pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

include(":app")
include(":app-shared-tests")
include(":ui-test-hilt-manifest")
