package ca.umanitoba.cs.timeline.uitesthiltmanifest

import androidx.activity.ComponentActivity
import dagger.hilt.android.AndroidEntryPoint

/**
 * [ComponentActivity] alternative for use with Hilt injection in tests.
 *
 * See Dagger issue [#3394](https://github.com/google/dagger/issues/3394)
 */
@AndroidEntryPoint
class HiltComponentActivity : ComponentActivity()
