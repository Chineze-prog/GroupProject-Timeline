package ca.umanitoba.cs.timeline.domain.goal

import ca.umanitoba.cs.timeline.data.InMemoryDayStatisticDao
import ca.umanitoba.cs.timeline.data.InMemoryGoalDao
import ca.umanitoba.cs.timeline.domain.dayStatistic.DayStatisticRepository
import ca.umanitoba.cs.timeline.domain.dayStatistic.DefaultDayStatisticRepository
import kotlinx.coroutines.test.TestScope
import org.junit.jupiter.api.Tag

@Tag("unit")
class InMemoryAddGoalTimeUseCase : AddGoalTimeUseCaseTest() {
    override fun TestScope.provideGoalRepository(): GoalRepository {
        return DefaultGoalRepository(InMemoryGoalDao())
    }

    override fun TestScope.provideDayStatisticRepository(): DayStatisticRepository {
        return DefaultDayStatisticRepository(InMemoryDayStatisticDao())
    }
}
