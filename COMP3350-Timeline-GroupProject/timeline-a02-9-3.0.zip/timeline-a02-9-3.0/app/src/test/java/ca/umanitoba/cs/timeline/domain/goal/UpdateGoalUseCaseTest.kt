package ca.umanitoba.cs.timeline.domain.goal

import ca.umanitoba.cs.timeline.domain.timer.InvalidDeadlineException
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.impl.annotations.MockK
import io.mockk.junit5.MockKExtension
import io.mockk.just
import io.mockk.runs
import java.time.Clock
import java.time.LocalDate
import java.time.Month
import java.time.ZoneOffset
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.extension.ExtendWith

@ExtendWith(MockKExtension::class)
@Tag("unit")
class UpdateGoalUseCaseTest {
    @MockK private lateinit var repository: GoalRepository
    private val goal = 1L

    @BeforeEach
    fun setup() {
        coEvery { repository.updateGoal(any(), any(), any()) } just runs
    }

    @Test
    fun `invalid deadline throws an exception`() = runTest {
        val fixedClock =
            Clock.fixed(
                LocalDate.of(2024, Month.MAY, 22).atStartOfDay().toInstant(ZoneOffset.UTC),
                ZoneOffset.UTC
            )

        val updateGoalUseCase = UpdateGoalUseCase(repository, fixedClock)
        val date = LocalDate.of(2024, Month.MAY, 21)

        assertThrows<InvalidDeadlineException>("Invalid Deadline") {
            updateGoalUseCase(goal, deadline = date)
        }

        // Since the update is invalid, repository update should not be invoked
        coVerify(exactly = 0) { repository.updateGoal(any(), any(), any()) }
    }

    @Test
    fun `deadline that are current dates do not throw an exception`() = runTest {
        val fixedClock =
            Clock.fixed(
                LocalDate.of(2024, Month.MAY, 22).atStartOfDay().toInstant(ZoneOffset.UTC),
                ZoneOffset.UTC
            )

        val updateGoalUseCase = UpdateGoalUseCase(repository, fixedClock)
        val date = LocalDate.of(2024, Month.MAY, 22)

        updateGoalUseCase(goal, deadline = date)
        coVerify(exactly = 1) { repository.updateGoal(any(), deadline = date) }
    }

    @Test
    fun `deadline that are future dates do not throw an exception`() = runTest {
        val fixedClock =
            Clock.fixed(
                LocalDate.of(2024, Month.MAY, 22).atStartOfDay().toInstant(ZoneOffset.UTC),
                ZoneOffset.UTC
            )

        val updateGoalUseCase = UpdateGoalUseCase(repository, fixedClock)
        val date = LocalDate.of(2028, Month.FEBRUARY, 29)

        updateGoalUseCase(goal, deadline = date)
        coVerify(exactly = 1) { repository.updateGoal(any(), deadline = date) }
    }
}
