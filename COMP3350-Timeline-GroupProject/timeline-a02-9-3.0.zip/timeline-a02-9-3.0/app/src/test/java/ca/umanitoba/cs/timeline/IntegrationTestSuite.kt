package ca.umanitoba.cs.timeline

import org.junit.platform.suite.api.IncludeTags
import org.junit.platform.suite.api.SelectPackages
import org.junit.platform.suite.api.Suite
import org.junit.platform.suite.api.SuiteDisplayName

@Suite
@SuiteDisplayName("Integration tests")
@SelectPackages("ca.umanitoba.cs.timeline")
@IncludeTags("integration")
class IntegrationTestSuite
