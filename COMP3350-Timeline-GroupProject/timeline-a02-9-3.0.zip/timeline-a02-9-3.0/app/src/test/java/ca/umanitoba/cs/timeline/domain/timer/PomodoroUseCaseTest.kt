package ca.umanitoba.cs.timeline.domain.timer

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test

@Tag("unit")
class PomodoroUseCaseTest {
    private val defaultConfig = PomodoroConfig()

    @Test
    fun initializeInWorkPeriod() {
        val pomodoro = PomodoroUseCase(defaultConfig)
        val state = pomodoro.state.value
        assertEquals(PomodoroState.State.POMODORO, state.state)
        assertEquals(defaultConfig.pomodoroDuration, state.duration)
    }

    @Test
    fun afterWorkIsShortBreak() {
        val pomodoro = PomodoroUseCase(defaultConfig)
        pomodoro.next()

        val state = pomodoro.state.value
        assertEquals(PomodoroState.State.SHORT_BREAK, state.state)
        assertEquals(defaultConfig.breakDuration, state.duration)
    }

    @Test
    fun afterShortBreakIsWork() {
        val pomodoro = PomodoroUseCase(defaultConfig)
        pomodoro.next()
        pomodoro.next()

        val state = pomodoro.state.value
        assertEquals(PomodoroState.State.POMODORO, state.state)
        assertEquals(defaultConfig.pomodoroDuration, state.duration)
    }

    @Test
    fun afterNCyclesIsLongBreak() {
        val pomodoro = PomodoroUseCase(defaultConfig)
        for (i in 1..defaultConfig.cyclesBeforeLongBreak) {
            pomodoro.next()
            pomodoro.next()
        }
        pomodoro.next()

        val state = pomodoro.state.value
        assertEquals(PomodoroState.State.LONG_BREAK, state.state)
        assertEquals(defaultConfig.longBreakDuration, state.duration)
    }

    @Test
    fun defaultInitUsesDefaultConfig() {
        val pomodoro = PomodoroUseCase()
        val state = pomodoro.state.value
        assertEquals(PomodoroState.State.POMODORO, state.state)
        assertEquals(defaultConfig.pomodoroDuration, state.duration)
    }
}
