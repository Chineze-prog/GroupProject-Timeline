import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.domain.recurringgoal.RecurringGoalRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

abstract class RecurringGoalUseCaseTest {
    abstract fun TestScope.provideGoalRepository(): GoalRepository

    abstract fun TestScope.provideRecurringGoalRepository(): RecurringGoalRepository

    @Test
    fun `add recurring goal successfully`() = runTest {
        val goalRepository = provideGoalRepository()
        val recurringGoalRepository = provideRecurringGoalRepository()
        val goalName = "Read a chapter daily"
        val goalId = goalRepository.addGoal(goalName)

        val frequency = RecurrenceFrequency.Daily
        val isRepeated = true

        recurringGoalRepository.setRecurringGoal(goalId, frequency, isRepeated)
        val recurringGoals = recurringGoalRepository.getRecurringGoals().first()

        assertEquals(1, recurringGoals.size)
        with(recurringGoals[0]) {
            assertEquals(goalId, this.goalId)
            assertEquals(frequency, this.repeatFrequency)
            assertTrue(this.isRepeated)
        }
    }

    @Test
    fun `updating recurring goal retains changes`() = runTest {
        val goalRepository = provideGoalRepository()
        val recurringGoalRepository = provideRecurringGoalRepository()
        val goalName = "Workout"
        val goalId = goalRepository.addGoal(goalName)
        var frequency = RecurrenceFrequency.Weekly
        var isRepeated = false

        recurringGoalRepository.setRecurringGoal(goalId, frequency, isRepeated)
        var recurringGoal = recurringGoalRepository.getRecurringGoal(goalId)

        assertNotNull(recurringGoal)
        assertEquals(RecurrenceFrequency.Weekly, recurringGoal?.repeatFrequency)
        assertFalse(recurringGoal?.isRepeated ?: true)

        frequency = RecurrenceFrequency.Daily
        isRepeated = true
        recurringGoalRepository.setRecurringGoal(goalId, frequency, isRepeated)
        recurringGoal = recurringGoalRepository.getRecurringGoal(goalId)

        assertNotNull(recurringGoal)
        assertEquals(RecurrenceFrequency.Daily, recurringGoal?.repeatFrequency)
        assertTrue(recurringGoal?.isRepeated ?: false)
    }

    @Test
    fun `deleting recurring goal removes it`() = runTest {
        val goalRepository = provideGoalRepository()
        val recurringGoalRepository = provideRecurringGoalRepository()
        val goalName = "Meditate"
        val goalId = goalRepository.addGoal(goalName)

        recurringGoalRepository.setRecurringGoal(goalId, RecurrenceFrequency.Daily, true)
        var recurringGoals = recurringGoalRepository.getRecurringGoals().first()
        assertEquals(1, recurringGoals.size)

        recurringGoalRepository.deleteRecurringGoal(goalId)
        recurringGoals = recurringGoalRepository.getRecurringGoals().first()
        assertTrue(recurringGoals.isEmpty())
    }
}
