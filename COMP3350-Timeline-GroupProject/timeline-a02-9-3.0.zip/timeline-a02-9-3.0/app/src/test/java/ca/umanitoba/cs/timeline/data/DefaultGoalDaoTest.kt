package ca.umanitoba.cs.timeline.data

import app.cash.sqldelight.driver.jdbc.sqlite.JdbcSqliteDriver
import ca.umanitoba.cs.timeline.Database
import ca.umanitoba.cs.timeline.di.ZoneIdModule
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import org.junit.jupiter.api.Tag

@Tag("integration")
class DefaultGoalDaoTest : GoalDaoTest() {
    override fun TestScope.provideGoalDao(): GoalDao {
        val driver = JdbcSqliteDriver(JdbcSqliteDriver.IN_MEMORY)
        Database.Schema.create(driver)
        val database = Database(driver)
        return DefaultGoalDao(
            database.goalQueries,
            ZoneIdModule.provideZoneId(),
            StandardTestDispatcher(testScheduler)
        )
    }
}
