package ca.umanitoba.cs.timeline.domain.timer

import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test

@Tag("unit")
class CollectTimeUseCaseTest {
    @Test
    fun `time is not collected twice`() = runTest {
        val collectTimeUseCase = CollectTimeUseCase()

        assertEquals(5.seconds, collectTimeUseCase(5.seconds))

        assertEquals(8.seconds, collectTimeUseCase(13.seconds))

        assertEquals(2.seconds, collectTimeUseCase(15.seconds))
    }

    @Test
    fun `collected time is reset`() = runTest {
        val collectTimeUseCase = CollectTimeUseCase()

        assertEquals(5.seconds, collectTimeUseCase(5.seconds))

        collectTimeUseCase.resetCollectedTime()
        assertEquals(15.seconds, collectTimeUseCase(15.seconds))

        collectTimeUseCase.resetCollectedTime()
        assertEquals(10.seconds, collectTimeUseCase(10.seconds))
    }
}
