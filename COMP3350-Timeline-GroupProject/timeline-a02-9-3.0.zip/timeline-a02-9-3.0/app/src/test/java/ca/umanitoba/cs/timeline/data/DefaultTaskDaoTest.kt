package ca.umanitoba.cs.timeline.data

import app.cash.sqldelight.driver.jdbc.sqlite.JdbcSqliteDriver
import ca.umanitoba.cs.timeline.Database
import java.util.Properties
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows

@Tag("integration")
class DefaultTaskDaoTest : TaskDaoTest() {
    override val goalIds: LongArray = longArrayOf(1, 2, 3)

    override fun TestScope.provideTaskDao(): TaskDao {
        val driver =
            JdbcSqliteDriver(
                JdbcSqliteDriver.IN_MEMORY,
                Properties().apply { put("foreign_keys", "true") }
            )
        Database.Schema.create(driver)
        val database = Database(driver)

        // Insert a few goals to test with
        database.goalQueries.insertGoal("placeholder")
        database.goalQueries.insertGoal("placeholder")
        database.goalQueries.insertGoal("placeholder")

        return DefaultTaskDao(database.taskQueries, StandardTestDispatcher(testScheduler))
    }

    @Test
    fun `Error on invalid goal reference`() = runTest {
        val taskDao = provideTaskDao()
        assertThrows<Exception> { taskDao.addTask(999L, "something") }
    }
}
