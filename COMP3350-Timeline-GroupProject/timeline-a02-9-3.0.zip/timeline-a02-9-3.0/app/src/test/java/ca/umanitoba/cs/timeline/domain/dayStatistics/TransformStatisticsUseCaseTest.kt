package ca.umanitoba.cs.timeline.domain.dayStatistics

import ca.umanitoba.cs.timeline.domain.dayStatistic.GenerateLabelsUseCase
import ca.umanitoba.cs.timeline.domain.dayStatistic.TransformStatisticsUseCase
import ca.umanitoba.cs.timeline.model.DayStatistic
import java.time.LocalDate
import java.time.Month
import kotlin.time.Duration.Companion.minutes
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test

@Tag("unit")
class TransformStatisticsUseCaseTest {
    @Test
    fun transformForWeeklyView() {
        val dayStat1 = DayStatistic(LocalDate.of(2024, Month.MARCH, 28), 0, 12.minutes)
        val dayStat2 = DayStatistic(LocalDate.of(2024, Month.MARCH, 26), 0, 42.minutes)
        val dayStat3 = DayStatistic(LocalDate.of(2024, Month.MARCH, 26), 0, 51.minutes)
        val dayStat4 = DayStatistic(LocalDate.of(2024, Month.MARCH, 25), 0, 201.minutes)
        val dayStat5 = DayStatistic(LocalDate.of(2024, Month.MARCH, 29), 0, 284.minutes)
        val dayStat6 = DayStatistic(LocalDate.of(2024, Month.MARCH, 30), 0, 56.minutes)
        val dayStat7 = DayStatistic(LocalDate.of(2024, Month.MARCH, 30), 0, 176.minutes)

        val dayStatList =
            listOf(dayStat1, dayStat2, dayStat3, dayStat4, dayStat5, dayStat6, dayStat7)

        val transformStatisticsUseCase = TransformStatisticsUseCase(GenerateLabelsUseCase())

        val transformedData = transformStatisticsUseCase.transformForWeeklyView(dayStatList)

        transformedData["Mon"]?.let { assertEquals(201f, it.sum()) }
        transformedData["Tue"]?.let { assertEquals(93f, it.sum()) }
        transformedData["Wed"]?.let { assertEquals(0f, it.sum()) }
        transformedData["Thu"]?.let { assertEquals(12f, it.sum()) }
        transformedData["Fri"]?.let { assertEquals(284f, it.sum()) }
        transformedData["Sat"]?.let { assertEquals(232f, it.sum()) }
        transformedData["Sun"]?.let { assertEquals(0f, it.sum()) }
    }

    @Test
    fun transformForMonthlyView() {
        val dayStat1 = DayStatistic(LocalDate.of(2024, Month.MARCH, 15), 0, 92.minutes)
        val dayStat2 = DayStatistic(LocalDate.of(2024, Month.JANUARY, 20), 0, 87.minutes)
        val dayStat3 = DayStatistic(LocalDate.of(2024, Month.JANUARY, 19), 0, 71.minutes)
        val dayStat4 = DayStatistic(LocalDate.of(2024, Month.AUGUST, 17), 0, 109.minutes)
        val dayStat5 = DayStatistic(LocalDate.of(2024, Month.DECEMBER, 30), 0, 143.minutes)
        val dayStat6 = DayStatistic(LocalDate.of(2024, Month.APRIL, 3), 0, 95.minutes)
        val dayStat7 = DayStatistic(LocalDate.of(2024, Month.APRIL, 5), 0, 84.minutes)

        val dayStatList =
            listOf(dayStat1, dayStat2, dayStat3, dayStat4, dayStat5, dayStat6, dayStat7)

        val transformStatisticsUseCase = TransformStatisticsUseCase(GenerateLabelsUseCase())

        val transformedData = transformStatisticsUseCase.transformForMonthlyView(dayStatList)

        transformedData["January"]?.let { assertEquals(158f, it.sum()) }
        transformedData["February"]?.let { assertEquals(0f, it.sum()) }
        transformedData["March"]?.let { assertEquals(92f, it.sum()) }
        transformedData["April"]?.let { assertEquals(179f, it.sum()) }
        transformedData["May"]?.let { assertEquals(0f, it.sum()) }
        transformedData["June"]?.let { assertEquals(0f, it.sum()) }
        transformedData["July"]?.let { assertEquals(0f, it.sum()) }
        transformedData["August"]?.let { assertEquals(109f, it.sum()) }
        transformedData["September"]?.let { assertEquals(0f, it.sum()) }
        transformedData["October"]?.let { assertEquals(0f, it.sum()) }
        transformedData["November"]?.let { assertEquals(0f, it.sum()) }
        transformedData["December"]?.let { assertEquals(143f, it.sum()) }
    }

    @Test
    fun transformForYearlyView() {
        val dayStat1 = DayStatistic(LocalDate.of(2020, Month.MARCH, 10), 0, 80.minutes)
        val dayStat2 = DayStatistic(LocalDate.of(2019, Month.JANUARY, 20), 0, 67.minutes)
        val dayStat3 = DayStatistic(LocalDate.of(2019, Month.JULY, 26), 0, 183.minutes)
        val dayStat4 = DayStatistic(LocalDate.of(2015, Month.JUNE, 13), 0, 76.minutes)
        val dayStat5 = DayStatistic(LocalDate.of(2013, Month.NOVEMBER, 9), 0, 32.minutes)
        val dayStat6 = DayStatistic(LocalDate.of(2013, Month.DECEMBER, 1), 0, 15.minutes)
        val dayStat7 = DayStatistic(LocalDate.of(2008, Month.OCTOBER, 11), 0, 3.minutes)

        val dayStatList =
            listOf(dayStat1, dayStat2, dayStat3, dayStat4, dayStat5, dayStat6, dayStat7)

        val transformStatisticsUseCase = TransformStatisticsUseCase(GenerateLabelsUseCase())

        val transformedData = transformStatisticsUseCase.transformForYearlyView(dayStatList)

        assertEquals(5, transformedData.keys.size)
        transformedData["2020"]?.let { assertEquals(80f, it.sum()) }
        transformedData["2019"]?.let { assertEquals(250f, it.sum()) }
        transformedData["2015"]?.let { assertEquals(76f, it.sum()) }
        transformedData["2013"]?.let { assertEquals(47f, it.sum()) }
        transformedData["2008"]?.let { assertEquals(3f, it.sum()) }
    }
}
