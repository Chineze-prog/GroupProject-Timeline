package ca.umanitoba.cs.timeline.data

import kotlinx.coroutines.test.TestScope
import org.junit.jupiter.api.Tag

@Tag("unit")
class InMemoryTaskDaoTest : TaskDaoTest() {
    override val goalIds: LongArray = longArrayOf(1, 2, 3)

    override fun TestScope.provideTaskDao(): TaskDao = InMemoryTaskDao()
}
