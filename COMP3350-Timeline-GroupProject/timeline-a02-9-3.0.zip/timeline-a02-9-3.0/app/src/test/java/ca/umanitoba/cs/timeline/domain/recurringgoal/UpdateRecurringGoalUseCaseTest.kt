package ca.umanitoba.cs.timeline.domain.recurringgoal

import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.impl.annotations.MockK
import io.mockk.junit5.MockKExtension
import io.mockk.just
import io.mockk.mockk
import io.mockk.runs
import java.time.Clock
import java.time.LocalDate
import java.time.Month
import java.time.ZoneOffset
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.extension.ExtendWith

@ExtendWith(MockKExtension::class)
@Tag("unit")
class UpdateRecurringGoalUseCaseTest {

    @MockK private lateinit var recurringGoalRepository: RecurringGoalRepository

    @MockK private lateinit var goalRepository: GoalRepository

    @MockK private lateinit var taskRepository: TaskRepository

    @MockK private lateinit var recurringGoalManager: RecurringGoalManager

    private val clock: Clock =
        Clock.fixed(
            LocalDate.of(2024, Month.JANUARY, 1).atStartOfDay().toInstant(ZoneOffset.UTC),
            ZoneOffset.UTC
        )

    private val goalId = 1L
    private val frequency = RecurrenceFrequency.Weekly

    @BeforeEach
    fun setup() {
        coEvery { goalRepository.getGoal(any()) } returns mockk(relaxed = true)
        coEvery { recurringGoalRepository.getRecurringGoal(any()) } returns mockk(relaxed = true)
        coEvery { recurringGoalRepository.setRecurringGoal(any(), any(), any()) } just runs
        coEvery { goalRepository.updateGoal(any(), any(), any()) } just runs
        coEvery { taskRepository.getTaskCompletionForGoal(any()) } returns flowOf(Pair(0, 0))
        coEvery { taskRepository.getTasksForGoal(any()) } returns flowOf(emptyList())
        coEvery { recurringGoalManager.handleTaskCompletionForGoal(any(), any()) } just runs
    }

    @Test
    fun `update recurring goal with existing frequency and deadline`() = runTest {
        val updateRecurringGoalUseCase =
            UpdateRecurringGoalUseCase(
                recurringGoalRepository,
                recurringGoalManager,
                goalRepository,
                taskRepository,
                clock
            )
        val deadline = LocalDate.of(2024, Month.JANUARY, 8)

        updateRecurringGoalUseCase(goalId, frequency, deadline)

        coVerify(exactly = 1) {
            recurringGoalRepository.setRecurringGoal(goalId, frequency, isRepeated = false)
        }
        coVerify(exactly = 1) { goalRepository.updateGoal(goalId, deadline = deadline) }
    }

    @Test
    fun `throws IllegalStateException when frequency is not provided for new recurring goal`() =
        runTest {
            val updateRecurringGoalUseCase =
                UpdateRecurringGoalUseCase(
                    recurringGoalRepository,
                    recurringGoalManager,
                    goalRepository,
                    taskRepository,
                    clock
                )

            coEvery { goalRepository.getGoal(goalId) } returns null
            coEvery { recurringGoalRepository.getRecurringGoal(goalId) } returns null

            assertThrows<IllegalStateException> {
                updateRecurringGoalUseCase(goalId, deadline = LocalDate.now(clock))
            }
        }

    @Test
    fun `repeats goal and tasks when all tasks are completed`() = runTest {
        val stats = Pair(5, 5)
        coEvery { taskRepository.getTaskCompletionForGoal(goalId) } returns flowOf(stats)
        coEvery { recurringGoalRepository.getRecurringGoal(any()) } returns
            mockk {
                coEvery { isRepeated } returns false
                coEvery { repeatFrequency } returns frequency
            }

        val updateRecurringGoalUseCase =
            UpdateRecurringGoalUseCase(
                recurringGoalRepository,
                recurringGoalManager,
                goalRepository,
                taskRepository,
                clock
            )

        updateRecurringGoalUseCase(goalId, frequency)

        coVerify { recurringGoalManager.handleTaskCompletionForGoal(goalId, frequency) }
    }

    @Test
    fun `updates frequency when a different one is provided`() = runTest {
        val newFrequency = RecurrenceFrequency.Monthly
        coEvery { recurringGoalRepository.getRecurringGoal(any()) } returns mockk(relaxed = true)

        val updateRecurringGoalUseCase =
            UpdateRecurringGoalUseCase(
                recurringGoalRepository,
                recurringGoalManager,
                goalRepository,
                taskRepository,
                clock
            )

        updateRecurringGoalUseCase(goalId, newFrequency)

        coVerify {
            recurringGoalRepository.setRecurringGoal(goalId, newFrequency, isRepeated = false)
        }
    }
}
