package ca.umanitoba.cs.timeline.data

import kotlinx.coroutines.test.TestScope
import org.junit.jupiter.api.Tag

@Tag("unit")
class InMemoryDayStatisticDaoTest : DayStatisticDaoTest() {
    override val goalIds: LongArray = longArrayOf(1, 2, 3)

    override fun TestScope.provideDayStatisticDao(): DayStatisticDao = InMemoryDayStatisticDao()
}
