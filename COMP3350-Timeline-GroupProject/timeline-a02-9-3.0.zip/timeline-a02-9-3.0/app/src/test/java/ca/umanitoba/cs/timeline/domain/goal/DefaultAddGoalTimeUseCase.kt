package ca.umanitoba.cs.timeline.domain.goal

import app.cash.sqldelight.driver.jdbc.sqlite.JdbcSqliteDriver
import ca.umanitoba.cs.timeline.Database
import ca.umanitoba.cs.timeline.data.DefaultDayStatisticDao
import ca.umanitoba.cs.timeline.data.DefaultGoalDao
import ca.umanitoba.cs.timeline.di.ZoneIdModule
import ca.umanitoba.cs.timeline.domain.dayStatistic.DayStatisticRepository
import ca.umanitoba.cs.timeline.domain.dayStatistic.DefaultDayStatisticRepository
import java.util.Properties
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import org.junit.jupiter.api.Tag

@Tag("integration")
class DefaultAddGoalTimeUseCase : AddGoalTimeUseCaseTest() {
    private var database: Database

    init {
        val driver =
            JdbcSqliteDriver(
                JdbcSqliteDriver.IN_MEMORY,
                Properties().apply { put("foreign_keys", "true") }
            )
        Database.Schema.create(driver)
        database = Database(driver)
    }

    override fun TestScope.provideGoalRepository(): GoalRepository {
        return DefaultGoalRepository(
            DefaultGoalDao(
                database.goalQueries,
                ZoneIdModule.provideZoneId(),
                StandardTestDispatcher(testScheduler)
            )
        )
    }

    override fun TestScope.provideDayStatisticRepository(): DayStatisticRepository {
        return DefaultDayStatisticRepository(
            DefaultDayStatisticDao(
                database.dayStatisticQueries,
                ZoneIdModule.provideZoneId(),
                StandardTestDispatcher(testScheduler)
            )
        )
    }
}
