package ca.umanitoba.cs.timeline.data

import java.time.LocalDate
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

abstract class DayStatisticDaoTest {
    abstract val goalIds: LongArray

    abstract fun TestScope.provideDayStatisticDao(): DayStatisticDao

    @Test
    fun `day statistics can be added`() = runTest {
        val dayStatList = provideDayStatisticDao()
        val dayStats =
            dayStatList.getDayStats().stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        delay(1.milliseconds)

        assertTrue(dayStats.value.isEmpty())

        val date1 = LocalDate.of(2000, 10, 10)
        val date2 = LocalDate.of(2010, 7, 8)

        dayStatList.addDayStat(date1, goalIds[0])
        delay(1.milliseconds)
        assertEquals(1, dayStats.value.count())
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date1, goalIds[0]))

        dayStatList.addDayStat(date2, goalIds[1])
        delay(1.milliseconds)
        assertEquals(2, dayStats.value.count())
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date2, goalIds[1]))
    }

    @Test
    fun `repeat day statistics are not added again`() = runTest {
        val dayStatList = provideDayStatisticDao()
        val dayStats =
            dayStatList.getDayStats().stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        delay(1.milliseconds)

        assertTrue(dayStats.value.isEmpty())

        val date1 = LocalDate.of(2000, 10, 10)
        val date2 = LocalDate.of(2010, 7, 8)

        dayStatList.addDayStat(date1, goalIds[0])
        delay(1.milliseconds)
        assertEquals(1, dayStats.value.count())
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date1, goalIds[0]))

        dayStatList.addDayStat(date2, goalIds[1])
        delay(1.milliseconds)
        assertEquals(2, dayStats.value.count())
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date2, goalIds[1]))

        dayStatList.addDayStat(date1, goalIds[0])
        delay(1.milliseconds)
        assertEquals(2, dayStats.value.count())
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date1, goalIds[0]))

        dayStatList.addDayStat(date2, goalIds[1])
        delay(1.milliseconds)
        assertEquals(2, dayStats.value.count())
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date2, goalIds[1]))
    }

    @Test
    fun `day statistics with the same date but different goals are considered different`() =
        runTest {
            val dayStatList = provideDayStatisticDao()
            val dayStats =
                dayStatList
                    .getDayStats()
                    .stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
            delay(1.milliseconds)

            assertTrue(dayStats.value.isEmpty())

            val date1 = LocalDate.of(2000, 10, 10)

            dayStatList.addDayStat(date1, goalIds[0])
            delay(1.milliseconds)
            assertEquals(1, dayStats.value.count())

            dayStatList.addDayStat(date1, goalIds[1])
            delay(1.milliseconds)
            assertEquals(2, dayStats.value.count())
        }

    @Test
    fun `day statistics with the same goal but different dates are considered different`() =
        runTest {
            val dayStatList = provideDayStatisticDao()
            val dayStats =
                dayStatList
                    .getDayStats()
                    .stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
            delay(1.milliseconds)

            assertTrue(dayStats.value.isEmpty())
            assertTrue(dayStatList.getDayStats().first().isEmpty())

            val date1 = LocalDate.of(2000, 10, 10)
            val date2 = LocalDate.of(2015, 7, 15)

            dayStatList.addDayStat(date1, goalIds[0])
            delay(1.milliseconds)
            assertEquals(1, dayStats.value.count())

            dayStatList.addDayStat(date2, goalIds[0])
            delay(1.milliseconds)
            assertEquals(2, dayStats.value.count())
        }

    @Test
    fun `time is added to correct day statistic`() = runTest {
        val dayStatList = provideDayStatisticDao()

        val date1 = LocalDate.of(2000, 10, 10)
        val date2 = LocalDate.of(2015, 7, 15)
        val date3 = LocalDate.of(2010, 5, 20)

        dayStatList.addDayStat(date1, goalIds[0])
        dayStatList.addDayStat(date1, goalIds[1])
        dayStatList.addDayStat(date2, goalIds[2])
        dayStatList.addDayStat(date3, goalIds[2])

        dayStatList.addTimeToStat(date1, goalIds[1], 10.seconds)
        dayStatList.addTimeToStat(date3, goalIds[2], 5.seconds)

        assertEquals(0.seconds, dayStatList.getDayStatByGoalIdAndDate(date1, goalIds[0])?.timeSpent)
        assertEquals(
            10.seconds,
            dayStatList.getDayStatByGoalIdAndDate(date1, goalIds[1])?.timeSpent
        )
        assertEquals(0.seconds, dayStatList.getDayStatByGoalIdAndDate(date2, goalIds[2])?.timeSpent)
        assertEquals(5.seconds, dayStatList.getDayStatByGoalIdAndDate(date3, goalIds[2])?.timeSpent)
    }

    @Test
    fun `statistics can be retrieved by a date`() = runTest {
        val dayStatList = provideDayStatisticDao()

        val date1 = LocalDate.of(2000, 10, 10)
        val date2 = LocalDate.of(2015, 7, 15)
        val date3 = LocalDate.of(2010, 5, 20)

        dayStatList.addDayStat(date1, goalIds[0])
        dayStatList.addDayStat(date1, goalIds[1])
        dayStatList.addDayStat(date2, goalIds[2])
        dayStatList.addDayStat(date3, goalIds[2])

        val filteredDayStats = dayStatList.getDayStatsByDate(date1).first()
        delay(1.milliseconds)

        assertEquals(2, filteredDayStats.count())
        assertNotNull(filteredDayStats.find { it.date == date1 && it.goalId == goalIds[0] })
        assertNotNull(filteredDayStats.find { it.date == date1 && it.goalId == goalIds[1] })
        assertNull(filteredDayStats.find { it.date == date2 && it.goalId == goalIds[2] })
        assertNull(filteredDayStats.find { it.date == date3 && it.goalId == goalIds[3] })
    }

    @Test
    fun `statistics can be retrieved by a goal id`() = runTest {
        val dayStatList = provideDayStatisticDao()

        val date1 = LocalDate.of(2000, 10, 10)
        val date2 = LocalDate.of(2015, 7, 15)
        val date3 = LocalDate.of(2010, 5, 20)

        dayStatList.addDayStat(date1, goalIds[0])
        dayStatList.addDayStat(date1, goalIds[1])
        dayStatList.addDayStat(date2, goalIds[2])
        dayStatList.addDayStat(date3, goalIds[2])

        val filteredDayStats = dayStatList.getDayStatsByGoalId(goalIds[2]).first()

        assertEquals(2, filteredDayStats.count())
        assertNotNull(filteredDayStats.find { it.date == date2 && it.goalId == goalIds[2] })
        assertNotNull(filteredDayStats.find { it.date == date3 && it.goalId == goalIds[2] })
        assertNull(filteredDayStats.find { it.date == date1 && it.goalId == goalIds[0] })
        assertNull(filteredDayStats.find { it.date == date1 && it.goalId == goalIds[1] })
    }

    @Test
    fun `day statistics can be removed`() = runTest {
        val dayStatList = provideDayStatisticDao()

        val date1 = LocalDate.of(2000, 10, 10)
        val date2 = LocalDate.of(2015, 7, 15)
        val date3 = LocalDate.of(2010, 5, 20)

        dayStatList.addDayStat(date1, goalIds[0])
        dayStatList.addDayStat(date1, goalIds[1])
        dayStatList.addDayStat(date2, goalIds[2])
        dayStatList.addDayStat(date3, goalIds[2])

        assertEquals(4, dayStatList.getDayStats().first().count())
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date1, goalIds[0]))
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date1, goalIds[1]))
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date2, goalIds[2]))
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date3, goalIds[2]))

        dayStatList.removeDayStat(date1, goalIds[1])

        assertEquals(3, dayStatList.getDayStats().first().count())
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date1, goalIds[0]))
        assertNull(dayStatList.getDayStatByGoalIdAndDate(date1, goalIds[1]))
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date2, goalIds[2]))
        assertNotNull(dayStatList.getDayStatByGoalIdAndDate(date3, goalIds[2]))
    }

    @Test
    fun `all flows are updated after filtering and adding a statistic`() = runTest {
        val dayStatList = provideDayStatisticDao()
        val dayStats =
            dayStatList.getDayStats().stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        delay(1.milliseconds)

        val date1 = LocalDate.of(2000, 10, 10)
        val date2 = LocalDate.of(2015, 7, 15)
        val date3 = LocalDate.of(2010, 5, 20)

        dayStatList.addDayStat(date1, goalIds[0])
        dayStatList.addDayStat(date1, goalIds[1])
        dayStatList.addDayStat(date2, goalIds[2])
        dayStatList.addDayStat(date3, goalIds[2])
        delay(1.milliseconds)
        assertEquals(4, dayStats.value.count())

        val filteredDayStatsByDay =
            dayStatList
                .getDayStatsByDate(date1)
                .stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        val filteredDayStatsByGoal =
            dayStatList
                .getDayStatsByGoalId(goalIds[2])
                .stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        delay(1.milliseconds)

        assertEquals(2, filteredDayStatsByDay.value.count())
        assertNotNull(
            filteredDayStatsByDay.value.find { it.date == date1 && it.goalId == goalIds[0] }
        )
        assertNotNull(
            filteredDayStatsByDay.value.find { it.date == date1 && it.goalId == goalIds[1] }
        )

        assertEquals(2, filteredDayStatsByGoal.value.count())
        assertNotNull(
            filteredDayStatsByGoal.value.find { it.date == date2 && it.goalId == goalIds[2] }
        )
        assertNotNull(
            filteredDayStatsByGoal.value.find { it.date == date3 && it.goalId == goalIds[2] }
        )

        dayStatList.addDayStat(date1, goalIds[2])
        delay(1.milliseconds)

        assertEquals(5, dayStats.value.count())

        assertEquals(3, filteredDayStatsByDay.value.count())
        assertNotNull(
            filteredDayStatsByDay.value.find { it.date == date1 && it.goalId == goalIds[0] }
        )
        assertNotNull(
            filteredDayStatsByDay.value.find { it.date == date1 && it.goalId == goalIds[1] }
        )
        assertNotNull(
            filteredDayStatsByDay.value.find { it.date == date1 && it.goalId == goalIds[2] }
        )

        assertEquals(3, filteredDayStatsByGoal.value.count())
        assertNotNull(
            filteredDayStatsByGoal.value.find { it.date == date2 && it.goalId == goalIds[2] }
        )
        assertNotNull(
            filteredDayStatsByGoal.value.find { it.date == date3 && it.goalId == goalIds[2] }
        )
        assertNotNull(
            filteredDayStatsByDay.value.find { it.date == date1 && it.goalId == goalIds[2] }
        )
    }

    @Test
    fun `filtered flows are updated after removing a statistic`() = runTest {
        val dayStatList = provideDayStatisticDao()
        val dayStats =
            dayStatList.getDayStats().stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        delay(1.milliseconds)

        val date1 = LocalDate.of(2000, 10, 10)
        val date2 = LocalDate.of(2015, 7, 15)
        val date3 = LocalDate.of(2010, 5, 20)

        dayStatList.addDayStat(date1, goalIds[0])
        dayStatList.addDayStat(date1, goalIds[1])
        dayStatList.addDayStat(date2, goalIds[2])
        dayStatList.addDayStat(date3, goalIds[2])
        delay(1.milliseconds)
        assertEquals(4, dayStats.value.count())

        val filteredDayStatsByDay =
            dayStatList
                .getDayStatsByDate(date1)
                .stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        val filteredDayStatsByGoal =
            dayStatList
                .getDayStatsByGoalId(goalIds[2])
                .stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        delay(1.milliseconds)

        assertEquals(2, filteredDayStatsByDay.value.count())
        assertNotNull(
            filteredDayStatsByDay.value.find { it.date == date1 && it.goalId == goalIds[0] }
        )
        assertNotNull(
            filteredDayStatsByDay.value.find { it.date == date1 && it.goalId == goalIds[1] }
        )

        assertEquals(2, filteredDayStatsByGoal.value.count())
        assertNotNull(
            filteredDayStatsByGoal.value.find { it.date == date2 && it.goalId == goalIds[2] }
        )
        assertNotNull(
            filteredDayStatsByGoal.value.find { it.date == date3 && it.goalId == goalIds[2] }
        )

        dayStatList.removeDayStat(date1, goalIds[1])
        delay(1.milliseconds)

        assertEquals(3, dayStats.value.count())

        assertEquals(1, filteredDayStatsByDay.value.count())
        assertNotNull(
            filteredDayStatsByDay.value.find { it.date == date1 && it.goalId == goalIds[0] }
        )
        assertNull(filteredDayStatsByDay.value.find { it.date == date1 && it.goalId == goalIds[1] })

        assertEquals(2, filteredDayStatsByGoal.value.count())
        assertNotNull(
            filteredDayStatsByGoal.value.find { it.date == date2 && it.goalId == goalIds[2] }
        )
        assertNotNull(
            filteredDayStatsByGoal.value.find { it.date == date3 && it.goalId == goalIds[2] }
        )
    }

    @Test
    fun `filtered flows are updated after adding time to a statistic`() = runTest {
        val dayStatList = provideDayStatisticDao()
        val dayStats =
            dayStatList.getDayStats().stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        delay(1.milliseconds)

        val date1 = LocalDate.of(2000, 10, 10)
        val date2 = LocalDate.of(2015, 7, 15)
        val date3 = LocalDate.of(2010, 5, 20)

        dayStatList.addDayStat(date1, goalIds[0])
        dayStatList.addDayStat(date1, goalIds[1])
        dayStatList.addDayStat(date2, goalIds[2])
        dayStatList.addDayStat(date3, goalIds[2])
        delay(1.milliseconds)
        assertEquals(4, dayStats.value.count())

        val filteredDayStatsByDay =
            dayStatList
                .getDayStatsByDate(date1)
                .stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        val filteredDayStatsByGoal =
            dayStatList
                .getDayStatsByGoalId(goalIds[2])
                .stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        delay(1.milliseconds)

        assertEquals(2, filteredDayStatsByDay.value.count())
        assertEquals(
            0.seconds,
            filteredDayStatsByDay.value
                .find { it.date == date1 && it.goalId == goalIds[0] }
                ?.timeSpent
        )
        assertEquals(
            0.seconds,
            filteredDayStatsByDay.value
                .find { it.date == date1 && it.goalId == goalIds[1] }
                ?.timeSpent
        )

        assertEquals(2, filteredDayStatsByGoal.value.count())
        assertEquals(
            0.seconds,
            filteredDayStatsByGoal.value
                .find { it.date == date2 && it.goalId == goalIds[2] }
                ?.timeSpent
        )
        assertEquals(
            0.seconds,
            filteredDayStatsByGoal.value
                .find { it.date == date3 && it.goalId == goalIds[2] }
                ?.timeSpent
        )

        dayStatList.addTimeToStat(date1, goalIds[1], 5.seconds)
        dayStatList.addTimeToStat(date2, goalIds[2], 3.seconds)
        delay(1.milliseconds)

        assertEquals(4, dayStats.value.count())

        assertEquals(2, filteredDayStatsByDay.value.count())
        assertEquals(
            0.seconds,
            filteredDayStatsByDay.value
                .find { it.date == date1 && it.goalId == goalIds[0] }
                ?.timeSpent
        )
        assertEquals(
            5.seconds,
            filteredDayStatsByDay.value
                .find { it.date == date1 && it.goalId == goalIds[1] }
                ?.timeSpent
        )

        assertEquals(2, filteredDayStatsByGoal.value.count())
        assertEquals(
            3.seconds,
            filteredDayStatsByGoal.value
                .find { it.date == date2 && it.goalId == goalIds[2] }
                ?.timeSpent
        )
        assertEquals(
            0.seconds,
            filteredDayStatsByGoal.value
                .find { it.date == date3 && it.goalId == goalIds[2] }
                ?.timeSpent
        )
    }

    @Test
    fun `day statistics can be removed by a goal id`() = runTest {
        val dayStatList = provideDayStatisticDao()
        delay(1.milliseconds)

        val date1 = LocalDate.of(2000, 10, 10)
        val date2 = LocalDate.of(2015, 7, 15)
        val date3 = LocalDate.of(2010, 5, 20)

        dayStatList.addDayStat(date1, goalIds[0])
        dayStatList.addDayStat(date1, goalIds[1])
        dayStatList.addDayStat(date2, goalIds[2])
        dayStatList.addDayStat(date3, goalIds[2])

        assertEquals(4, dayStatList.getDayStats().first().count())

        dayStatList.removeDayStatByGoal(goalIds[2])

        assertEquals(2, dayStatList.getDayStats().first().count())
    }
}
