package ca.umanitoba.cs.timeline.domain.dayStatistics

import ca.umanitoba.cs.timeline.domain.dayStatistic.FilterStatsByTimePeriodUseCase
import ca.umanitoba.cs.timeline.model.DayStatistic
import java.time.LocalDate
import java.time.Month
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test

@Tag("unit")
class FilterStatsByTimePeriodUseCaseTest {
    @Test
    fun getWeeklyStats() = runTest {
        val dayStatMon = DayStatistic(LocalDate.of(2024, Month.MARCH, 25), 0)
        val dayStatTue = DayStatistic(LocalDate.of(2024, Month.MARCH, 26), 0)
        val dayStatWed = DayStatistic(LocalDate.of(2024, Month.MARCH, 27), 0)
        val dayStatThu = DayStatistic(LocalDate.of(2024, Month.MARCH, 28), 0)
        val dayStatFri = DayStatistic(LocalDate.of(2024, Month.MARCH, 29), 0)
        val dayStatSat = DayStatistic(LocalDate.of(2024, Month.MARCH, 30), 0)
        val dayStatSun = DayStatistic(LocalDate.of(2024, Month.MARCH, 31), 0)
        val dayStatOutOfWeek = DayStatistic(LocalDate.of(2024, Month.APRIL, 1), 0)

        val dayStatFlowList =
            MutableStateFlow(
                    listOf(
                        dayStatMon,
                        dayStatTue,
                        dayStatWed,
                        dayStatThu,
                        dayStatFri,
                        dayStatSat,
                        dayStatSun,
                        dayStatOutOfWeek
                    )
                )
                .asStateFlow()

        val filterStatsByTimePeriodUseCase = FilterStatsByTimePeriodUseCase()

        val filledWeek =
            filterStatsByTimePeriodUseCase.getWeeklyStats(
                dayStatFlowList,
                LocalDate.of(2024, Month.MARCH, 29)
            )

        assertEquals(7, filledWeek.first().count())

        val outsideOfWeek =
            filterStatsByTimePeriodUseCase.getWeeklyStats(
                dayStatFlowList,
                LocalDate.of(2024, Month.APRIL, 5)
            )

        assertEquals(1, outsideOfWeek.first().count())
    }

    @Test
    fun getMonthlyStats() = runTest {
        val dayStatJan = DayStatistic(LocalDate.of(2024, Month.JANUARY, 10), 0)
        val dayStatFeb = DayStatistic(LocalDate.of(2024, Month.FEBRUARY, 10), 0)
        val dayStatMar = DayStatistic(LocalDate.of(2024, Month.MARCH, 10), 0)
        val dayStatApr = DayStatistic(LocalDate.of(2024, Month.APRIL, 10), 0)
        val dayStatMay = DayStatistic(LocalDate.of(2024, Month.MAY, 10), 0)
        val dayStatJun = DayStatistic(LocalDate.of(2024, Month.JUNE, 10), 0)
        val dayStatJul = DayStatistic(LocalDate.of(2024, Month.JULY, 10), 0)
        val dayStatAug = DayStatistic(LocalDate.of(2024, Month.AUGUST, 10), 0)
        val dayStatSep = DayStatistic(LocalDate.of(2024, Month.SEPTEMBER, 10), 0)
        val dayStatOct = DayStatistic(LocalDate.of(2024, Month.OCTOBER, 10), 0)
        val dayStatNov = DayStatistic(LocalDate.of(2024, Month.NOVEMBER, 10), 0)
        val dayStatDec = DayStatistic(LocalDate.of(2024, Month.DECEMBER, 10), 0)
        val dayStatOutOfYear = DayStatistic(LocalDate.of(2026, Month.AUGUST, 10), 0)

        val dayStatFlowList =
            MutableStateFlow(
                    listOf(
                        dayStatJan,
                        dayStatFeb,
                        dayStatMar,
                        dayStatApr,
                        dayStatMay,
                        dayStatJun,
                        dayStatJul,
                        dayStatAug,
                        dayStatSep,
                        dayStatOct,
                        dayStatNov,
                        dayStatDec,
                        dayStatOutOfYear
                    )
                )
                .asStateFlow()

        val filterStatsByTimePeriodUseCase = FilterStatsByTimePeriodUseCase()

        val filledYear =
            filterStatsByTimePeriodUseCase.getMonthlyStats(
                dayStatFlowList,
                LocalDate.of(2024, Month.JUNE, 12)
            )

        assertEquals(12, filledYear.first().count())

        val outsideOfYear =
            filterStatsByTimePeriodUseCase.getMonthlyStats(
                dayStatFlowList,
                LocalDate.of(2026, Month.OCTOBER, 19)
            )

        assertEquals(1, outsideOfYear.first().count())
    }

    @Test
    fun getYearlyStats() = runTest {
        val dayStat2024 = DayStatistic(LocalDate.of(2024, Month.JANUARY, 4), 0)
        val dayStat2025 = DayStatistic(LocalDate.of(2025, Month.FEBRUARY, 17), 0)
        val dayStat2026 = DayStatistic(LocalDate.of(2026, Month.JULY, 21), 0)
        val dayStat2027 = DayStatistic(LocalDate.of(2027, Month.DECEMBER, 26), 0)

        val dayStatFlowList =
            MutableStateFlow(listOf(dayStat2027, dayStat2024, dayStat2026, dayStat2025))
                .asStateFlow()

        assertEquals(dayStatFlowList.first()[0], dayStat2027)
        assertEquals(dayStatFlowList.first()[1], dayStat2024)
        assertEquals(dayStatFlowList.first()[2], dayStat2026)
        assertEquals(dayStatFlowList.first()[3], dayStat2025)

        val filterStatsByTimePeriodUseCase = FilterStatsByTimePeriodUseCase()

        val filteredDayStatList = filterStatsByTimePeriodUseCase.getYearlyStats(dayStatFlowList)

        assertEquals(filteredDayStatList.first()[0], dayStat2024)
        assertEquals(filteredDayStatList.first()[1], dayStat2025)
        assertEquals(filteredDayStatList.first()[2], dayStat2026)
        assertEquals(filteredDayStatList.first()[3], dayStat2027)
    }
}
