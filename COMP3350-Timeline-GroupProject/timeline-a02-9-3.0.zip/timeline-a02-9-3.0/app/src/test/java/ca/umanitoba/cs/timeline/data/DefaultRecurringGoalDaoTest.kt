package ca.umanitoba.cs.timeline.data

import app.cash.sqldelight.driver.jdbc.sqlite.JdbcSqliteDriver
import ca.umanitoba.cs.timeline.Database
import java.util.Properties
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import org.junit.jupiter.api.Tag

@Tag("integration")
class DefaultRecurringGoalDaoTest : RecurringGoalDaoTest() {
    override var goalId: Long = 0L

    override fun TestScope.provideRecurringGoalDao(): RecurringGoalDao {
        val driver =
            JdbcSqliteDriver(
                JdbcSqliteDriver.IN_MEMORY,
                Properties().apply { put("foreign_keys", "true") }
            )
        Database.Schema.create(driver)
        val database = Database(driver)

        database.goalQueries.insertGoal("Test Goal")
        database.goalQueries.insertGoal("Test Goal")
        database.goalQueries.insertGoal("Test Goal")
        goalId = database.goalQueries.selectLastRowId().executeAsOne()

        return DefaultRecurringGoalDao(
            database.recurringGoalQueries,
            StandardTestDispatcher(testScheduler)
        )
    }
}
