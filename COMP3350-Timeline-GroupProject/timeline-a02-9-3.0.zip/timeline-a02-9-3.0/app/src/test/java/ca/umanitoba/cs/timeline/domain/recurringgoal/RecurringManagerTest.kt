package ca.umanitoba.cs.timeline.domain.recurringgoal

import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import ca.umanitoba.cs.timeline.model.RecurringGoal
import io.mockk.MockKAnnotations
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.impl.annotations.MockK
import io.mockk.junit5.MockKExtension
import io.mockk.just
import io.mockk.mockk
import io.mockk.runs
import java.time.LocalDate
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith

@ExtendWith(MockKExtension::class)
@Tag("unit")
class RecurringManagerTest {

    @MockK private lateinit var recurringGoalRepository: RecurringGoalRepository

    @MockK private lateinit var goalRepository: GoalRepository

    @MockK private lateinit var taskRepository: TaskRepository

    @MockK private lateinit var recurringGoalManager: RecurringGoalManager

    @BeforeEach
    fun setup() {
        MockKAnnotations.init(this)
        recurringGoalManager =
            RecurringGoalManager(recurringGoalRepository, goalRepository, taskRepository)
        coEvery { goalRepository.getGoal(any()) } returns mockk(relaxed = true)
        coEvery { recurringGoalRepository.getRecurringGoal(any()) } returns mockk(relaxed = true)
        coEvery { taskRepository.getTasksForGoal(any()) } returns flowOf(emptyList())
        coEvery { taskRepository.getTaskCompletionForGoal(any()) } returns flowOf(Pair(0, 0))
        coEvery { goalRepository.addGoal(any()) } returns 2L
        coEvery { recurringGoalRepository.setRecurringGoal(any(), any(), any()) } just runs
        coEvery { goalRepository.updateGoal(any(), any(), any()) } just runs
        coEvery { taskRepository.addTask(any(), any()) } returns 2L
    }

    @Test
    fun `do not repeat goal and tasks if not all tasks are completed`() = runTest {
        val goalId = 1L
        val tasksCompletedStats = Pair(3, 5)

        coEvery { taskRepository.getTaskCompletionForGoal(goalId) } returns
            flowOf(tasksCompletedStats)

        recurringGoalManager.handleTaskCompletionForRecurringGoal(goalId)

        coVerify(exactly = 0) { goalRepository.addGoal(any()) }
        coVerify(exactly = 0) { recurringGoalRepository.setRecurringGoal(any(), any(), any()) }
    }

    @Test
    fun `do not repeat goal if it has already been repeated`() = runTest {
        val goalId = 1L
        val tasksCompletedStats = Pair(5, 5)

        coEvery { taskRepository.getTaskCompletionForGoal(goalId) } returns
            flowOf(tasksCompletedStats)
        coEvery { recurringGoalRepository.getRecurringGoal(goalId) } returns
            RecurringGoal(goalId, RecurrenceFrequency.Weekly, true)

        recurringGoalManager.handleTaskCompletionForRecurringGoal(goalId)

        coVerify(exactly = 0) { goalRepository.addGoal(any()) }
    }

    @Test
    fun `repeat goal and tasks when all tasks are completed and goal has not been repeated`() =
        runTest {
            val goalId = 1L
            val tasksCompletedStats = Pair(5, 5)
            val recurrenceFrequency = RecurrenceFrequency.Weekly

            coEvery { taskRepository.getTaskCompletionForGoal(goalId) } returns
                flowOf(tasksCompletedStats)
            coEvery { recurringGoalRepository.getRecurringGoal(goalId) } returns
                RecurringGoal(goalId, recurrenceFrequency, false)

            recurringGoalManager.handleTaskCompletionForRecurringGoal(goalId)

            coVerify(exactly = 1) { goalRepository.addGoal(any()) }
            coVerify(exactly = 1) {
                recurringGoalRepository.setRecurringGoal(goalId, recurrenceFrequency, true)
            }
        }

    @Test
    fun `ensure new goal and tasks are created with correct attributes when repeating`() = runTest {
        val originalGoalId = 1L
        val newGoalId = 2L
        val tasksCompletedStats = Pair(5, 5)
        val recurrenceFrequency = RecurrenceFrequency.Daily

        coEvery { taskRepository.getTaskCompletionForGoal(originalGoalId) } returns
            flowOf(tasksCompletedStats)
        coEvery { recurringGoalRepository.getRecurringGoal(originalGoalId) } returns
            RecurringGoal(originalGoalId, recurrenceFrequency, false)
        coEvery { goalRepository.addGoal(any()) } returns newGoalId
        coEvery { goalRepository.updateGoal(any(), any(), any()) } just runs
        coEvery { recurringGoalRepository.setRecurringGoal(originalGoalId, any(), true) } just runs
        coEvery {
            recurringGoalRepository.setRecurringGoal(newGoalId, recurrenceFrequency, false)
        } just runs
        coEvery { taskRepository.getTasksForGoal(originalGoalId) } returns
            flowOf(listOf(mockk(relaxed = true)))

        recurringGoalManager.handleTaskCompletionForRecurringGoal(originalGoalId)

        coVerify(exactly = 1) { goalRepository.addGoal(any()) }
        coVerify(exactly = 1) {
            recurringGoalRepository.setRecurringGoal(newGoalId, recurrenceFrequency, false)
        }
        coVerify(exactly = 1) { taskRepository.addTask(eq(newGoalId), any()) }
    }

    @Test
    fun `handleTaskCompletionForGoal repeats goal and tasks when all tasks are completed`() =
        runTest {
            val goalId = 1L
            val newGoalId = 2L
            val tasksCompletedStats = Pair(5, 5)
            val recurrenceFrequency = RecurrenceFrequency.Daily

            coEvery { taskRepository.getTaskCompletionForGoal(goalId) } returns
                flowOf(tasksCompletedStats)
            coEvery { goalRepository.getGoal(goalId) } returns
                mockk {
                    every { id } returns goalId
                    every { name } returns "Sample Goal"
                    every { deadline } returns LocalDate.of(2022, 1, 1)
                }
            coEvery { goalRepository.addGoal(any()) } returns newGoalId
            coEvery { taskRepository.getTasksForGoal(goalId) } returns
                flowOf(listOf(mockk(relaxed = true)))
            coEvery { taskRepository.addTask(any(), any()) } returns 3L
            coEvery { recurringGoalRepository.setRecurringGoal(any(), any(), true) } just runs
            coEvery {
                recurringGoalRepository.setRecurringGoal(newGoalId, recurrenceFrequency, false)
            } just runs

            recurringGoalManager.handleTaskCompletionForGoal(goalId, recurrenceFrequency)

            coVerify(exactly = 1) { goalRepository.addGoal(any()) }
            coVerify(exactly = 1) {
                recurringGoalRepository.setRecurringGoal(newGoalId, any(), false)
            }
            coVerify(atLeast = 1) { taskRepository.addTask(newGoalId, any()) }
        }
}
