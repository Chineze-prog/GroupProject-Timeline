package ca.umanitoba.cs.timeline.domain.goal

import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.domain.dayStatistic.DayStatisticRepository
import ca.umanitoba.cs.timeline.domain.recurringgoal.RecurringGoalRepository
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import java.time.LocalDate
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

abstract class DeleteGoalUseCaseTest {
    abstract fun TestScope.provideGoalRepository(): GoalRepository

    abstract fun TestScope.provideTaskRepository(): TaskRepository

    abstract fun TestScope.provideRecurringGoalRepository(): RecurringGoalRepository

    abstract fun TestScope.provideDayStatisticRepository(): DayStatisticRepository

    @Test
    fun `Goal and its tasks and statistics are deleted`() = runTest {
        val goalRepository = provideGoalRepository()
        val taskRepository = provideTaskRepository()
        val dayStatisticRepository = provideDayStatisticRepository()
        val recurringGoalRepository = provideRecurringGoalRepository()
        val deleteCase =
            DeleteGoalUseCase(
                goalRepository,
                recurringGoalRepository,
                taskRepository,
                dayStatisticRepository
            )

        val goal1 = goalRepository.addGoal("Goal 1")

        val task1 = taskRepository.addTask(goal1, "Task 1")
        val task2 = taskRepository.addTask(goal1, "Task 2")

        val date1 = LocalDate.of(2000, 10, 10)
        val date2 = LocalDate.of(2015, 7, 15)
        dayStatisticRepository.addDayStat(date1, goal1)
        dayStatisticRepository.addDayStat(date2, goal1)

        var goals = goalRepository.getGoals().first()
        var tasks = taskRepository.getTasks().first()
        var dayStats = dayStatisticRepository.getDayStats().first()

        assertEquals(1, goals.size)
        assertEquals("Goal 1", goals[0].name)

        assertEquals(2, tasks.size)
        assertEquals("Task 1", tasks[0].name)
        assertEquals("Task 2", tasks[1].name)

        assertEquals(2, dayStats.size)
        assertNotNull(dayStats[0])
        assertNotNull(dayStats[1])

        deleteCase(goal1)

        goals = goalRepository.getGoals().first()
        assertEquals(0, goals.size)
        assertNull(goalRepository.getGoal(goal1))

        tasks = taskRepository.getTasks().first()
        assertEquals(0, tasks.size)
        assertNull(taskRepository.getTask(task1))
        assertNull(taskRepository.getTask(task2))

        dayStats = dayStatisticRepository.getDayStats().first()
        assertEquals(0, dayStats.size)
        assertNull(dayStatisticRepository.getDayStatByGoalIdAndDate(date1, goal1))
        assertNull(dayStatisticRepository.getDayStatByGoalIdAndDate(date2, goal1))
    }

    @Test
    fun `Recurring goal is deleted along with the goal, its tasks, and statistics`() = runTest {
        val goalRepository = provideGoalRepository()
        val taskRepository = provideTaskRepository()
        val dayStatisticRepository = provideDayStatisticRepository()
        val recurringGoalRepository = provideRecurringGoalRepository()
        val deleteGoalUseCase =
            DeleteGoalUseCase(
                goalRepository,
                recurringGoalRepository,
                taskRepository,
                dayStatisticRepository
            )

        // Setting up a goal with tasks, day statistics, and marking it as a recurring goal
        val goalId = goalRepository.addGoal("Recurring Goal")

        taskRepository.addTask(goalId, "Task 1")
        taskRepository.addTask(goalId, "Task 2")

        val date1 = LocalDate.of(2020, 1, 1)
        val date2 = LocalDate.of(2020, 1, 2)
        dayStatisticRepository.addDayStat(date1, goalId)
        dayStatisticRepository.addDayStat(date2, goalId)

        recurringGoalRepository.setRecurringGoal(
            goalId,
            RecurrenceFrequency.Monthly,
            isRepeated = false
        )

        // Verify initial conditions
        assertNotNull(goalRepository.getGoal(goalId))
        assertEquals(2, taskRepository.getTasksForGoal(goalId).first().size)
        assertEquals(2, dayStatisticRepository.getDayStats().first().size)
        assertNotNull(recurringGoalRepository.getRecurringGoal(goalId))

        // Perform the deletion
        deleteGoalUseCase(goalId)

        // Assert that all related entities are deleted
        assertNull(goalRepository.getGoal(goalId))
        assertTrue(taskRepository.getTasksForGoal(goalId).first().isEmpty())
        assertTrue(dayStatisticRepository.getDayStats().first().isEmpty())
        assertNull(recurringGoalRepository.getRecurringGoal(goalId))
    }
}
