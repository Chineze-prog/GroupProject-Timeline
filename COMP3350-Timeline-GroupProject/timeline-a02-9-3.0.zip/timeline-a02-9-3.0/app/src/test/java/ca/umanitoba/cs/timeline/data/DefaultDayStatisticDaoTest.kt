package ca.umanitoba.cs.timeline.data

import app.cash.sqldelight.driver.jdbc.sqlite.JdbcSqliteDriver
import ca.umanitoba.cs.timeline.Database
import ca.umanitoba.cs.timeline.di.ZoneIdModule
import java.time.LocalDate
import java.util.Properties
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows

@Tag("integration")
class DefaultDayStatisticDaoTest : DayStatisticDaoTest() {
    override val goalIds: LongArray = longArrayOf(1, 2, 3)

    override fun TestScope.provideDayStatisticDao(): DayStatisticDao {
        val driver =
            JdbcSqliteDriver(
                JdbcSqliteDriver.IN_MEMORY,
                Properties().apply { put("foreign_keys", "true") }
            )
        Database.Schema.create(driver)
        val database = Database(driver)

        database.goalQueries.insertGoal("placeholder")
        database.goalQueries.insertGoal("placeholder")
        database.goalQueries.insertGoal("placeholder")

        return DefaultDayStatisticDao(
            database.dayStatisticQueries,
            ZoneIdModule.provideZoneId(),
            StandardTestDispatcher(testScheduler)
        )
    }

    @Test
    fun `Error on invalid goal reference`() = runTest {
        val dayStatDao = provideDayStatisticDao()
        assertThrows<Exception> { dayStatDao.addDayStat(LocalDate.now(), 999L) }
    }
}
