package ca.umanitoba.cs.timeline.domain.timer

import kotlin.time.Duration
import kotlin.time.Duration.Companion.ZERO
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds
import kotlin.time.ExperimentalTime
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.testTimeSource
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows

@ExperimentalCoroutinesApi
@ExperimentalTime
@Tag("unit")
class TimerUseCaseTest {
    companion object {
        private fun TestScope.createTimer(timeout: Duration, interval: Duration = 1.seconds) =
            TimerUseCase(timeout, this.testTimeSource, interval)
    }

    @Test
    fun sourceOnlyConstructsZeroTimer() = runTest {
        val timer = TimerUseCase(this.testTimeSource)
        assertEquals(ZERO, timer.state.value.initialTime)
    }

    @Test
    fun errorOnNegativeDuration() = runTest {
        assertThrows<IllegalArgumentException> { createTimer((-10).seconds) }

        assertThrows<IllegalArgumentException> { createTimer(ZERO).reset((-10).seconds) }
    }

    @Test
    fun constructInStoppedState() = runTest {
        val timer = createTimer(10.seconds)
        assertEquals(TimerState.State.PAUSED, timer.state.value.state)
        assertEquals(10.seconds, timer.state.value.remainingTime)
        assertEquals(10.seconds, timer.state.value.initialTime)
    }

    @Test
    fun wontStartWithDurationZero() = runTest {
        val timer = createTimer(ZERO)
        assertFalse(timer.start(this))
    }

    @Test
    fun tickOnStart() = runTest {
        val timer = createTimer(10.seconds)
        assertTrue(timer.start(this), "Timer did not start")
        testScheduler.runCurrent()
        assertEquals(TimerState.State.RUNNING, timer.state.value.state)
        assertEquals(10.seconds, timer.state.value.remainingTime)
        assertEquals(10.seconds, timer.state.value.initialTime)
    }

    @Test
    fun startAfterStart() = runTest {
        val timer = createTimer(10.seconds)
        assertTrue(timer.start(this), "Timer did not start")
        runCurrent()
        assertEquals(TimerState.State.RUNNING, timer.state.value.state)
        assertEquals(10.seconds, timer.state.value.remainingTime)
        assertEquals(10.seconds, timer.state.value.initialTime)
        assertTrue(timer.start(this), "Timer should say that it is running")
    }

    @Test
    fun periodicTick() = runTest {
        val interval = 1.seconds
        val timer = createTimer(10.seconds, interval)
        assertTrue(timer.start(this), "Timer did not start")

        runCurrent()
        // Verify initial state
        assertEquals(TimerState.State.RUNNING, timer.state.value.state)
        assertEquals(10.seconds, timer.state.value.remainingTime)
        assertEquals(10.seconds, timer.state.value.initialTime)

        delay(interval + 1.milliseconds)
        assertEquals(TimerState.State.RUNNING, timer.state.value.state)
        assertEquals(9.seconds, timer.state.value.remainingTime)
        assertEquals(10.seconds, timer.state.value.initialTime)

        delay(interval + 1.milliseconds)
        assertEquals(TimerState.State.RUNNING, timer.state.value.state)
        assertEquals(8.seconds, timer.state.value.remainingTime)
        assertEquals(10.seconds, timer.state.value.initialTime)
    }

    @Test
    fun stopSoonerThanInterval() = runTest {
        val timer = createTimer(500.milliseconds, interval = 1.seconds)
        assertTrue(timer.start(this), "Timer did not start")

        runCurrent()
        // Verify initial state
        assertEquals(TimerState.State.RUNNING, timer.state.value.state)
        assertEquals(500.milliseconds, timer.state.value.remainingTime)
        assertEquals(500.milliseconds, timer.state.value.initialTime)

        delay(501.milliseconds)
        assertEquals(TimerState.State.COMPLETED, timer.state.value.state)
        assertEquals(ZERO, timer.state.value.remainingTime)
        assertEquals(500.milliseconds, timer.state.value.initialTime)
    }

    @Test
    fun emitOnStopBeforeInterval() = runTest {
        val timer = createTimer(500.milliseconds, interval = 1.seconds)
        assertTrue(timer.start(this), "Timer did not start")

        runCurrent()
        // Verify initial state
        val initState = timer.state.value
        assertEquals(TimerState.State.RUNNING, initState.state)
        assertEquals(500.milliseconds, initState.remainingTime)
        assertEquals(500.milliseconds, timer.state.value.initialTime)

        delay(10.milliseconds)
        // Nothing should change before a tick
        assertEquals(initState, timer.state.value)

        timer.stop()
        runCurrent()
        assertEquals(TimerState.State.PAUSED, timer.state.value.state)
        assertEquals(490.milliseconds, timer.state.value.remainingTime)
        assertEquals(500.milliseconds, timer.state.value.initialTime)
    }

    @Test
    fun toggle() = runTest {
        val timer = createTimer(10.seconds)
        // Verify that timer is stopped
        assertEquals(TimerState.State.PAUSED, timer.state.value.state)
        timer.toggle(this)
        runCurrent()

        // Timer is started
        assertEquals(TimerState.State.RUNNING, timer.state.value.state)
        timer.toggle(this)

        // Timer is stopped
        testScheduler.advanceTimeBy(1.milliseconds)
        assertEquals(TimerState.State.PAUSED, timer.state.value.state)
    }

    @Test
    fun reset() = runTest {
        val interval = 1.seconds
        val timer = createTimer(10.seconds, interval)
        assertTrue(timer.start(this), "Timer did not start")

        runCurrent()
        // Verify initial state
        assertEquals(TimerState.State.RUNNING, timer.state.value.state)
        assertEquals(10.seconds, timer.state.value.remainingTime)
        assertEquals(10.seconds, timer.state.value.initialTime)

        delay(interval + 1.milliseconds)
        assertEquals(TimerState.State.RUNNING, timer.state.value.state)
        assertEquals(9.seconds, timer.state.value.remainingTime)
        assertEquals(10.seconds, timer.state.value.initialTime)

        timer.reset(25.seconds)
        assertEquals(TimerState.State.PAUSED, timer.state.value.state)
        assertEquals(25.seconds, timer.state.value.remainingTime)
        assertEquals(25.seconds, timer.state.value.initialTime)
    }
}
