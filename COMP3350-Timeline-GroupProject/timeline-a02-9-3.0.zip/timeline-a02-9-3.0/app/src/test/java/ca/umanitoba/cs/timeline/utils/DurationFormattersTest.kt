package ca.umanitoba.cs.timeline.utils

import kotlin.time.Duration.Companion.hours
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.nanoseconds
import kotlin.time.Duration.Companion.seconds
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test

@Tag("unit")
class FormatTimerDurationTest {
    @Test
    fun formatPositiveHour() {
        assertEquals("2:00:00", 2.hours.format())
        assertEquals("48:00:00", 48.hours.format())
    }

    @Test
    fun formatNegativeHour() {
        assertEquals("-2:12:01", ((-2).hours - 12.minutes - 1.seconds).format())
        assertEquals("-48:02:12", ((-48).hours - 2.minutes - 12.seconds).format())
    }

    @Test
    fun formatPositiveMinute() {
        assertEquals("2:00", 2.minutes.format())
        assertEquals("12:00", 12.minutes.format())
    }

    @Test
    fun formatNegativeMinute() {
        assertEquals("-2:05", ((-2).minutes - 5.seconds).format())
        assertEquals("-12:03", (-(12).minutes - 3.seconds).format())
    }

    @Test
    fun formatPositiveSecond() {
        assertEquals("2", (2.seconds).format())
        assertEquals("12", (12.seconds).format())
    }

    @Test
    fun formatNegativeSecond() {
        assertEquals("-2", ((-2).seconds).format())
        assertEquals("-12", ((-12).seconds).format())
    }

    @Test
    fun `format subsecond is rounded up`() {
        assertEquals("12", (11.seconds + 500000000.nanoseconds).format())
        assertEquals("2", (1.seconds + 500000000.nanoseconds).format())
        assertEquals("2:12", (2.minutes + 11.seconds + 500000000.nanoseconds).format())
        assertEquals("12:12", (12.minutes + 11.seconds + 999999999.nanoseconds).format())
    }

    @Test
    fun `format subsecond is rounded up to the next minute`() {
        assertEquals("2:00", (1.minutes + 59.seconds + 500000000.nanoseconds).format())
        assertEquals("12:00", (11.minutes + 59.seconds + 999999999.nanoseconds).format())
        assertEquals(
            "1:12:00",
            (1.hours + 11.minutes + 59.seconds + 999999999.nanoseconds).format()
        )
    }

    @Test
    fun `format subsecond is rounded up to the next hour`() {
        assertEquals("1:00:00", (59.minutes + 59.seconds + 500000000.nanoseconds).format())
        assertEquals(
            "12:00:00",
            (11.hours + 59.minutes + 59.seconds + 999999999.nanoseconds).format()
        )
    }

    @Test
    fun `format subsecond is rounded down`() {
        assertEquals("33", (33.seconds + 1.nanoseconds).format())

        assertEquals("33:59", (33.minutes + 59.seconds + 1.nanoseconds).format())

        assertEquals(
            "3:33:59",
            (3.hours + 33.minutes + 59.seconds + 499999999.nanoseconds).format()
        )
    }
}
