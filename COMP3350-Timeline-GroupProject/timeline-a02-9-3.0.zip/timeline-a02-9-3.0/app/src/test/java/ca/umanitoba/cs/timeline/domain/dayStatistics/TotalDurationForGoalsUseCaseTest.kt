package ca.umanitoba.cs.timeline.domain.dayStatistics

import ca.umanitoba.cs.timeline.domain.dayStatistic.TotalDurationForGoalsUseCase
import ca.umanitoba.cs.timeline.model.DayStatistic
import java.time.LocalDate
import java.time.Month
import kotlin.time.Duration.Companion.minutes
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test

@Tag("unit")
class TotalDurationForGoalsUseCaseTest {
    @Test
    fun goalDurationsAreTotaledByGoal() {
        val dayStat1 = DayStatistic(LocalDate.of(2020, Month.DECEMBER, 25), 0, 5.minutes)
        val dayStat2 = DayStatistic(LocalDate.of(2020, Month.DECEMBER, 25), 0, 52.minutes)
        val dayStat3 = DayStatistic(LocalDate.of(2020, Month.DECEMBER, 25), 1, 10.minutes)
        val dayStat4 = DayStatistic(LocalDate.of(2020, Month.DECEMBER, 25), 1, 22.minutes)
        val dayStat5 = DayStatistic(LocalDate.of(2020, Month.DECEMBER, 25), 2, 172.minutes)
        val dayStat6 = DayStatistic(LocalDate.of(2020, Month.DECEMBER, 25), 2, 44.minutes)

        val dayStatList = listOf(dayStat1, dayStat2, dayStat3, dayStat4, dayStat5, dayStat6)

        val totalDurationForGoalsUseCase = TotalDurationForGoalsUseCase()

        val totalDayStatDurations = totalDurationForGoalsUseCase(dayStatList)

        println(totalDayStatDurations[0])

        assertEquals(57f, totalDayStatDurations[0])
        assertEquals(32f, totalDayStatDurations[1])
        assertEquals(216f, totalDayStatDurations[2])
    }
}
