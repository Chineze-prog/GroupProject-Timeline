package ca.umanitoba.cs.timeline.data

import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

abstract class RecurringGoalDaoTest {
    abstract fun TestScope.provideRecurringGoalDao(): RecurringGoalDao

    abstract val goalId: Long

    @Test
    fun `setRecurringGoal should correctly toggle the isRepeated status`() = runTest {
        val recurringGoalDao = provideRecurringGoalDao()
        val frequency = RecurrenceFrequency.Weekly

        recurringGoalDao.setRecurringGoal(goalId, frequency, false)
        var recurringGoal = recurringGoalDao.getRecurringGoal(goalId)!!
        assertFalse(recurringGoal.isRepeated)

        recurringGoalDao.setRecurringGoal(goalId, frequency, true)
        recurringGoal = recurringGoalDao.getRecurringGoal(goalId)!!
        assertTrue(recurringGoal.isRepeated)
    }

    @Test
    fun `deleteRecurringGoal should not fail when goal does not exist`() = runTest {
        val dao = provideRecurringGoalDao()
        dao.deleteRecurringGoal(goalId)
        assertTrue(true, "deleteRecurringGoal completed without error")
    }

    @Test
    fun `setRecurringGoal should add or update a recurring goal correctly`() = runTest {
        val dao = provideRecurringGoalDao()
        val repeatFrequency = RecurrenceFrequency.Weekly

        dao.setRecurringGoal(goalId, repeatFrequency, false)
        var recurringGoal = dao.getRecurringGoal(goalId)

        assertNotNull(recurringGoal)
        assertEquals(goalId, recurringGoal?.goalId)
        assertEquals(repeatFrequency, recurringGoal?.repeatFrequency)
        assertFalse(recurringGoal?.isRepeated ?: true)

        dao.setRecurringGoal(goalId, repeatFrequency, true)
        recurringGoal = dao.getRecurringGoal(goalId)

        assertNotNull(recurringGoal)
        assertTrue(recurringGoal?.isRepeated ?: false)
    }

    @Test
    fun `deleteRecurringGoal should remove the recurring goal correctly`() = runTest {
        val dao = provideRecurringGoalDao()
        val frequency = RecurrenceFrequency.Daily
        dao.setRecurringGoal(goalId, frequency, false)
        assertNotNull(dao.getRecurringGoal(goalId))
        dao.deleteRecurringGoal(goalId)
        assertNull(dao.getRecurringGoal(goalId))
    }

    @Test
    fun `getRecurringGoals should return all recurring goals correctly`() = runTest {
        val dao = provideRecurringGoalDao()

        val goalId1 = 1L
        val goalId2 = 2L
        val frequency1 = RecurrenceFrequency.Daily
        val frequency2 = RecurrenceFrequency.Weekly
        dao.setRecurringGoal(goalId1, frequency1, false)
        dao.setRecurringGoal(goalId2, frequency2, true)

        val recurringGoals = dao.getRecurringGoals().first()
        assertNotNull(
            recurringGoals.find {
                it.goalId == goalId1 && it.repeatFrequency == frequency1 && !it.isRepeated
            }
        )
        assertNotNull(
            recurringGoals.find {
                it.goalId == goalId2 && it.repeatFrequency == frequency2 && it.isRepeated
            }
        )
        assertEquals(2, recurringGoals.size, "Should return exactly two recurring goals")
    }
}
