package ca.umanitoba.cs.timeline.data

import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertDoesNotThrow
import org.junit.jupiter.api.assertThrows

abstract class TaskDaoTest {
    /**
     * A set of goal ids that can be used in tests.
     *
     * At least 3 ids must be provided.
     */
    abstract val goalIds: LongArray

    abstract fun TestScope.provideTaskDao(): TaskDao

    @Test
    fun `Tasks can be added`() = runTest {
        val taskList = provideTaskDao()
        val tasks =
            taskList.getTasks().stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        delay(1.milliseconds) // Get stateIn coroutine to run
        assertTrue(tasks.value.isEmpty())
        val addedId = taskList.addTask(goalIds[0], "New task")
        val addedTask = taskList.getTask(addedId)!!
        assertEquals("New task", addedTask.name)
    }

    @Test
    fun `Tasks can have duplicated names within the same goal`() = runTest {
        val testName = "Duplicated"
        val taskList = provideTaskDao()
        taskList.addTask(goalIds[0], testName)
        taskList.addTask(goalIds[0], testName)
        assertEquals(
            2,
            taskList.getTasks().first().count { it.name == testName },
        )
    }

    @Test
    fun `Tasks can have duplicated names within the different goal`() = runTest {
        val testName = "Duplicated"
        val taskList = provideTaskDao()
        taskList.addTask(goalIds[0], testName)
        taskList.addTask(goalIds[0], testName)
        assertEquals(
            2,
            taskList.getTasks().first().count { it.name == testName },
        )
    }

    @Test
    fun `Tasks can be removed`() = runTest {
        val taskList = provideTaskDao()

        val tasks =
            taskList.getTasks().stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        delay(1.milliseconds) // Get stateIn coroutine to run
        assertTrue(tasks.value.isEmpty())

        val id = taskList.addTask(goalIds[0], "Ready to remove task")
        delay(1.milliseconds) // Get new data to propagate
        assertEquals(1, tasks.value.count())

        val currentTask = taskList.getTask(id)!!
        taskList.removeTask(currentTask.id)
        delay(1.milliseconds) // Get new data to propagate

        assertTrue(tasks.value.isEmpty())
    }

    @Test
    fun `Removing a task should not affect others tasks`() = runTest {
        val taskList = provideTaskDao()
        taskList.addTask(goalIds[0], "Task 1")
        taskList.addTask(goalIds[0], "Task 2")
        taskList.addTask(goalIds[0], "Task 3")

        val tasks =
            taskList.getTasks().stateIn(backgroundScope, SharingStarted.Eagerly, emptyList())
        delay(1.milliseconds) // Get stateIn coroutine to run

        // taskToRemove only have task2
        val taskToRemove = tasks.value.find { it.name == "Task 2" }!!
        val tasksWithoutTask2 = tasks.value.filterNot { it.id == taskToRemove.id }

        // taskList remove task2
        taskList.removeTask(taskToRemove.id)
        delay(1.milliseconds) // Get new data to propagate

        // Task 2 should be deleted in current taskList
        assertNull(taskList.getTask(taskToRemove.id))
        // List should be roughly equal to the one without Task 2
        assertEquals(tasksWithoutTask2, tasks.value)
    }

    @Test
    fun `Update task name should not affect completion`() = runTest {
        val taskList = provideTaskDao()
        val oldId = taskList.addTask(goalIds[0], "Old Task")
        val added = taskList.getTask(oldId)!!
        assertEquals("Old Task", added.name)

        val newName = "Updated Task"
        taskList.updateTask(added.id, name = newName)
        val updatedTask = taskList.getTask(added.id)!!
        assertEquals(newName, updatedTask.name)
        assertFalse(updatedTask.isCompleted)

        taskList.updateTask(added.id, completed = true)
        assertTrue(taskList.getTask(added.id)!!.isCompleted)

        val newerName = "Updated (again)"
        taskList.updateTask(added.id, name = newerName)
        val updatedTask2 = taskList.getTask(added.id)!!
        assertEquals(newerName, updatedTask2.name)
        assertTrue(updatedTask2.isCompleted)
    }

    @Test
    fun `Update completion status works`() = runTest {
        val taskList = provideTaskDao()
        val id = taskList.addTask(goalIds[0], "Incomplete")
        val task = taskList.getTask(id)!!
        assertEquals("Incomplete", task.name)

        taskList.updateTask(task.id, completed = true)
        assertTrue(taskList.getTask(task.id)!!.isCompleted)

        taskList.updateTask(task.id, completed = false)
        assertFalse(taskList.getTask(task.id)!!.isCompleted)
    }

    @Test
    fun `Attempting to Update a non-exist task with name`() = runTest {
        val taskList = provideTaskDao()
        val nonExistentTaskId = 999L
        val newName = "Non-exist Task"
        assertDoesNotThrow { taskList.updateTask(nonExistentTaskId, name = newName) }
    }

    @Test
    fun `Attempting to update a non-exist task with completion state`() = runTest {
        val taskList = provideTaskDao()
        val nonExistentTaskId = 999L
        assertDoesNotThrow { taskList.updateTask(nonExistentTaskId, completed = true) }
    }

    @Test
    fun `Read the last task from an empty list will returns null`() = runTest {
        val taskList = provideTaskDao()
        assertTrue(taskList.getTasks().first().isEmpty())
    }

    @Test
    fun `Move task upwards works`() = runTest {
        val taskList = provideTaskDao()

        val firstTaskId = taskList.addTask(goalIds[0], "First task")
        val secondTaskId = taskList.addTask(goalIds[0], "Second task")
        val thirdTaskId = taskList.addTask(goalIds[0], "Third task")

        val tasks = taskList.getTasksForGoal(goalIds[0]).first()
        assertEquals(listOf(firstTaskId, secondTaskId, thirdTaskId), tasks.map { it.id })
        taskList.moveTask(thirdTaskId, firstTaskId)

        val movedTasks = taskList.getTasksForGoal(goalIds[0]).first()
        assertEquals(listOf(thirdTaskId, firstTaskId, secondTaskId), movedTasks.map { it.id })
    }

    @Test
    fun `Move task downwards works`() = runTest {
        val taskList = provideTaskDao()

        val firstTaskId = taskList.addTask(goalIds[0], "First task")
        val secondTaskId = taskList.addTask(goalIds[0], "Second task")
        val thirdTaskId = taskList.addTask(goalIds[0], "Third task")

        val tasks = taskList.getTasksForGoal(goalIds[0]).first()
        assertEquals(listOf(firstTaskId, secondTaskId, thirdTaskId), tasks.map { it.id })
        taskList.moveTask(firstTaskId, thirdTaskId)

        val movedTasks = taskList.getTasksForGoal(goalIds[0]).first()
        assertEquals(listOf(secondTaskId, thirdTaskId, firstTaskId), movedTasks.map { it.id })
    }

    @Test
    fun `Moving tasks in different goals is an error`() = runTest {
        val taskList = provideTaskDao()

        val firstTaskId = taskList.addTask(goalIds[0], "First task")
        val secondTaskId = taskList.addTask(goalIds[1], "Second task")

        assertThrows<Exception> { taskList.moveTask(secondTaskId, firstTaskId) }
    }

    @Test
    fun `Moving non-existent tasks is an error`() = runTest {
        val taskList = provideTaskDao()

        val firstTaskId = taskList.addTask(goalIds[0], "First task")

        assertThrows<Exception> { taskList.moveTask(firstTaskId, 999L) }
    }

    @Test
    fun `getTasksByGoal yields just tasks associated with that goal`() = runTest {
        val taskList = provideTaskDao()

        taskList.addTask(goalIds[0], "first")
        taskList.addTask(goalIds[1], "second")
        taskList.addTask(goalIds[2], "third")

        assertEquals(listOf("first"), taskList.getTasksForGoal(goalIds[0]).first().map { it.name })
        assertEquals(listOf("second"), taskList.getTasksForGoal(goalIds[1]).first().map { it.name })
        assertEquals(listOf("third"), taskList.getTasksForGoal(goalIds[2]).first().map { it.name })
    }

    @Test
    fun `time is added to tasks`() = runTest {
        val taskList = provideTaskDao()
        val task1 = taskList.addTask(goalIds[0], "Task 1")
        val task2 = taskList.addTask(goalIds[0], "Task 2")
        val task3 = taskList.addTask(goalIds[0], "Task 3")

        assertEquals(0.seconds, taskList.getTask(task1)!!.timeSpent)
        assertEquals(0.seconds, taskList.getTask(task2)!!.timeSpent)
        assertEquals(0.seconds, taskList.getTask(task3)!!.timeSpent)

        taskList.addTimeToTask(task2, 2.seconds)

        assertEquals(0.seconds, taskList.getTask(task1)!!.timeSpent)
        assertEquals(2.seconds, taskList.getTask(task2)!!.timeSpent)
        assertEquals(0.seconds, taskList.getTask(task3)!!.timeSpent)

        taskList.addTimeToTask(task2, 3.seconds)

        assertEquals(0.seconds, taskList.getTask(task1)!!.timeSpent)
        assertEquals(5.seconds, taskList.getTask(task2)!!.timeSpent)
        assertEquals(0.seconds, taskList.getTask(task3)!!.timeSpent)

        taskList.addTimeToTask(task3, 4.seconds)

        assertEquals(0.seconds, taskList.getTask(task1)!!.timeSpent)
        assertEquals(5.seconds, taskList.getTask(task2)!!.timeSpent)
        assertEquals(4.seconds, taskList.getTask(task3)!!.timeSpent)
    }

    @Test
    fun `getTaskCompletionForGoal returns correct pair of integers`() = runTest {
        val taskList = provideTaskDao()

        taskList.addTask(goalIds[0], "first")
        taskList.addTask(goalIds[1], "second")
        val thirdId = taskList.addTask(goalIds[1], "third")
        val fourthId = taskList.addTask(goalIds[2], "fourth")
        val fifthId = taskList.addTask(goalIds[2], "fifth")
        val sixthId = taskList.addTask(goalIds[2], "sixth")

        taskList.updateTask(thirdId, "third", true)
        taskList.updateTask(fourthId, "fourth", true)
        taskList.updateTask(fifthId, "fifth", true)
        taskList.updateTask(sixthId, "sixth", true)

        assertEquals(Pair(0, 1), taskList.getTaskCompletionForGoal(goalIds[0]).first())
        assertEquals(Pair(1, 2), taskList.getTaskCompletionForGoal(goalIds[1]).first())
        assertEquals(Pair(3, 3), taskList.getTaskCompletionForGoal(goalIds[2]).first())
    }

    @Test
    fun `getTaskCompletionForGoal returns correct pair for non existent goals`() = runTest {
        val taskList = provideTaskDao()

        assertEquals(Pair(0, 0), taskList.getTaskCompletionForGoal(999L).first())
    }

    @Test
    fun `getTaskCompletionForGoal updates counts`() = runTest {
        val taskList = provideTaskDao()

        assertEquals(Pair(0, 0), taskList.getTaskCompletionForGoal(goalIds[0]).first())

        taskList.addTask(goalIds[0], "first")
        taskList.addTask(goalIds[0], "second")
        val thirdId = taskList.addTask(goalIds[1], "third")
        val fourthId = taskList.addTask(goalIds[1], "fourth")
        val fifthId = taskList.addTask(goalIds[1], "fifth")
        taskList.addTask(goalIds[2], "sixth")

        assertEquals(Pair(0, 2), taskList.getTaskCompletionForGoal(goalIds[0]).first())

        taskList.updateTask(thirdId, "third", true)
        taskList.updateTask(fourthId, "fourth", true)
        taskList.updateTask(fifthId, "fifth", true)

        assertEquals(Pair(3, 3), taskList.getTaskCompletionForGoal(goalIds[1]).first())
    }
}
