package ca.umanitoba.cs.timeline.domain.goal

import ca.umanitoba.cs.timeline.domain.dayStatistic.DayStatisticRepository
import ca.umanitoba.cs.timeline.domain.dayStatistic.InvalidDayStatisticException
import java.time.Clock
import java.time.LocalDate
import java.time.Month
import java.time.ZoneOffset
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertDoesNotThrow
import org.junit.jupiter.api.assertThrows

abstract class AddGoalTimeUseCaseTest {
    abstract fun TestScope.provideGoalRepository(): GoalRepository

    abstract fun TestScope.provideDayStatisticRepository(): DayStatisticRepository

    @Test
    fun `invalid date for day statistic throws an exception`() = runTest {
        val goalRepository = provideGoalRepository()
        val dayStatisticRepository = provideDayStatisticRepository()
        val fixedClock =
            Clock.fixed(
                LocalDate.of(2024, Month.MAY, 22).atStartOfDay().toInstant(ZoneOffset.UTC),
                ZoneOffset.UTC
            )
        val addTimeCase = AddGoalTimeUseCase(goalRepository, dayStatisticRepository, fixedClock)

        val goal1 = goalRepository.addGoal("Goal 1")

        assertThrows<InvalidDayStatisticException>("Invalid date for statistics") {
            addTimeCase(goal1, LocalDate.of(2025, Month.JANUARY, 13), 15.seconds)
        }
    }

    @Test
    fun `current date for day statistic does not throw an exception`() = runTest {
        val goalRepository = provideGoalRepository()
        val dayStatisticRepository = provideDayStatisticRepository()
        val fixedClock =
            Clock.fixed(
                LocalDate.of(2024, Month.MAY, 22).atStartOfDay().toInstant(ZoneOffset.UTC),
                ZoneOffset.UTC
            )
        val addTimeCase = AddGoalTimeUseCase(goalRepository, dayStatisticRepository, fixedClock)

        val goal1 = goalRepository.addGoal("Goal 1")

        assertDoesNotThrow { addTimeCase(goal1, LocalDate.of(2024, Month.MAY, 22), 15.seconds) }
    }

    @Test
    fun `date before current date for day statistic does not throw an exception`() = runTest {
        val goalRepository = provideGoalRepository()
        val dayStatisticRepository = provideDayStatisticRepository()
        val fixedClock =
            Clock.fixed(
                LocalDate.of(2024, Month.MAY, 22).atStartOfDay().toInstant(ZoneOffset.UTC),
                ZoneOffset.UTC
            )
        val addTimeCase = AddGoalTimeUseCase(goalRepository, dayStatisticRepository, fixedClock)

        val goal1 = goalRepository.addGoal("Goal 1")

        assertDoesNotThrow { addTimeCase(goal1, LocalDate.of(2015, Month.DECEMBER, 8), 15.seconds) }
    }

    @Test
    fun `day statistic is created if nonexistent`() = runTest {
        val goalRepository = provideGoalRepository()
        val dayStatisticRepository = provideDayStatisticRepository()
        val fixedClock =
            Clock.fixed(
                LocalDate.of(2024, Month.MAY, 22).atStartOfDay().toInstant(ZoneOffset.UTC),
                ZoneOffset.UTC
            )
        val addTimeCase = AddGoalTimeUseCase(goalRepository, dayStatisticRepository, fixedClock)

        val goal1 = goalRepository.addGoal("Goal 1")
        val date = LocalDate.of(2020, Month.JANUARY, 20)

        assertEquals(1, goalRepository.getGoals().first().count())
        assertEquals(0, dayStatisticRepository.getDayStats().first().count())

        addTimeCase(goal1, date, 15.seconds)

        assertEquals(1, goalRepository.getGoals().first().count())
        assertEquals(1, dayStatisticRepository.getDayStats().first().count())
    }

    @Test
    fun `day statistic is not created if already present`() = runTest {
        val goalRepository = provideGoalRepository()
        val dayStatisticRepository = provideDayStatisticRepository()
        val fixedClock =
            Clock.fixed(
                LocalDate.of(2024, Month.MAY, 22).atStartOfDay().toInstant(ZoneOffset.UTC),
                ZoneOffset.UTC
            )
        val addTimeCase = AddGoalTimeUseCase(goalRepository, dayStatisticRepository, fixedClock)

        val goal1 = goalRepository.addGoal("Goal 1")
        val date = LocalDate.of(2020, Month.JANUARY, 20)

        assertEquals(1, goalRepository.getGoals().first().count())
        assertEquals(0, dayStatisticRepository.getDayStats().first().count())

        addTimeCase(goal1, date, 15.seconds)

        assertEquals(1, goalRepository.getGoals().first().count())
        assertEquals(1, dayStatisticRepository.getDayStats().first().count())

        addTimeCase(goal1, date, 30.seconds)

        assertEquals(1, goalRepository.getGoals().first().count())
        assertEquals(1, dayStatisticRepository.getDayStats().first().count())
    }

    @Test
    fun `time is added to both goal and day statistic`() = runTest {
        val goalRepository = provideGoalRepository()
        val dayStatisticRepository = provideDayStatisticRepository()
        val fixedClock =
            Clock.fixed(
                LocalDate.of(2024, Month.MAY, 22).atStartOfDay().toInstant(ZoneOffset.UTC),
                ZoneOffset.UTC
            )
        val addTimeCase = AddGoalTimeUseCase(goalRepository, dayStatisticRepository, fixedClock)

        val goal1 = goalRepository.addGoal("Goal 1")
        val date = LocalDate.of(2020, Month.JANUARY, 20)

        assertEquals(1, goalRepository.getGoals().first().count())
        assertEquals(0, dayStatisticRepository.getDayStats().first().count())

        addTimeCase(goal1, date, 15.seconds)

        assertEquals(1, goalRepository.getGoals().first().count())
        assertEquals(1, dayStatisticRepository.getDayStats().first().count())
        assertEquals(15.seconds, goalRepository.getGoal(goal1)?.unallocatedTimeSpent)
        assertEquals(
            15.seconds,
            dayStatisticRepository.getDayStatByGoalIdAndDate(date, goal1)?.timeSpent
        )
    }
}
