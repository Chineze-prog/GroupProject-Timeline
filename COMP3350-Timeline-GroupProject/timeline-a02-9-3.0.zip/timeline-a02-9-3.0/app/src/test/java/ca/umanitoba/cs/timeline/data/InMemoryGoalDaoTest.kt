package ca.umanitoba.cs.timeline.data

import kotlinx.coroutines.test.TestScope
import org.junit.jupiter.api.Tag

@Tag("unit")
class InMemoryGoalDaoTest : GoalDaoTest() {
    override fun TestScope.provideGoalDao(): GoalDao = InMemoryGoalDao()
}
