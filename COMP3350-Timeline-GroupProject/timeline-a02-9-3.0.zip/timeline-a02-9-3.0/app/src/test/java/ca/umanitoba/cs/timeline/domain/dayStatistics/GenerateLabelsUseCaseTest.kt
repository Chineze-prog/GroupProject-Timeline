package ca.umanitoba.cs.timeline.domain.dayStatistics

import ca.umanitoba.cs.timeline.domain.dayStatistic.GenerateLabelsUseCase
import ca.umanitoba.cs.timeline.model.DayStatistic
import java.time.LocalDate
import java.time.Month
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test

@Tag("unit")
class GenerateLabelsUseCaseTest {
    @Test
    fun generateMonthLabels() {
        val dataMap = mutableMapOf<String, List<Float>>()
        dataMap["January"] = listOf(4f, 12f, 40f)
        dataMap["February"] = listOf(180f, 125f, 98f)
        dataMap["March"] = listOf(23f, 79f, 45f)
        dataMap["May"] = listOf(61f, 151f, 18f)
        dataMap["July"] = listOf(28f, 6f, 58f)
        dataMap["October"] = listOf(38f, 212f, 340f)
        dataMap["November"] = listOf(90f, 63f, 78f)

        val generateLabelsUseCase = GenerateLabelsUseCase()
        val labels = generateLabelsUseCase.generateMonthLabels(dataMap)

        assertEquals("Jan", labels[0])
        assertEquals("Feb", labels[1])
        assertEquals("Mar", labels[2])
        assertEquals("May", labels[3])
        assertEquals("Jul", labels[4])
        assertEquals("Oct", labels[5])
        assertEquals("Nov", labels[6])
    }

    @Test
    fun generateYearLabels() {
        val dayStat2024 = DayStatistic(LocalDate.of(2024, Month.FEBRUARY, 14), 0)
        val dayStat2025 = DayStatistic(LocalDate.of(2025, Month.FEBRUARY, 14), 0)
        val dayStat2027 = DayStatistic(LocalDate.of(2027, Month.FEBRUARY, 14), 0)
        val dayStat2027Repeat = DayStatistic(LocalDate.of(2027, Month.JULY, 7), 0)
        val dayStat2030 = DayStatistic(LocalDate.of(2030, Month.FEBRUARY, 14), 0)

        val dayStatList =
            listOf(dayStat2024, dayStat2025, dayStat2027, dayStat2027Repeat, dayStat2030)

        val generateLabelsUseCase = GenerateLabelsUseCase()

        val labels = generateLabelsUseCase.generateYearLabels(dayStatList)

        assertEquals(4, labels.size)
        assertEquals("2024", labels[0])
        assertEquals("2025", labels[1])
        assertEquals("2027", labels[2])
        assertEquals("2030", labels[3])
    }
}
