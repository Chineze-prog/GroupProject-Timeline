package ca.umanitoba.cs.timeline.data

import java.time.LocalDate
import java.time.Month
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

abstract class GoalDaoTest {
    abstract fun TestScope.provideGoalDao(): GoalDao

    @Test
    fun `addGoal should add a goal correctly`() = runTest {
        val repository = provideGoalDao()
        val goalName = "Test Goal"
        repository.addGoal(goalName)
        val goals = repository.getGoals().first()
        assertEquals(1, goals.size)
        assertEquals(goalName, goals[0].name)
    }

    @Test
    fun `deleteGoal should remove the goal correctly`() = runTest {
        val repository = provideGoalDao()
        val goalName = "Goal to Delete"
        val goalId = repository.addGoal(goalName)
        repository.deleteGoal(goalId)
        val goals = repository.getGoals().first()
        assertTrue(goals.isEmpty())
    }

    @Test
    fun `updateGoalName should change the goal's name`() = runTest {
        val repository = provideGoalDao()
        val originalName = "Original Name"
        val newName = "New Name"
        val goalId = repository.addGoal(originalName)
        repository.updateGoal(goalId, name = newName)
        val goal = repository.getGoal(goalId)
        assertEquals(newName, goal?.name)
    }

    @Test
    fun `getGoalById should return the correct goal`() = runTest {
        val repository = provideGoalDao()
        val goalName = "Specific Goal"
        val goalId = repository.addGoal(goalName)
        val goal = repository.getGoal(goalId)
        assertEquals(goalName, goal?.name)
    }

    @Test
    fun `getObservableGoal should update when goal name is changed`() = runTest {
        val dao = provideGoalDao()
        val goalId = dao.addGoal("Test")
        val observed = dao.getObservableGoal(goalId)
        assertEquals("Test", observed.first().name)

        dao.updateGoal(goalId, "New name")
        assertEquals("New name", observed.first().name)
    }

    @Test
    fun `deadline can be added to a goal`() = runTest {
        val repository = provideGoalDao()
        val date = LocalDate.of(2024, Month.JUNE, 25)
        val goal = repository.addGoal("Goal")

        assertEquals(null, repository.getGoal(goal)?.deadline ?: null)
        repository.updateGoal(goal, deadline = date)
        assertEquals(date, repository.getGoal(goal)?.deadline)
    }

    @Test
    fun `an existing goal deadline can be changed`() = runTest {
        val repository = provideGoalDao()
        val date1 = LocalDate.of(2024, Month.MAY, 21)
        val date2 = LocalDate.of(2024, Month.APRIL, 29)
        val goal = repository.addGoal("Goal")

        repository.updateGoal(goal, deadline = date1)
        assertEquals(date1, repository.getGoal(goal)?.deadline)

        repository.updateGoal(goal, deadline = date2)
        assertEquals(date2, repository.getGoal(goal)?.deadline)
    }

    @Test
    fun `an existing goal deadline can be removed`() = runTest {
        val repository = provideGoalDao()
        val date = LocalDate.of(2024, Month.MAY, 21)
        val goal = repository.addGoal("Goal")

        repository.updateGoal(goal, deadline = date)
        assertEquals(date, repository.getGoal(goal)?.deadline)

        repository.removeGoalDeadline(goal)
        assertEquals(null, repository.getGoal(goal)?.deadline ?: null)
    }

    @Test
    fun `time is added to a goal`() = runTest {
        val repository = provideGoalDao()
        val goal1 = repository.addGoal("Goal 1")
        val goal2 = repository.addGoal("Goal 2")
        val goal3 = repository.addGoal("Goal 3")

        assertEquals(0.seconds, repository.getGoal(goal1)!!.unallocatedTimeSpent)
        assertEquals(0.seconds, repository.getGoal(goal2)!!.unallocatedTimeSpent)
        assertEquals(0.seconds, repository.getGoal(goal3)!!.unallocatedTimeSpent)

        repository.addTimeToGoal(goal1, 2.seconds)

        assertEquals(2.seconds, repository.getGoal(goal1)!!.unallocatedTimeSpent)
        assertEquals(0.seconds, repository.getGoal(goal2)!!.unallocatedTimeSpent)
        assertEquals(0.seconds, repository.getGoal(goal3)!!.unallocatedTimeSpent)

        repository.addTimeToGoal(goal1, 3.seconds)

        assertEquals(5.seconds, repository.getGoal(goal1)!!.unallocatedTimeSpent)
        assertEquals(0.seconds, repository.getGoal(goal2)!!.unallocatedTimeSpent)
        assertEquals(0.seconds, repository.getGoal(goal3)!!.unallocatedTimeSpent)

        repository.addTimeToGoal(goal3, 10.seconds)

        assertEquals(5.seconds, repository.getGoal(goal1)!!.unallocatedTimeSpent)
        assertEquals(0.seconds, repository.getGoal(goal2)!!.unallocatedTimeSpent)
        assertEquals(10.seconds, repository.getGoal(goal3)!!.unallocatedTimeSpent)
    }

    @Test
    fun `unallocated time is converted to allocated time`() = runTest {
        val repository = provideGoalDao()
        val goal1 = repository.addGoal("Goal 1")
        val goal2 = repository.addGoal("Goal 2")
        val goal3 = repository.addGoal("Goal 3")

        assertEquals(0.seconds, repository.getGoal(goal1)!!.allocatedTimeSpent)
        assertEquals(0.seconds, repository.getGoal(goal2)!!.allocatedTimeSpent)
        assertEquals(0.seconds, repository.getGoal(goal3)!!.allocatedTimeSpent)

        repository.addTimeToGoal(goal3, 2.seconds)

        assertEquals(0.seconds, repository.getGoal(goal1)!!.allocatedTimeSpent)
        assertEquals(0.seconds, repository.getGoal(goal2)!!.allocatedTimeSpent)
        assertEquals(0.seconds, repository.getGoal(goal3)!!.allocatedTimeSpent)

        repository.allocateTime(goal3)

        assertEquals(0.seconds, repository.getGoal(goal1)!!.allocatedTimeSpent)
        assertEquals(0.seconds, repository.getGoal(goal2)!!.allocatedTimeSpent)
        assertEquals(2.seconds, repository.getGoal(goal3)!!.allocatedTimeSpent)
    }
}
