package ca.umanitoba.cs.timeline

import org.junit.platform.suite.api.IncludeTags
import org.junit.platform.suite.api.SelectPackages
import org.junit.platform.suite.api.Suite
import org.junit.platform.suite.api.SuiteDisplayName

@Suite
@SuiteDisplayName("Unit tests")
@SelectPackages("ca.umanitoba.cs.timeline")
@IncludeTags("unit")
class UnitTestSuite
