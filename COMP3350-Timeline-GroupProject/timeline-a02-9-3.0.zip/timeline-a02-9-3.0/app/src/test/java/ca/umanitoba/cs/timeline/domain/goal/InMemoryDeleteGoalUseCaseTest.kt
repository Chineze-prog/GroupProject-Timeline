package ca.umanitoba.cs.timeline.domain.goal

import ca.umanitoba.cs.timeline.data.InMemoryDayStatisticDao
import ca.umanitoba.cs.timeline.data.InMemoryGoalDao
import ca.umanitoba.cs.timeline.data.InMemoryRecurringGoalDao
import ca.umanitoba.cs.timeline.data.InMemoryTaskDao
import ca.umanitoba.cs.timeline.domain.dayStatistic.DayStatisticRepository
import ca.umanitoba.cs.timeline.domain.dayStatistic.DefaultDayStatisticRepository
import ca.umanitoba.cs.timeline.domain.recurringgoal.DefaultRecurringGoalRepository
import ca.umanitoba.cs.timeline.domain.recurringgoal.RecurringGoalRepository
import ca.umanitoba.cs.timeline.domain.task.DefaultTaskRepository
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import kotlinx.coroutines.test.TestScope
import org.junit.jupiter.api.Tag

@Tag("unit")
class InMemoryDeleteGoalUseCaseTest : DeleteGoalUseCaseTest() {
    override fun TestScope.provideGoalRepository(): GoalRepository {
        return DefaultGoalRepository(InMemoryGoalDao())
    }

    override fun TestScope.provideTaskRepository(): TaskRepository {
        return DefaultTaskRepository(InMemoryTaskDao())
    }

    override fun TestScope.provideDayStatisticRepository(): DayStatisticRepository {
        return DefaultDayStatisticRepository(InMemoryDayStatisticDao())
    }

    override fun TestScope.provideRecurringGoalRepository(): RecurringGoalRepository {
        return DefaultRecurringGoalRepository(InMemoryRecurringGoalDao())
    }
}
