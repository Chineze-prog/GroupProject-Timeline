package ca.umanitoba.cs.timeline.domain.goal

import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import ca.umanitoba.cs.timeline.model.Goal
import io.mockk.coEvery
import io.mockk.impl.annotations.MockK
import io.mockk.junit5.MockKExtension
import java.time.Clock
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith

@ExtendWith(MockKExtension::class)
@Tag("unit")
class CategorizeAndSortGoalsUseCaseTest {
    @MockK private lateinit var repository: TaskRepository

    private lateinit var fixedClock: Clock
    private lateinit var categorizeAndSortGoalsUseCase: CategorizeAndSortGoalsUseCase

    @BeforeEach
    fun setup() {
        fixedClock = Clock.fixed(Instant.parse("2024-05-22T00:00:00Z"), ZoneOffset.UTC)
        categorizeAndSortGoalsUseCase = CategorizeAndSortGoalsUseCase(fixedClock, repository)
        coEvery { repository.getTaskCompletionForGoal(less(9L)) } returns
            MutableStateFlow(Pair(0, 0)).asStateFlow()
        coEvery { repository.getTaskCompletionForGoal(9) } returns
            MutableStateFlow(Pair(5, 5)).asStateFlow()
    }

    @Test
    fun `goals are correctly categorized and sorted by deadlines`() = runTest {
        val goals =
            listOf(
                Goal(id = 1, name = "Future Goal", deadline = LocalDate.of(2024, 5, 23)),
                Goal(id = 2, name = "Today Goal", deadline = LocalDate.of(2024, 5, 22)),
                Goal(id = 3, name = "Past Goal", deadline = LocalDate.of(2024, 5, 21)),
                Goal(id = 4, name = "No Deadline Goal", deadline = null),
                Goal(id = 9, name = "Completed", deadline = LocalDate.of(2024, 5, 21))
            )

        val categorizedGoals = categorizeAndSortGoalsUseCase(goals)

        assertEquals(CategorizeAndSortGoalsUseCase.CATEGORY_NO_DEADLINE, categorizedGoals[0].first)
        assertEquals(CategorizeAndSortGoalsUseCase.CATEGORY_PAST_DUE, categorizedGoals[1].first)
        assertEquals(CategorizeAndSortGoalsUseCase.CATEGORY_DUE_TODAY, categorizedGoals[2].first)
        assertEquals(
            CategorizeAndSortGoalsUseCase.CATEGORY_DAYS_LEFT + "1",
            categorizedGoals[3].first
        )
        assertEquals(CategorizeAndSortGoalsUseCase.CATEGORY_COMPLETED, categorizedGoals[4].first)
    }

    @Test
    fun `sorting an empty list returns an empty categorization`() = runTest {
        val goals = emptyList<Goal>()

        val categorizedGoals = categorizeAndSortGoalsUseCase(goals)

        assertTrue(categorizedGoals.isEmpty())
    }

    @Test
    fun `goals within each category are correctly sorted by deadline`() = runTest {
        val goals =
            listOf(
                Goal(id = 1, name = "Future Goal 1", deadline = LocalDate.of(2024, 5, 25)),
                Goal(id = 2, name = "Future Goal 2", deadline = LocalDate.of(2024, 5, 24)),
                Goal(id = 3, name = "Past Goal 1", deadline = LocalDate.of(2024, 5, 21)),
                Goal(id = 4, name = "Past Goal 2", deadline = LocalDate.of(2024, 5, 20))
            )

        val categorizedGoals = categorizeAndSortGoalsUseCase(goals)

        val pastDueCategory =
            categorizedGoals.first { it.first == CategorizeAndSortGoalsUseCase.CATEGORY_PAST_DUE }
        assertEquals("Past Goal 2", pastDueCategory.second.first().name)
        assertEquals("Past Goal 1", pastDueCategory.second[1].name)

        val daysLeftCategory =
            categorizedGoals
                .filter { it.first.startsWith(CategorizeAndSortGoalsUseCase.CATEGORY_DAYS_LEFT) }
                .flatMap { it.second }

        assertEquals("Future Goal 2", daysLeftCategory.first().name)
        assertEquals("Future Goal 1", daysLeftCategory[1].name)
    }

    @Test
    fun `goals with the same deadline are correctly categorized together`() = runTest {
        val sameDeadline = LocalDate.of(2024, 5, 23)
        val goals =
            listOf(
                Goal(id = 1, name = "Goal A", deadline = sameDeadline),
                Goal(id = 2, name = "Goal B", deadline = sameDeadline)
            )

        val categorizedGoals = categorizeAndSortGoalsUseCase(goals)
        val daysLeftCategory =
            categorizedGoals.first {
                it.first.startsWith(CategorizeAndSortGoalsUseCase.CATEGORY_DAYS_LEFT)
            }

        assertEquals(2, daysLeftCategory.second.size)
        assertTrue(daysLeftCategory.second.map { it.name }.containsAll(listOf("Goal A", "Goal B")))
    }

    @Test
    fun `multiple goals within each category are ordered and grouped correctly`() = runTest {
        val goals =
            listOf(
                Goal(id = 1, name = "Past Goal 1", deadline = LocalDate.of(2024, 5, 20)),
                Goal(id = 2, name = "Past Goal 2", deadline = LocalDate.of(2024, 5, 19)),
                Goal(id = 3, name = "Today Goal 1", deadline = LocalDate.of(2024, 5, 22)),
                Goal(id = 4, name = "Today Goal 2", deadline = LocalDate.of(2024, 5, 22)),
                Goal(id = 5, name = "Future Goal 1", deadline = LocalDate.of(2024, 5, 23)),
                Goal(id = 6, name = "Future Goal 2", deadline = LocalDate.of(2024, 5, 24)),
                Goal(id = 7, name = "No Deadline Goal 1", deadline = null),
                Goal(id = 8, name = "No Deadline Goal 2", deadline = null)
            )

        val categorizedGoals = categorizeAndSortGoalsUseCase(goals)

        val allDaysLeftGoals =
            categorizedGoals
                .filter { it.first.startsWith(CategorizeAndSortGoalsUseCase.CATEGORY_DAYS_LEFT) }
                .flatMap { it.second }

        categorizedGoals.forEach { (category, goalsInCategory) ->
            when (category) {
                CategorizeAndSortGoalsUseCase.CATEGORY_PAST_DUE -> {
                    assertEquals(2, goalsInCategory.size)
                    assertEquals(goalsInCategory[0].name, "Past Goal 2")
                }
                CategorizeAndSortGoalsUseCase.CATEGORY_DUE_TODAY -> {
                    assertEquals(2, goalsInCategory.size)
                    assertEquals(goalsInCategory[0].name, "Today Goal 1")
                }
                CategorizeAndSortGoalsUseCase.CATEGORY_NO_DEADLINE -> {
                    assertEquals(2, goalsInCategory.size)
                    assertEquals(goalsInCategory[0].name, "No Deadline Goal 1")
                }
            }
        }

        assertEquals(allDaysLeftGoals.first().name, "Future Goal 1")
    }
}
