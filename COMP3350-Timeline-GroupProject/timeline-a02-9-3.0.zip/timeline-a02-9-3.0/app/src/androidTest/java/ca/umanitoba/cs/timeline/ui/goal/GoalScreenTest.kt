package ca.umanitoba.cs.timeline.ui.goal

import ca.umanitoba.cs.timeline.test.ui.goal.BaseGoalScreenTest
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest

@HiltAndroidTest
class GoalScreenTest : BaseGoalScreenTest() {
    override val hiltRule: HiltAndroidRule = HiltAndroidRule(this)
}
