package ca.umanitoba.cs.timeline.ui.statistics

import ca.umanitoba.cs.timeline.test.ui.statistics.BaseStatisticsScreenTest
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest

@HiltAndroidTest
class StatisticsScreenTest : BaseStatisticsScreenTest() {
    override val hiltRule: HiltAndroidRule = HiltAndroidRule(this)
}
