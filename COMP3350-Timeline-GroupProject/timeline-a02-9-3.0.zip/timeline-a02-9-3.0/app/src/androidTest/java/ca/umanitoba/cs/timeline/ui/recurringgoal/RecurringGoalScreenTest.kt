package ca.umanitoba.cs.timeline.ui.recurringgoal

import ca.umanitoba.cs.timeline.test.ui.recurringgoal.BaseRecurringGoalTest
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest

@HiltAndroidTest
class RecurringGoalScreenTest : BaseRecurringGoalTest() {
    override val hiltRule: HiltAndroidRule = HiltAndroidRule(this)
}
