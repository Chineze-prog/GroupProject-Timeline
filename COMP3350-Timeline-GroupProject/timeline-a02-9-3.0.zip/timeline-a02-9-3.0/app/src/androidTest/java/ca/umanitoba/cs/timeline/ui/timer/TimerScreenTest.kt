package ca.umanitoba.cs.timeline.ui.timer

import ca.umanitoba.cs.timeline.test.ui.timer.BaseTimerScreenTest
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import kotlin.time.Duration

@HiltAndroidTest
class TimerScreenTest : BaseTimerScreenTest() {
    override val hiltRule: HiltAndroidRule = HiltAndroidRule(this)

    override fun skipTime(duration: Duration) {
        // Does nothing, only required for robolectric
    }
}
