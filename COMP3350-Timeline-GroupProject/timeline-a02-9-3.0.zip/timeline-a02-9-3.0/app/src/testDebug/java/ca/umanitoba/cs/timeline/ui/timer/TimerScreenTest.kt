package ca.umanitoba.cs.timeline.ui.timer

import androidx.test.ext.junit.runners.AndroidJUnit4
import ca.umanitoba.cs.timeline.test.ui.timer.BaseTimerScreenTest
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import dagger.hilt.android.testing.HiltTestApplication
import kotlin.time.Duration
import kotlin.time.toJavaDuration
import org.junit.Before
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLog
import org.robolectric.shadows.ShadowSystemClock

@RunWith(AndroidJUnit4::class)
@Config(application = HiltTestApplication::class)
@HiltAndroidTest
class TimerScreenTest : BaseTimerScreenTest() {
    override val hiltRule: HiltAndroidRule = HiltAndroidRule(this)

    @Before
    fun setupLog() {
        ShadowLog.stream = System.out
    }

    override fun skipTime(duration: Duration) {
        ShadowSystemClock.advanceBy(duration.toJavaDuration())
    }
}
