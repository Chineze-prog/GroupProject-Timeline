package ca.umanitoba.cs.timeline.ui.statistics

import androidx.test.ext.junit.runners.AndroidJUnit4
import ca.umanitoba.cs.timeline.test.ui.statistics.BaseStatisticsScreenTest
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import dagger.hilt.android.testing.HiltTestApplication
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(AndroidJUnit4::class)
@Config(application = HiltTestApplication::class)
@HiltAndroidTest
class StatisticsScreenTest : BaseStatisticsScreenTest() {
    override val hiltRule: HiltAndroidRule = HiltAndroidRule(this)
}
