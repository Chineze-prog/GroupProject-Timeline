package ca.umanitoba.cs.timeline

import ca.umanitoba.cs.timeline.ui.goal.GoalScreenTest
import ca.umanitoba.cs.timeline.ui.timer.TimerScreenTest
import org.junit.runner.RunWith
import org.junit.runners.Suite
import org.junit.runners.Suite.SuiteClasses

@RunWith(Suite::class)
@SuiteClasses(TimerScreenTest::class, GoalScreenTest::class)
class RobolectricTestSuite
