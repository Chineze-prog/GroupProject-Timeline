package ca.umanitoba.cs.timeline.domain.timer

import kotlin.time.Duration

data class PomodoroState(
    val duration: Duration = Duration.ZERO,
    val state: State = State.POMODORO,
    val numberOfCompletedCycles: Int = 0,
) {
    enum class State {
        POMODORO,
        SHORT_BREAK,
        LONG_BREAK
    }
}
