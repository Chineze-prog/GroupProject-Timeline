package ca.umanitoba.cs.timeline.domain.dayStatistic

class InvalidDayStatisticException(message: String) : Exception(message)
