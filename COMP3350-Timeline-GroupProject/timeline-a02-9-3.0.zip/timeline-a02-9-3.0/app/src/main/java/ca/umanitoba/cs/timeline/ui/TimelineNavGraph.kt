package ca.umanitoba.cs.timeline.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import ca.umanitoba.cs.timeline.ui.goals.goalScreen
import ca.umanitoba.cs.timeline.ui.statistics.navigateToStatistics
import ca.umanitoba.cs.timeline.ui.statistics.statisticsScreen
import ca.umanitoba.cs.timeline.ui.timer.navigateToTimer
import ca.umanitoba.cs.timeline.ui.timer.timerScreen

@Composable
fun TimelineNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = "goals") {
        goalScreen(
            onNavigateToTimer = { navController.navigateToTimer(it) },
            onNavigateToStatistics = { navController.navigateToStatistics() }
        )
        timerScreen()
        statisticsScreen()
    }
}
