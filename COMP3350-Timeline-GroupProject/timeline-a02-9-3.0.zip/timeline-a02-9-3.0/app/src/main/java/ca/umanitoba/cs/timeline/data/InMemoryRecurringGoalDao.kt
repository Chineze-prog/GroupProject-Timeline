package ca.umanitoba.cs.timeline.data

import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.model.RecurringGoal
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class InMemoryRecurringGoalDao @Inject constructor() : RecurringGoalDao {
    private val recurringGoals = MutableStateFlow<List<RecurringGoal>>(emptyList())

    override suspend fun setRecurringGoal(
        goalId: Long,
        repeatFrequency: RecurrenceFrequency,
        isRepeated: Boolean,
    ) {
        val newRecurringGoal =
            RecurringGoal(
                goalId = goalId,
                repeatFrequency = repeatFrequency,
                isRepeated = isRepeated,
            )
        recurringGoals.update { currentGoals ->
            currentGoals.filterNot { it.goalId == goalId } + newRecurringGoal
        }
    }

    override suspend fun deleteRecurringGoal(goalId: Long) {
        recurringGoals.update { it.filterNot { goal -> goal.goalId == goalId } }
    }

    override suspend fun getRecurringGoal(goalId: Long): RecurringGoal? =
        recurringGoals.value.find { it.goalId == goalId }

    override fun getRecurringGoals(): Flow<List<RecurringGoal>> = recurringGoals.asStateFlow()
}
