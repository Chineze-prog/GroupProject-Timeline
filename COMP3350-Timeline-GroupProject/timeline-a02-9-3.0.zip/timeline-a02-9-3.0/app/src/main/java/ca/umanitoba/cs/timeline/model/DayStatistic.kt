package ca.umanitoba.cs.timeline.model

import java.time.LocalDate
import kotlin.time.Duration

data class DayStatistic(
    val date: LocalDate,
    val goalId: Long,
    val timeSpent: Duration = Duration.ZERO
)
