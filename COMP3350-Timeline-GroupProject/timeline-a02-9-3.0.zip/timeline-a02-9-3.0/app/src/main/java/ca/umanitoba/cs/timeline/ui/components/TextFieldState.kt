package ca.umanitoba.cs.timeline.ui.components

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue

class TextFieldState(value: TextFieldValue, isError: Boolean = false) {
    constructor(
        text: String,
        selection: TextRange = TextRange.Zero,
        isError: Boolean = false
    ) : this(TextFieldValue(text, selection), isError)

    var value: TextFieldValue by mutableStateOf(value)
    var isError: Boolean by mutableStateOf(isError)
}
