package ca.umanitoba.cs.timeline.utils

import java.time.LocalDate
import java.time.format.DateTimeFormatter

object DateUtils {

    private val dateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("MMMM dd, yyyy")
    /**
     * Converts a LocalDate to a String representation using the defined format.
     *
     * @param localDate The LocalDate to convert.
     * @return A String representation of the LocalDate in the format "MMMM dd, yyyy".
     */
    fun localDateToString(localDate: LocalDate): String {
        return localDate.format(dateFormat)
    }
}
