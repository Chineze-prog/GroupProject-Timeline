package ca.umanitoba.cs.timeline.domain.timer

import javax.inject.Inject
import kotlin.time.Duration

/**
 * Keeps track of time collected from a total amount of time passed.
 *
 * To be used with [timePassed] value in [TimerState].
 */
class CollectTimeUseCase(private var timeCollected: Duration = Duration.ZERO) {
    @Inject constructor() : this(Duration.ZERO)

    /**
     * Collect the time from total time passed that has not been collected
     *
     * @param time The total amount of time that has passed
     * @return the time that has not been previously collected
     */
    operator fun invoke(time: Duration): Duration {
        val newTime = time - timeCollected
        timeCollected += newTime
        return newTime
    }

    /**
     * Resets how much time has been collected.
     *
     * To be used when total time passed is also reset.
     */
    fun resetCollectedTime() {
        timeCollected = Duration.ZERO
    }
}
