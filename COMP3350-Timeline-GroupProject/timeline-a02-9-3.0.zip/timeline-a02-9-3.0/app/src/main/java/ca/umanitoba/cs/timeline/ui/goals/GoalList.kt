package ca.umanitoba.cs.timeline.ui.goals

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.model.Goal
import ca.umanitoba.cs.timeline.model.RecurringGoal
import ca.umanitoba.cs.timeline.model.Task
import ca.umanitoba.cs.timeline.ui.components.LengthRestrictedTextField
import ca.umanitoba.cs.timeline.ui.components.TextFieldState
import ca.umanitoba.cs.timeline.utils.DateUtils
import java.text.DateFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.Date
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoalListUI(
    goals: List<Goal>,
    date: Date,
    recurringGoals: List<RecurringGoal>,
    onNavigateToTimer: (Long) -> Unit,
    onNavigateToStatistics: () -> Unit,
    viewModel: GoalViewModel,
    onRemoveGoal: (Long) -> Unit,
    onUpdateGoal: (Long, String, LocalDate?) -> Unit,
    onUpdateGoalDeadline: (Long, LocalDate?) -> Unit,
    onRemoveGoalDeadline: (Long) -> Unit,
    onRemoveRecurringGoal: (Long) -> Unit,
    onSetRecurringGoal: (Long, RecurrenceFrequency) -> Unit,
    modifier: Modifier = Modifier
) {
    var showUpdateDialog by remember { mutableStateOf(false) }
    var showDeadlineDialog by remember { mutableStateOf(false) }
    var initGoalName by remember { mutableStateOf("") }
    var editingGoalId by remember { mutableLongStateOf(-1L) }
    var initGoalDeadline: LocalDate? by remember { mutableStateOf(null) }

    // A buffer to buffer changes to goals until database has been updated
    var goalsBuffer by remember(goals) { mutableStateOf(goals) }

    val sortedGoals by viewModel.goalsByDeadlines.collectAsState(initial = emptyList())

    Column(
        modifier = modifier.fillMaxWidth().fillMaxHeight(0.9f).padding(16.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Column(
            modifier = modifier.padding(start = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = DateFormat.getDateInstance(DateFormat.LONG).format(date),
                style = MaterialTheme.typography.bodySmall,
                modifier = modifier
            )
            Text(
                text = "Have a productive day!",
                style = MaterialTheme.typography.bodyLarge,
                modifier = modifier
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Your Current Goals",
                        style = MaterialTheme.typography.headlineLarge,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
                Box { Button(onClick = onNavigateToStatistics) { Text(text = "Statistics") } }
            }
        }

        LazyColumn(modifier = modifier) {
            sortedGoals.forEach { (category, goalsInCategory) ->
                item {
                    Text(
                        text = category,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
                goalsInCategory.forEach { goal ->
                    item(key = goal.id) {
                        val stats =
                            viewModel
                                .getTaskCompletionStats(goal.id)
                                .collectAsState(initial = Pair(0, 0))
                        val percentCompleted: Int =
                            if (stats.value.second > 0) {
                                ((stats.value.first.toFloat() / stats.value.second) * 100)
                                    .roundToInt()
                            } else {
                                0
                            }

                        val matchingRecurringGoal = recurringGoals.find { it.goalId == goal.id }

                        GoalItem(
                            goal = goal,
                            onNavigateToTimer = { onNavigateToTimer(goal.id) },
                            onUpdateGoalClick = {
                                editingGoalId = goal.id
                                initGoalName = goal.name
                                showUpdateDialog = true
                            },
                            onRemoveGoalClick = {
                                goalsBuffer = goalsBuffer.filterNot { it.id == goal.id }
                                onRemoveGoal(goal.id)
                            },
                            onDeadlineGoalClick = {
                                editingGoalId = goal.id
                                initGoalDeadline = goal.deadline
                                showDeadlineDialog = true
                            },
                            percentCompleted = percentCompleted,
                            modifier = Modifier.fillMaxWidth(),
                            frequency = matchingRecurringGoal?.repeatFrequency,
                            onFrequencySelected = { frequency ->
                                onSetRecurringGoal(goal.id, frequency)
                            }
                        )
                    }
                }
            }
        }
    }
    if (showUpdateDialog) {
        GoalAlertDialog(
            initialName = initGoalName,
            onDismissRequest = { showUpdateDialog = false },
            title = "Edit Goal",
            onConfirm = { newName ->
                onUpdateGoal(editingGoalId, newName, initGoalDeadline)
                showUpdateDialog = false
            },
        )
    }

    if (showDeadlineDialog) {

        val datePickerState =
            rememberDatePickerState(
                initialSelectedDateMillis =
                    initGoalDeadline?.atStartOfDay(ZoneOffset.UTC)?.toInstant()?.toEpochMilli()
            )

        var confirmDeadlineRemoval by remember { mutableStateOf(false) }

        DatePickerDialog(
            onDismissRequest = { showDeadlineDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedDate: LocalDate? =
                            datePickerState.selectedDateMillis?.let { date ->
                                Instant.ofEpochMilli(date).atZone(ZoneOffset.UTC).toLocalDate()
                            }!!

                        onUpdateGoalDeadline(editingGoalId, selectedDate)

                        if (!viewModel.getGoalEditDialogueState().showErrorDialogue) {
                            showDeadlineDialog = false
                        }
                    },
                    enabled = datePickerState.selectedDateMillis != null
                ) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDeadlineRemoval = true }) { Text("Cancel/Remove") }
            }
        ) {
            DatePicker(state = datePickerState)
        }

        if (confirmDeadlineRemoval) {
            AlertDialog(
                title = { Text(text = "Remove Current Deadline", textAlign = TextAlign.Center) },
                onDismissRequest = { confirmDeadlineRemoval = false },
                confirmButton = {
                    Button(
                        onClick = {
                            onRemoveGoalDeadline(editingGoalId)
                            onRemoveRecurringGoal(editingGoalId)
                            confirmDeadlineRemoval = false
                            showDeadlineDialog = false
                        }
                    ) {
                        Text("YES")
                    }
                },
                dismissButton = {
                    Button(
                        onClick = {
                            confirmDeadlineRemoval = false
                            showDeadlineDialog = false
                        }
                    ) {
                        Text("NO")
                    }
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoalItem(
    goal: Goal,
    onNavigateToTimer: () -> Unit,
    onRemoveGoalClick: () -> Unit,
    onUpdateGoalClick: () -> Unit,
    onDeadlineGoalClick: () -> Unit,
    percentCompleted: Int,
    modifier: Modifier,
    frequency: RecurrenceFrequency?,
    onFrequencySelected: (RecurrenceFrequency) -> Unit,
) {
    val dismissState = rememberSwipeToDismissBoxState(positionalThreshold = { it * 0.4f })
    val displayFrequency = frequency?.name ?: "No Recurrence"
    val displayDeadline = goal.deadline?.let { DateUtils.localDateToString(goal.deadline) }
    var showFrequencyMenu by remember { mutableStateOf(false) }

    LaunchedEffect(dismissState.currentValue, dismissState.progress) {
        if (
            dismissState.currentValue != SwipeToDismissBoxValue.Settled &&
                dismissState.progress > 0.9f
        ) {
            onRemoveGoalClick()
            dismissState.snapTo(SwipeToDismissBoxValue.Settled)
        }
    }

    SwipeToDismissBox(
        dismissState,
        backgroundContent = {
            Box(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Icon(Icons.Rounded.Delete, contentDescription = "Delete")
            }
        },
        modifier = modifier,
        enableDismissFromStartToEnd = false
    ) {
        ListItem(
            headlineContent = {
                Column {
                    Box {
                        val status =
                            if (percentCompleted == 100) {
                                "Completed"
                            } else {
                                "In Progress"
                            }
                        Text(text = status, style = MaterialTheme.typography.labelLarge)
                    }
                    Text(text = goal.name, style = MaterialTheme.typography.headlineSmall)
                    if (frequency != null) {
                        Text(
                            text = "Frequency: $displayFrequency",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (displayDeadline != null) {
                        Text(
                            text = "Deadline: $displayDeadline",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            supportingContent = {
                Text(
                    text = "${percentCompleted}% Complete",
                    style = MaterialTheme.typography.labelMedium
                )
            },
            trailingContent = {
                Row {
                    Spacer(modifier = Modifier.width(12.dp))

                    FloatingActionButton(onClick = onDeadlineGoalClick) {
                        Icon(Icons.Filled.DateRange, "Deadline")
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    FloatingActionButton(onClick = { showFrequencyMenu = true }) {
                        Icon(Icons.Filled.Refresh, "Frequency")
                    }
                    DropdownMenu(
                        expanded = showFrequencyMenu,
                        onDismissRequest = { showFrequencyMenu = (false) }
                    ) {
                        RecurrenceFrequency.entries.forEach { frequency ->
                            DropdownMenuItem(
                                onClick = {
                                    onFrequencySelected(frequency)
                                    showFrequencyMenu = false
                                },
                                text = {
                                    Text(
                                        text = frequency.name,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))

                    FloatingActionButton(onClick = onUpdateGoalClick) {
                        Icon(Icons.Filled.Edit, "Edit")
                    }
                }
            },
            modifier = Modifier.clickable(onClickLabel = "View Tasks", onClick = onNavigateToTimer)
        )
    }
}

@Composable
fun GoalAlertDialog(
    initialName: String,
    title: String,
    onDismissRequest: () -> Unit,
    onConfirm: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val taskNameField = remember {
        TextFieldState(initialName, selection = TextRange(initialName.length))
    }

    AlertDialog(
        title = { Text(title) },
        text = {
            val focusRequester = remember { FocusRequester() }

            LengthRestrictedTextField(
                taskNameField,
                onValueChange = { taskNameField.value = it },
                limits = Task.NAME_LENGTH_LIMITS,
                label = { Text("Goal Name*") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                modifier = Modifier.focusRequester(focusRequester)
            )

            LaunchedEffect(Unit) { focusRequester.requestFocus() }
        },
        onDismissRequest = onDismissRequest,
        confirmButton = {
            Button(
                onClick = { onConfirm(taskNameField.value.text) },
                enabled = !taskNameField.isError
            ) {
                Text("Confirm")
            }
        },
        dismissButton = { Button(onClick = onDismissRequest) { Text("Cancel") } },
        modifier = modifier
    )
}
