package ca.umanitoba.cs.timeline.domain.goal

import ca.umanitoba.cs.timeline.domain.timer.InvalidDeadlineException
import java.time.Clock
import java.time.LocalDate
import javax.inject.Inject

/**
 * Checks that the new deadline to be added to a goal is either a current or future date.
 *
 * Updates the goal's deadline if the deadline is valid and throws an exception otherwise
 */
class UpdateGoalUseCase
@Inject
constructor(private val goalRepository: GoalRepository, private val clock: Clock) {

    suspend operator fun invoke(id: Long, name: String? = null, deadline: LocalDate? = null) {

        val currentDate = LocalDate.now(clock)

        // checks that the deadline is not null and is a current or future date
        if (deadline != null && deadline < currentDate) {
            throw InvalidDeadlineException("Invalid Deadline")
        } else {
            goalRepository.updateGoal(id, name, deadline)
            // sametime to update the recurring endDate }
        }
    }
}
