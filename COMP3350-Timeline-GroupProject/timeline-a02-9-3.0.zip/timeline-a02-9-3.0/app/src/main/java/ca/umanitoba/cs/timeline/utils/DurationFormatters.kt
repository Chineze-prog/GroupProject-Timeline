package ca.umanitoba.cs.timeline.utils

import kotlin.math.abs
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

fun Duration.format() =
    toComponents { seconds, nanoseconds ->
            // Round seconds up when above half a second to avoid information loss since we don't
            // display sub-seconds
            if (nanoseconds >= 500000000) (seconds + 1).seconds else seconds.seconds
        }
        .toComponents { hours, minutes, seconds, _ ->
            when {
                hours != 0L -> String.format("%d:%02d:%02d", hours, abs(minutes), abs(seconds))
                minutes != 0 -> String.format("%d:%02d", minutes, abs(seconds))
                else -> String.format("%d", seconds)
            }
        }
