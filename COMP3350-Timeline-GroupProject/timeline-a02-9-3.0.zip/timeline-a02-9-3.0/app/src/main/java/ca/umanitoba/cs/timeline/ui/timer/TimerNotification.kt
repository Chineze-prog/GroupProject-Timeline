package ca.umanitoba.cs.timeline.ui.timer

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun TimerNotification(
    onDismissRequest: () -> Unit,
    dialogTitle: String,
    dialogText: String,
) {
    AlertDialog(
        title = { Text(text = dialogTitle) },
        text = { Text(text = dialogText) },
        onDismissRequest = onDismissRequest,
        confirmButton = { TextButton(onClick = onDismissRequest) { Text("Dismiss") } }
    )
}

@Preview(showBackground = true)
@Composable
fun PreviewTimerNotification() {
    TimerNotification({}, "The timer has ended", "You may now take a break")
}
