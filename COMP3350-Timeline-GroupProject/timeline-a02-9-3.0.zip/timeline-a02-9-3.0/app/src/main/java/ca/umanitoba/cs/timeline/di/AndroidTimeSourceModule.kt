package ca.umanitoba.cs.timeline.di

import ca.umanitoba.cs.timeline.utils.AndroidRealTimeSource
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlin.time.TimeSource

/** Module providing TimeSource dependency */
@Module
@InstallIn(SingletonComponent::class)
internal interface AndroidTimeSourceModule {
    @Binds fun bindAndroidTimeSource(source: AndroidRealTimeSource): TimeSource
}
