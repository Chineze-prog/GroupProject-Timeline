package ca.umanitoba.cs.timeline.model

import kotlin.time.Duration

data class Task(
    val goalId: Long,
    val id: Long,
    val name: String,
    val isCompleted: Boolean = false,
    val timeSpent: Duration = Duration.ZERO
) {
    companion object {
        val NAME_LENGTH_LIMITS = 1..100
    }
}
