package ca.umanitoba.cs.timeline.data

import app.cash.sqldelight.coroutines.asFlow
import app.cash.sqldelight.coroutines.mapToList
import app.cash.sqldelight.coroutines.mapToOne
import ca.umanitoba.cs.timeline.GoalQueries
import ca.umanitoba.cs.timeline.di.Dispatcher
import ca.umanitoba.cs.timeline.di.TimelineDispatchers.IO
import ca.umanitoba.cs.timeline.model.Goal
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import javax.inject.Inject
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.DurationUnit
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class DefaultGoalDao
@Inject
constructor(
    private val goalQueries: GoalQueries,
    private val zoneId: ZoneId,
    @Dispatcher(IO) private val ioDispatcher: CoroutineDispatcher
) : GoalDao {

    override fun getGoals(): Flow<List<Goal>> =
        goalQueries.selectAll().asFlow().mapToList(ioDispatcher).map { goals ->
            goals.map { goal ->
                Goal(
                    goal.id,
                    goal.name,
                    goal.deadline?.let { date ->
                        Instant.ofEpochSecond(date).atZone(zoneId).toLocalDate()
                    },
                    goal.unallocatedTime.milliseconds,
                    goal.allocatedTime.milliseconds,
                )
            }
        }

    override suspend fun addGoal(name: String): Long =
        withContext(ioDispatcher) {
            goalQueries.transactionWithResult {
                goalQueries.insertGoal(name)
                goalQueries.selectLastRowId().executeAsOne()
            }
        }

    override suspend fun updateGoal(id: Long, name: String?, deadline: LocalDate?): Unit =
        withContext(ioDispatcher) {
            goalQueries.transaction {
                name?.let { goalQueries.updateGoalName(name, id) }
                deadline?.let {
                    goalQueries.updateGoalDeadline(
                        deadline = deadline.atStartOfDay(zoneId)?.toEpochSecond(),
                        id = id
                    )
                }
            }
        }

    override suspend fun removeGoalDeadline(id: Long) {
        withContext(ioDispatcher) {
            goalQueries.transaction { goalQueries.updateGoalDeadline(null, id) }
        }
    }

    override suspend fun deleteGoal(id: Long) =
        withContext(ioDispatcher) { goalQueries.deleteGoal(id) }

    override suspend fun getGoal(id: Long): Goal? =
        withContext(ioDispatcher) {
            goalQueries.selectGoalById(id).executeAsOneOrNull()?.let {
                Goal(
                    it.id,
                    it.name,
                    it.deadline?.let { date ->
                        Instant.ofEpochSecond(date).atZone(zoneId).toLocalDate()
                    },
                    it.unallocatedTime.milliseconds,
                    it.allocatedTime.milliseconds,
                )
            }
        }

    override fun getObservableGoal(id: Long): Flow<Goal> =
        goalQueries.selectGoalById(id).asFlow().mapToOne(ioDispatcher).map {
            Goal(
                it.id,
                it.name,
                it.deadline?.let { date ->
                    Instant.ofEpochSecond(date).atZone(zoneId).toLocalDate()
                },
                it.unallocatedTime.milliseconds,
                it.allocatedTime.milliseconds
            )
        }

    override suspend fun addTimeToGoal(id: Long, time: Duration) {
        val timeLong: Long = time.toLong(DurationUnit.MILLISECONDS)
        withContext(ioDispatcher) {
            goalQueries.transaction { goalQueries.addUnallocatedTime(timeLong, id) }
        }
    }

    override suspend fun allocateTime(id: Long) {
        withContext(ioDispatcher) { goalQueries.transaction { goalQueries.allocateTime(id) } }
    }
}
