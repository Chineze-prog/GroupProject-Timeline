package ca.umanitoba.cs.timeline.ui.statistics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ca.umanitoba.cs.timeline.domain.dayStatistic.DayStatisticRepository
import ca.umanitoba.cs.timeline.domain.dayStatistic.FilterStatsByTimePeriodUseCase
import ca.umanitoba.cs.timeline.domain.dayStatistic.GenerateLabelsUseCase
import ca.umanitoba.cs.timeline.domain.dayStatistic.TotalDurationForGoalsUseCase
import ca.umanitoba.cs.timeline.domain.dayStatistic.TransformStatisticsUseCase
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.model.DayStatistic
import com.patrykandpatrick.vico.core.model.CartesianChartModelProducer
import com.patrykandpatrick.vico.core.model.lineSeries
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.transform
import kotlinx.coroutines.launch

@HiltViewModel
class StatisticsViewModel
@Inject
constructor(
    private val generateLabelsUseCase: GenerateLabelsUseCase,
    private val totalDurationForGoalsUseCase: TotalDurationForGoalsUseCase,
    private val transformStatisticsUseCase: TransformStatisticsUseCase,
    private val dayStatisticRepository: DayStatisticRepository,
    private val goalRepository: GoalRepository,
    private val filterStatsByTimePeriodUseCase: FilterStatsByTimePeriodUseCase
) : ViewModel() {

    private val _timeModelProducer = MutableStateFlow<CartesianChartModelProducer?>(null)
    val timeModelProducer: StateFlow<CartesianChartModelProducer?> = _timeModelProducer

    private val _goalModelProducer = MutableStateFlow<CartesianChartModelProducer?>(null)
    val goalModelProducer: StateFlow<CartesianChartModelProducer?> = _goalModelProducer

    private val _dayLabels = MutableStateFlow<List<String>>(emptyList())
    val dayLabels: StateFlow<List<String>> = _dayLabels

    private val _goalLabels = MutableStateFlow<List<String>>(emptyList())
    val goalLabels: StateFlow<List<String>> = _goalLabels

    private val _labelMode = MutableStateFlow(GraphState.WEEKLY)

    init {
        _timeModelProducer.value = CartesianChartModelProducer.build()
    }

    private val currentDay: LocalDate = LocalDate.now()

    private val currentWeekStats: Flow<List<DayStatistic>> =
        filterStatsByTimePeriodUseCase.getWeeklyStats(
            dayStatisticRepository.getDayStats(),
            currentDay
        )

    private val currentMonthStats: Flow<List<DayStatistic>> =
        filterStatsByTimePeriodUseCase.getMonthlyStats(
            dayStatisticRepository.getDayStats(),
            currentDay
        )

    private val currentYearStats: Flow<List<DayStatistic>> =
        filterStatsByTimePeriodUseCase.getYearlyStats(dayStatisticRepository.getDayStats())

    private val currentStats =
        _labelMode.transform {
            when (it) {
                GraphState.WEEKLY -> emitAll(currentWeekStats)
                GraphState.MONTHLY -> emitAll(currentMonthStats)
                GraphState.YEARLY -> emitAll(currentYearStats)
            }
        }

    fun setGraphState(graphState: GraphState) {
        _labelMode.value = graphState
        updateGoalChart(currentStats)
        updateChartData(currentStats)
    }

    private fun updateGoalChart(data: Flow<List<DayStatistic>>) {
        viewModelScope.launch {
            val stats = data.firstOrNull() ?: return@launch
            val transformedData = transformDataForGoals(stats).toMutableMap()
            if (transformedData.isEmpty()) return@launch

            if (transformedData.size == 1) transformedData[""] = listOf(0f)

            val newModelProducer = CartesianChartModelProducer.build()

            newModelProducer.tryRunTransaction {
                lineSeries {
                    _goalLabels.value = transformedData.keys.toList()
                    val yValues = transformedData.values.map { durations -> durations.sum() }
                    val xValues = transformedData.keys.indices.toList()
                    series(xValues, yValues)
                }
            }
            _goalModelProducer.value = newModelProducer
        }
    }

    private fun updateChartData(data: Flow<List<DayStatistic>>) {
        viewModelScope.launch {
            val stats = data.firstOrNull() ?: return@launch
            val transformedData = transformDataForChart(stats)
            if (transformedData.isEmpty()) return@launch
            val labels =
                when (_labelMode.value) {
                    GraphState.WEEKLY -> generateLabelsUseCase.generateWeekLabels()
                    GraphState.MONTHLY -> generateLabelsUseCase.generateMonthLabels(transformedData)
                    GraphState.YEARLY -> generateLabelsUseCase.generateYearLabels(stats)
                }
            _dayLabels.value = labels

            // refresh the model producer
            val newModelProducer = CartesianChartModelProducer.build()

            newModelProducer.tryRunTransaction {
                lineSeries {
                    val yValues =
                        transformedData.entries.mapIndexed { index, entry -> entry.value.sum() }
                    val xValues = transformedData.keys.indices.toList()
                    series(xValues, yValues)
                }
            }
            _timeModelProducer.value = newModelProducer
        }
    }

    private suspend fun transformDataForGoals(data: List<DayStatistic>): Map<String, List<Float>> {
        val totalDurationForGoals = totalDurationForGoalsUseCase(data)
        val goalNamesWithDurations = mutableMapOf<String, List<Float>>()
        totalDurationForGoals.forEach { (goalId, duration) ->
            val goalName = getGoalName(goalId) ?: "Unknown Goal"
            goalNamesWithDurations[goalName] = listOf(duration)
        }
        return goalNamesWithDurations
    }

    private suspend fun getGoalName(goalId: Long): String? {
        return goalRepository.getGoal(goalId)?.name
    }

    private fun transformDataForChart(dayStatistics: List<DayStatistic>): Map<String, List<Float>> {
        return when (_labelMode.value) {
            GraphState.WEEKLY -> transformStatisticsUseCase.transformForWeeklyView(dayStatistics)
            GraphState.MONTHLY -> transformStatisticsUseCase.transformForMonthlyView(dayStatistics)
            GraphState.YEARLY -> transformStatisticsUseCase.transformForYearlyView(dayStatistics)
        }
    }
}
