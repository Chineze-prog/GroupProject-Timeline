package ca.umanitoba.cs.timeline.ui.notification

import android.Manifest
import android.app.Notification
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

fun Context.createNotification(channelId: String, block: NotificationCompat.Builder.() -> Unit) =
    NotificationCompat.Builder(this, channelId).apply(block).build()

fun Context.notificationManager() = NotificationManagerCompat.from(this)

fun Context.notify(id: Int, notification: Notification) {
    if (
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
    ) {
        return
    }
    notificationManager().notify(id, notification)
}
