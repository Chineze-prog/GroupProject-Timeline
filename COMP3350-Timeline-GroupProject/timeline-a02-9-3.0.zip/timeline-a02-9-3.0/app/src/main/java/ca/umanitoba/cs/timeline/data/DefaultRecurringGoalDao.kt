package ca.umanitoba.cs.timeline.data

import app.cash.sqldelight.coroutines.asFlow
import app.cash.sqldelight.coroutines.mapToList
import ca.umanitoba.cs.timeline.RecurringGoalQueries
import ca.umanitoba.cs.timeline.di.Dispatcher
import ca.umanitoba.cs.timeline.di.TimelineDispatchers.IO
import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.model.RecurringGoal
import javax.inject.Inject
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class DefaultRecurringGoalDao
@Inject
constructor(
    private val recurringGoalQueries: RecurringGoalQueries,
    @Dispatcher(IO) private val ioDispatcher: CoroutineDispatcher
) : RecurringGoalDao {
    override suspend fun setRecurringGoal(
        goalId: Long,
        repeatFrequency: RecurrenceFrequency,
        isRepeated: Boolean,
    ) =
        withContext(ioDispatcher) {
            recurringGoalQueries.transactionWithResult {
                recurringGoalQueries.setGoalRepeating(goalId, repeatFrequency.name, isRepeated)
            }
        }

    override suspend fun deleteRecurringGoal(goalId: Long) =
        withContext(ioDispatcher) {
            recurringGoalQueries.transaction { recurringGoalQueries.removeGoalRepeating(goalId) }
        }

    override suspend fun getRecurringGoal(goalId: Long): RecurringGoal? =
        withContext(ioDispatcher) {
            recurringGoalQueries.selectRecurringGoalById(goalId).executeAsOneOrNull()?.let {
                RecurringGoal(
                    it.goal_id,
                    RecurrenceFrequency.valueOf(it.repeat_frequency),
                    it.is_repeated,
                )
            }
        }

    override fun getRecurringGoals(): Flow<List<RecurringGoal>> =
        recurringGoalQueries.selectAll().asFlow().mapToList(ioDispatcher).map { recurringGoals ->
            recurringGoals.map { recurringGoal ->
                RecurringGoal(
                    recurringGoal.goal_id,
                    RecurrenceFrequency.valueOf(recurringGoal.repeat_frequency),
                    recurringGoal.is_repeated,
                )
            }
        }
}
