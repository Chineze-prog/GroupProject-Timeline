package ca.umanitoba.cs.timeline.domain.timer

/** Exception that is thrown if a user chooses an invalid deadline */
class InvalidDeadlineException(message: String) : Exception(message)
