package ca.umanitoba.cs.timeline.domain.dayStatistic

import ca.umanitoba.cs.timeline.model.DayStatistic
import java.time.Month
import java.time.format.TextStyle
import java.util.Locale
import javax.inject.Inject

class GenerateLabelsUseCase @Inject constructor() {

    fun generateWeekLabels(): List<String> {
        return listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    }

    fun generateMonthLabels(transformedData: Map<String, List<Float>>): List<String> {
        return Month.values()
            .map { month -> month.getDisplayName(TextStyle.SHORT, Locale.getDefault()) }
            .filter { monthLabel -> transformedData.keys.any { key -> key.startsWith(monthLabel) } }
    }

    fun generateYearLabels(stats: List<DayStatistic>): List<String> {
        val yearSet = stats.map { it.date.year }.toSortedSet()
        if (yearSet.size == 1) {
            yearSet.add(yearSet.first() - 1)
        }
        return yearSet.map { it.toString() }
    }
}
