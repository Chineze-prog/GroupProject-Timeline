package ca.umanitoba.cs.timeline.utils

import kotlin.time.Duration
import kotlin.time.TimeMark
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.flow

/**
 * Produces a flow that yield the remaining time before a [deadline] every [interval].
 *
 * @param interval Interval before a tick
 * @param deadline The deadline mark
 */
fun countdownTicker(
    interval: Duration,
    deadline: TimeMark,
) =
    flow {
            var remaining: Duration
            do {
                remaining = -deadline.elapsedNow()
                emit(remaining)
                delay(minOf(interval, remaining))
            } while (remaining > Duration.ZERO)
        }
        .conflate()
