package ca.umanitoba.cs.timeline.data.di

import app.cash.sqldelight.db.SqlDriver
import ca.umanitoba.cs.timeline.Database
import ca.umanitoba.cs.timeline.DayStatisticQueries
import ca.umanitoba.cs.timeline.GoalQueries
import ca.umanitoba.cs.timeline.RecurringGoalQueries
import ca.umanitoba.cs.timeline.TaskQueries
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton fun provideDatabase(sqlDriver: SqlDriver): Database = Database(sqlDriver)

    @Provides
    @Singleton
    fun provideTaskQueries(database: Database): TaskQueries = database.taskQueries

    @Provides
    @Singleton
    fun provideGoalQueries(database: Database): GoalQueries = database.goalQueries

    @Provides
    @Singleton
    fun provideDayStatQueries(database: Database): DayStatisticQueries =
        database.dayStatisticQueries

    @Provides
    @Singleton
    fun provideRecurringGoalQueries(database: Database): RecurringGoalQueries =
        database.recurringGoalQueries
}
