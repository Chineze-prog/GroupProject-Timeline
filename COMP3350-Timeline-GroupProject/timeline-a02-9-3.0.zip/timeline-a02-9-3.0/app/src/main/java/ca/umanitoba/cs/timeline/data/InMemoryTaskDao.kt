package ca.umanitoba.cs.timeline.data

import ca.umanitoba.cs.timeline.model.Task
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.time.Duration
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update

@Singleton
class InMemoryTaskDao @Inject constructor() : TaskDao {
    private val tasks = MutableStateFlow<Map<Long, List<Task>>>(emptyMap())

    // Task related functions
    private val uniqueId = AtomicLong(0)

    private fun generateNewId(): Long = uniqueId.incrementAndGet()

    override fun getTasks(): Flow<List<Task>> = tasks.map { it.values.flatten() }

    override suspend fun addTask(goalId: Long, name: String): Long {
        val newTask = Task(goalId = goalId, id = generateNewId(), name = name)

        tasks.update { tasks ->
            tasks.toMutableMap().apply { put(goalId, getOrElse(goalId) { emptyList() } + newTask) }
        }

        return newTask.id
    }

    override suspend fun removeTask(id: Long) {
        tasks.update { currentTasks ->
            currentTasks.mapValues { task -> task.value.filterNot { it.id == id } }
        }
    }

    override suspend fun updateTask(id: Long, name: String?, completed: Boolean?) {
        tasks.update { currentTasks ->
            currentTasks.mapValues { (_, tasks) ->
                tasks.map { task ->
                    if (task.id == id) {
                        task.copy(
                            name = name ?: task.name,
                            isCompleted = completed ?: task.isCompleted
                        )
                    } else {
                        task
                    }
                }
            }
        }
    }

    override suspend fun getTask(id: Long): Task? =
        tasks.value.values.flatten().find { it.id == id }

    override suspend fun moveTask(sourceTask: Long, targetTask: Long) {
        if (sourceTask == targetTask) return

        tasks.update { taskMap ->
            val workingGoal =
                taskMap.keys.find { goalId ->
                    taskMap[goalId]?.any { it.id == sourceTask } ?: false
                } ?: throw Exception("Source task ID: $sourceTask does not exist")
            val tasks = taskMap[workingGoal]!!
            val sourceTaskOrder = tasks.indexOfFirst { it.id == sourceTask }
            val targetTaskOrder = tasks.indexOfFirst { it.id == targetTask }
            if (targetTaskOrder == -1) {
                throw Exception(
                    "Target task ID: $targetTask does not exist or is not of the same goal"
                )
            }
            taskMap +
                (workingGoal to
                    tasks.toMutableList().apply { add(targetTaskOrder, removeAt(sourceTaskOrder)) })
        }
    }

    override fun getTasksForGoal(goalId: Long): Flow<List<Task>> =
        tasks.map { it[goalId] ?: emptyList() }

    override suspend fun addTimeToTask(id: Long, timeSpent: Duration) {
        tasks.update { currentTasks ->
            currentTasks.mapValues { (_, tasks) ->
                tasks.map { task ->
                    if (task.id == id) {
                        task.copy(timeSpent = task.timeSpent + timeSpent)
                    } else {
                        task
                    }
                }
            }
        }
    }

    override fun getTaskCompletionForGoal(goalId: Long): Flow<Pair<Int, Int>> =
        tasks
            .map { it[goalId] ?: emptyList() }
            .map { list ->
                val completedTasks = list.count { it.isCompleted }
                val totalTasks = list.size
                Pair(completedTasks, totalTasks)
            }
}
