package ca.umanitoba.cs.timeline.ui.timer

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ca.umanitoba.cs.timeline.domain.goal.AddGoalTimeUseCase
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.domain.recurringgoal.RecurringGoalManager
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import ca.umanitoba.cs.timeline.domain.timer.CollectTimeUseCase
import ca.umanitoba.cs.timeline.domain.timer.PomodoroState
import ca.umanitoba.cs.timeline.domain.timer.PomodoroUseCase
import ca.umanitoba.cs.timeline.domain.timer.TimerState
import ca.umanitoba.cs.timeline.domain.timer.TimerUseCase
import ca.umanitoba.cs.timeline.ui.notification.TimerNotifier
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import javax.inject.Inject
import kotlin.time.Duration
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

@HiltViewModel
class TimerViewModel
@Inject
constructor(
    savedStateHandle: SavedStateHandle,
    private val pomodoro: PomodoroUseCase,
    private val timer: TimerUseCase,
    private val timerNotifier: TimerNotifier,
    private val taskRepository: TaskRepository,
    private val goalRepository: GoalRepository,
    private val collectTimeUseCase: CollectTimeUseCase,
    private val addGoalTimeUseCase: AddGoalTimeUseCase,
    private val recurringGoalManager: RecurringGoalManager
) : ViewModel() {
    private val timerArgs = TimerArgs(savedStateHandle)

    init {
        viewModelScope.launch { timerWatcher() }
        viewModelScope.launch { pomodoroState.collect { state -> timer.reset(state.duration) } }
    }

    val timerState
        get() = timer.state

    val pomodoroState
        get() = pomodoro.state

    fun startTimer() = timer.start(viewModelScope)

    fun stopTimer() {
        timer.stop()
    }

    val tasks = taskRepository.getTasksForGoal(timerArgs.goalId)

    val goalName = goalRepository.getObservableGoal(timerArgs.goalId).map { it.name }

    val goalTime =
        goalRepository.getObservableGoal(timerArgs.goalId).map {
            it.unallocatedTimeSpent + it.allocatedTimeSpent
        }

    fun addTask(taskName: String) {
        viewModelScope.launch { taskRepository.addTask(timerArgs.goalId, taskName) }
    }

    // if removeTask to be 100%, may not be repeated, but now is fixed
    fun removeTask(taskId: Long) {
        viewModelScope.launch { taskRepository.removeTask(taskId) }
        viewModelScope.launch {
            recurringGoalManager.handleTaskCompletionForRecurringGoal(timerArgs.goalId)
        }
    }

    fun editTask(taskId: Long, newName: String) {
        viewModelScope.launch { taskRepository.updateTask(taskId, name = newName) }
    }

    fun onCompletionTask(taskId: Long, isCompleted: Boolean) {
        if (isCompleted) {
            allocateTimeToTask(taskId)
        }
        viewModelScope.launch { taskRepository.updateTask(taskId, completed = isCompleted) }
        viewModelScope.launch {
            recurringGoalManager.handleTaskCompletionForRecurringGoal(timerArgs.goalId)
        }
    }

    private fun addTimeToGoal(goalId: Long, time: Duration) {
        viewModelScope.launch { addGoalTimeUseCase(goalId, LocalDate.now(), time) }
    }

    private fun allocateTimeToTask(taskId: Long) {
        viewModelScope.launch {
            taskRepository.addTimeToTask(
                taskId,
                goalRepository.getGoal(timerArgs.goalId)!!.unallocatedTimeSpent
            )
            goalRepository.allocateTime(timerArgs.goalId)
        }
    }

    fun moveTask(srcId: Long, dstId: Long) {
        viewModelScope.launch { taskRepository.moveTask(srcId, dstId) }
    }

    fun skipPomodoro() {
        collectTimeUseCase.resetCollectedTime()
        pomodoro.next()
    }

    private fun showNotification(nextState: PomodoroState) {
        timerNotifier(nextState)
    }

    private suspend fun timerWatcher() {
        timerState.collect { timerState ->
            if (pomodoro.state.value.state == PomodoroState.State.POMODORO) {
                addTimeToGoal(timerArgs.goalId, collectTimeUseCase(timerState.timePassed))
            }
            if (timerState.state == TimerState.State.COMPLETED) {
                collectTimeUseCase.resetCollectedTime()
                val next = pomodoro.next()
                showNotification(next)
            }
        }
    }
}
