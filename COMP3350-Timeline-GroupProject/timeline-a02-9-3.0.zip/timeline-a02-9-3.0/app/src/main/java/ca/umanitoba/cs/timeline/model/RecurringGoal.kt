package ca.umanitoba.cs.timeline.model

import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency

data class RecurringGoal(
    val goalId: Long,
    val repeatFrequency: RecurrenceFrequency,
    val isRepeated: Boolean = false,
)
