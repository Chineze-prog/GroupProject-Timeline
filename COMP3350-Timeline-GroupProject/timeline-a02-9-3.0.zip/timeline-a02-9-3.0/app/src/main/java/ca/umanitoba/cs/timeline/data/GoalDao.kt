package ca.umanitoba.cs.timeline.data

import ca.umanitoba.cs.timeline.model.Goal
import java.time.LocalDate
import kotlin.time.Duration
import kotlinx.coroutines.flow.Flow

interface GoalDao {
    /** @return An observable list of goals */
    fun getGoals(): Flow<List<Goal>>

    /**
     * Add a new goal with [name].
     *
     * @return The ID of the created goal
     */
    /** Set the repeating information for a goal with [id]. */
    suspend fun addGoal(name: String): Long

    /**
     * Update the goal with [id].
     *
     * Does not do anything if the goal does not exist.
     *
     * @param id The goal to update.
     * @param name The new name for the goal. If `null`, the name will not be updated.
     * @param deadline The new deadline of the goal to be updated
     */
    suspend fun updateGoal(id: Long, name: String? = null, deadline: LocalDate? = null)

    /**
     * Delete the goal with [id].
     *
     * Does not do anything if the goal does not exist.
     */
    suspend fun deleteGoal(id: Long)

    /**
     * Get the goal with [id].
     *
     * @return `null` if the task does not exist, the goal otherwise.
     */
    suspend fun getGoal(id: Long): Goal?

    /** Get observable goal with [id]. */
    fun getObservableGoal(id: Long): Flow<Goal>

    /**
     * Adds unallocated time to the goal with [id]
     *
     * @param id The id of the goal
     * @param time How much time will be added to the goal
     */
    suspend fun addTimeToGoal(id: Long, time: Duration)

    /**
     * Converts the unallocated time of the goal with [id] to allocated time
     *
     * @param id The id of the goal
     */
    suspend fun allocateTime(id: Long)

    /**
     * remove the goal deadline with [id].
     *
     * Does not do anything if the goal does not exist.
     *
     * @param id The goal to remove its deadline.
     */
    suspend fun removeGoalDeadline(id: Long)
}
