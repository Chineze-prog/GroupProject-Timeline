package ca.umanitoba.cs.timeline.domain.task

import ca.umanitoba.cs.timeline.data.TaskDao
import ca.umanitoba.cs.timeline.model.Task
import javax.inject.Inject
import kotlin.time.Duration
import kotlinx.coroutines.flow.Flow

class DefaultTaskRepository @Inject constructor(private val taskSource: TaskDao) : TaskRepository {
    override fun getTasks(): Flow<List<Task>> = taskSource.getTasks()

    override suspend fun addTask(goalId: Long, name: String): Long =
        taskSource.addTask(goalId, name)

    override suspend fun removeTask(id: Long) = taskSource.removeTask(id)

    override suspend fun updateTask(id: Long, name: String?, completed: Boolean?) =
        taskSource.updateTask(id, name, completed)

    override suspend fun getTask(id: Long): Task? = taskSource.getTask(id)

    override suspend fun moveTask(sourceTask: Long, targetTask: Long) =
        taskSource.moveTask(sourceTask, targetTask)

    override fun getTasksForGoal(goalId: Long): Flow<List<Task>> =
        taskSource.getTasksForGoal(goalId)

    override suspend fun addTimeToTask(id: Long, timeSpent: Duration) {
        taskSource.addTimeToTask(id, timeSpent)
    }

    override fun getTaskCompletionForGoal(goalId: Long): Flow<Pair<Int, Int>> =
        taskSource.getTaskCompletionForGoal(goalId)
}
