package ca.umanitoba.cs.timeline.domain.recurringgoal

import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import ca.umanitoba.cs.timeline.domain.toTotalDays
import java.time.LocalDate
import javax.inject.Inject
import kotlinx.coroutines.flow.first

class RecurringGoalManager
@Inject
constructor(
    private val recurringGoalRepository: RecurringGoalRepository,
    private val goalRepository: GoalRepository,
    private val taskRepository: TaskRepository,
) {
    private fun calculateNextRecurrenceDates(
        frequency: RecurrenceFrequency,
        currentEndDate: LocalDate
    ): LocalDate {
        return currentEndDate.plusDays(frequency.futureOffset.toTotalDays())
    }

    private suspend fun repeatGoalAndTasks(goalId: Long, frequency: RecurrenceFrequency) {
        val goal = goalRepository.getGoal(goalId)!!
        val recurringSetting = recurringGoalRepository.getRecurringGoal(goalId)!!
        val newEndDate = calculateNextRecurrenceDates(frequency, goal.deadline!!)
        val newGoalId = goalRepository.addGoal(goal.name)
        goalRepository.updateGoal(newGoalId, deadline = newEndDate)
        recurringGoalRepository.setRecurringGoal(
            newGoalId,
            recurringSetting.repeatFrequency,
            false,
        )
        val tasks = taskRepository.getTasksForGoal(goalId).first()
        tasks.forEach { task -> taskRepository.addTask(newGoalId, task.name) }
    }

    suspend fun handleTaskCompletionForRecurringGoal(goalId: Long) {
        val stats = taskRepository.getTaskCompletionForGoal(goalId).first()
        if (stats.first == stats.second && stats.second > 0) {
            val recurringSetting = recurringGoalRepository.getRecurringGoal(goalId)
            if (recurringSetting != null) {
                if (!recurringSetting.isRepeated) {
                    repeatGoalAndTasks(
                        goalId,
                        recurringSetting.repeatFrequency,
                    )
                    recurringGoalRepository.setRecurringGoal(
                        recurringSetting.goalId,
                        recurringSetting.repeatFrequency,
                        true
                    )
                }
            }
        }
    }

    suspend fun handleTaskCompletionForGoal(goalId: Long, frequency: RecurrenceFrequency) {
        val stats = taskRepository.getTaskCompletionForGoal(goalId).first()
        if (stats.first == stats.second && stats.second > 0) {
            val goalSetting = goalRepository.getGoal(goalId)
            if (goalSetting != null) {
                repeatGoalAndTasks(goalSetting.id, frequency)
            }
        }
    }
}
