package ca.umanitoba.cs.timeline.domain

import java.time.Duration

enum class RecurrenceFrequency(val futureOffset: Duration) {
    Daily(Duration.ofDays(1)),
    Weekly(Duration.ofDays(7)),
    Monthly(Duration.ofDays(30))
}

fun Duration.toTotalDays(): Long {
    return this.toDays()
}
