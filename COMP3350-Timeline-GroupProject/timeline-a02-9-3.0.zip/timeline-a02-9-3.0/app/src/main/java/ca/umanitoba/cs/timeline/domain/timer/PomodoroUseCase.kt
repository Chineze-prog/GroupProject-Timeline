package ca.umanitoba.cs.timeline.domain.timer

import javax.inject.Inject
import kotlin.time.Duration
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.updateAndGet

/** Provides a state machine for the Pomodoro technique */
class PomodoroUseCase(private val config: PomodoroConfig) {
    @Inject constructor() : this(PomodoroConfig())

    private val _state = MutableStateFlow(PomodoroState())
    val state: StateFlow<PomodoroState> = _state.asStateFlow()

    init {
        require(config.pomodoroDuration > Duration.ZERO)
        require(config.breakDuration > Duration.ZERO)
        require(config.longBreakDuration > Duration.ZERO)
        require(config.cyclesBeforeLongBreak > 0)
        reset()
    }

    /** Reset Pomodoro to initial state */
    fun reset() {
        _state.value =
            PomodoroState(state = PomodoroState.State.POMODORO, duration = config.pomodoroDuration)
    }

    /**
     * Advance to the next pomodoro state
     *
     * @return The next pomodoro state
     */
    fun next(): PomodoroState =
        _state.updateAndGet { state ->
            when (state.state) {
                PomodoroState.State.POMODORO ->
                    if (state.numberOfCompletedCycles >= config.cyclesBeforeLongBreak) {
                        state.copy(
                            state = PomodoroState.State.LONG_BREAK,
                            duration = config.longBreakDuration,
                            numberOfCompletedCycles = 0,
                        )
                    } else {
                        state.copy(
                            state = PomodoroState.State.SHORT_BREAK,
                            duration = config.breakDuration,
                            numberOfCompletedCycles = state.numberOfCompletedCycles + 1
                        )
                    }
                else -> {
                    state.copy(
                        state = PomodoroState.State.POMODORO,
                        duration = config.pomodoroDuration
                    )
                }
            }
        }
}
