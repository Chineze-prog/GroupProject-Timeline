package ca.umanitoba.cs.timeline.ui.notification

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import ca.umanitoba.cs.timeline.R
import ca.umanitoba.cs.timeline.domain.timer.PomodoroState
import ca.umanitoba.cs.timeline.ui.MainActivity
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

/** Provides notification facilities for Pomodoro timer related events */
class TimerNotifier @Inject constructor(@ApplicationContext private val context: Context) {
    /**
     * Send notification if allowed by the user.
     *
     * @param nextState The next Pomodoro state to tell the user about.
     */
    operator fun invoke(nextState: PomodoroState) {
        val title =
            when (nextState.state) {
                PomodoroState.State.POMODORO -> "Break has ended"
                else -> "Work period ended"
            }
        val body =
            when (nextState.state) {
                PomodoroState.State.POMODORO -> "Time to start working again"
                PomodoroState.State.SHORT_BREAK -> "Take a short break"
                PomodoroState.State.LONG_BREAK -> "Give yourself a long break"
            }

        with(context) {
            val notification =
                createNotification(Notifications.TIMER_CHANNEL_ID) {
                    setSmallIcon(R.drawable.ic_timer_notification)
                    setPriority(NotificationCompat.PRIORITY_HIGH)
                    setCategory(NotificationCompat.CATEGORY_ALARM)
                    setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    setContentTitle(title)
                    setContentText(body)
                    setContentIntent(openAppPendingIntent())
                    setAutoCancel(true)
                }

            notify(Notifications.TIMER_NOTIFICATION_ID, notification)
        }
    }
}

private fun Context.openAppPendingIntent(): PendingIntent =
    PendingIntent.getActivity(
        this,
        0,
        Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
