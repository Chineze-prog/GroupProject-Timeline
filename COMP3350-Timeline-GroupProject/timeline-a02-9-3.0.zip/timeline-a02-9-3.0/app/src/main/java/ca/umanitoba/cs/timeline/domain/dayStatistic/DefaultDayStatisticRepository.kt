package ca.umanitoba.cs.timeline.domain.dayStatistic

import ca.umanitoba.cs.timeline.data.DayStatisticDao
import ca.umanitoba.cs.timeline.model.DayStatistic
import java.time.LocalDate
import javax.inject.Inject
import kotlin.time.Duration
import kotlinx.coroutines.flow.Flow

class DefaultDayStatisticRepository
@Inject
constructor(private val dayStatisticSource: DayStatisticDao) : DayStatisticRepository {
    override fun getDayStats(): Flow<List<DayStatistic>> = dayStatisticSource.getDayStats()

    override fun getDayStatsByDate(date: LocalDate): Flow<List<DayStatistic>> =
        dayStatisticSource.getDayStatsByDate(date)

    override fun getDayStatsByGoalId(goalId: Long): Flow<List<DayStatistic>> =
        dayStatisticSource.getDayStatsByGoalId(goalId)

    override suspend fun getDayStatByGoalIdAndDate(date: LocalDate, goalId: Long): DayStatistic? =
        dayStatisticSource.getDayStatByGoalIdAndDate(date, goalId)

    override suspend fun addDayStat(date: LocalDate, goalId: Long) {
        dayStatisticSource.addDayStat(date, goalId)
    }

    override suspend fun addTimeToStat(date: LocalDate, goalId: Long, time: Duration) {
        dayStatisticSource.addTimeToStat(date, goalId, time)
    }

    override suspend fun removeDayStat(date: LocalDate, goalId: Long) {
        dayStatisticSource.removeDayStat(date, goalId)
    }

    override suspend fun removeDayStatByGoal(goalId: Long) {
        dayStatisticSource.removeDayStatByGoal(goalId)
    }
}
