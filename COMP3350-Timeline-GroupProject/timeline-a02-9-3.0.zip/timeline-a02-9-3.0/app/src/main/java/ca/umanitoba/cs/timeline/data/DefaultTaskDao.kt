package ca.umanitoba.cs.timeline.data

import app.cash.sqldelight.coroutines.asFlow
import app.cash.sqldelight.coroutines.mapToList
import ca.umanitoba.cs.timeline.TaskQueries
import ca.umanitoba.cs.timeline.di.Dispatcher
import ca.umanitoba.cs.timeline.di.TimelineDispatchers.IO
import ca.umanitoba.cs.timeline.model.Task
import javax.inject.Inject
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.DurationUnit
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class DefaultTaskDao
@Inject
constructor(
    private val taskSource: TaskQueries,
    @Dispatcher(IO) private val ioDispatcher: CoroutineDispatcher
) : TaskDao {
    override fun getTasks(): Flow<List<Task>> =
        taskSource
            .selectAllTasks { id, goal, name, completed, timeSpent ->
                Task(
                    goalId = goal,
                    id = id,
                    name = name,
                    isCompleted = completed,
                    timeSpent = timeSpent.milliseconds
                )
            }
            .asFlow()
            .mapToList(ioDispatcher)

    override suspend fun addTask(goalId: Long, name: String): Long =
        withContext(ioDispatcher) {
            taskSource.transactionWithResult {
                val maxOrderNumber =
                    taskSource.getMaxPositionWithinGoal(goalId).executeAsOne().maxOrder ?: 0

                taskSource.insert(goalId, name, false, maxOrderNumber + 1)
                // NOTE: Workaround for https://github.com/cashapp/sqldelight/issues/5001
                taskSource.selectLastRowId().executeAsOne()
            }
        }

    override suspend fun removeTask(id: Long) {
        withContext(ioDispatcher) {
            taskSource.transaction {
                val removedTask = taskSource.selectOne(id).executeAsOneOrNull()

                if (removedTask != null) {
                    taskSource.delete(id)

                    val remainingTasks =
                        taskSource
                            .getTasksWithPositionGreaterThan(removedTask.goal, removedTask.position)
                            .executeAsList()

                    for (task in remainingTasks) {
                        taskSource.updatePosition(task.position - 1, task.id)
                    }
                }
            }
        }
    }

    override suspend fun updateTask(id: Long, name: String?, completed: Boolean?) {
        withContext(ioDispatcher) {
            taskSource.transaction {
                if (name != null) {
                    taskSource.updateName(name, id)
                }
                if (completed != null) {
                    taskSource.updateCompletion(completed, id)
                }
            }
        }
    }

    override suspend fun getTask(id: Long): Task? =
        withContext(ioDispatcher) {
            taskSource
                .selectOne(id) { id, goal, name, completed, position, timeSpent ->
                    Task(
                        goalId = goal,
                        id = id,
                        name = name,
                        isCompleted = completed,
                        timeSpent = timeSpent.milliseconds
                    )
                }
                .executeAsOneOrNull()
        }

    override suspend fun moveTask(sourceTask: Long, targetTask: Long) {
        withContext(ioDispatcher) {
            taskSource.transaction {
                val source = taskSource.selectOne(sourceTask).executeAsOneOrNull()
                val target = taskSource.selectOne(targetTask).executeAsOneOrNull()

                if ((source != null && target != null) && (source.goal == target.goal)) {
                    val decrementPosOf =
                        taskSource
                            .getTasksWithPositionGreaterThan(source.goal, source.position)
                            .executeAsList()
                    for (task in decrementPosOf) {
                        taskSource.updatePosition(task.position - 1, task.id)
                    }

                    val remainingTasks =
                        taskSource
                            .getTasksWithPositionGreaterThan(target.goal, target.position)
                            .executeAsList()
                    for (task in remainingTasks) {
                        taskSource.updatePosition(task.position + 1, task.id)
                    }

                    taskSource.updatePosition(target.position, sourceTask)
                } else {
                    throw IllegalAccessException("Illegal movement of tasks.")
                }
            }
        }
    }

    override fun getTasksForGoal(goalId: Long): Flow<List<Task>> =
        taskSource
            .selectWithGoal(goalId) { id, goal, name, completed, position, timeSpent ->
                Task(
                    goalId = goal,
                    id = id,
                    name = name,
                    isCompleted = completed,
                    timeSpent = timeSpent.milliseconds
                )
            }
            .asFlow()
            .mapToList(ioDispatcher)

    override suspend fun addTimeToTask(id: Long, timeSpent: Duration) {
        val timeSpentLong: Long = timeSpent.toLong(DurationUnit.MILLISECONDS)
        withContext(ioDispatcher) {
            taskSource.transaction { taskSource.addTime(timeSpentLong, id) }
        }
    }

    override fun getTaskCompletionForGoal(goalId: Long): Flow<Pair<Int, Int>> =
        taskSource
            .selectWithGoal(goalId) { id, goal, name, completed, _, _ ->
                Task(goalId = goal, id = id, name = name, isCompleted = completed)
            }
            .asFlow()
            .mapToList(ioDispatcher)
            .map { tasks ->
                val completedTasks = tasks.count { it.isCompleted }
                val totalTasks = tasks.size
                Pair(completedTasks, totalTasks)
            }
}
