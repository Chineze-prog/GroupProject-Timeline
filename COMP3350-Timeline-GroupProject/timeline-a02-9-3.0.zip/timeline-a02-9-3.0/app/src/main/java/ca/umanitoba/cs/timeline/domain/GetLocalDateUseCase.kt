package ca.umanitoba.cs.timeline.domain

import java.util.Calendar
import java.util.Date
import javax.inject.Inject
import kotlin.time.Duration.Companion.hours
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class GetLocalDateUseCase @Inject constructor() {
    operator fun invoke(): Flow<Date> = flow {
        while (true) {
            emit(Calendar.getInstance().time)
            delay(1.hours)
        }
    }
}
