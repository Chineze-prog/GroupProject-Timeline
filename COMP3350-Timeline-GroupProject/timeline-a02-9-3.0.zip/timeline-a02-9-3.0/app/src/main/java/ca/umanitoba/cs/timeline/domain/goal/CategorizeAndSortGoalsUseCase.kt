package ca.umanitoba.cs.timeline.domain.goal

import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import ca.umanitoba.cs.timeline.model.Goal
import java.time.Clock
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import javax.inject.Inject
import kotlin.math.roundToInt
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

class CategorizeAndSortGoalsUseCase
@Inject
constructor(private val clock: Clock, private val taskRepository: TaskRepository) {

    companion object {
        const val CATEGORY_PAST_DUE = "Past Due"
        const val CATEGORY_DUE_TODAY = "Due Today"
        const val CATEGORY_NO_DEADLINE = "No Deadline"
        const val CATEGORY_DAYS_LEFT = "Days Left: "
        const val CATEGORY_COMPLETED = "Completed"

        const val SORT_PRIORITY_FIRST = 0
        const val SORT_PRIORITY_SECOND = 1
        const val SORT_PRIORITY_THIRD = 2
        const val SORT_PRIORITY_FOURTH = 3
        const val SORT_PRIORITY_LAST = Int.MAX_VALUE
    }

    operator fun invoke(goals: List<Goal>): List<Pair<String, List<Goal>>> {
        return goals
            .groupBy { goal ->
                val goalCompletionPair: Pair<Int, Int>
                runBlocking {
                    goalCompletionPair = taskRepository.getTaskCompletionForGoal(goal.id).first()
                }
                if (
                    goalCompletionPair.second > 0 &&
                        ((goalCompletionPair.first.toFloat() /
                                goalCompletionPair.second.toFloat()) * 100)
                            .roundToInt() == 100
                ) {
                    CATEGORY_COMPLETED
                } else {
                    goal.deadline?.let { deadline ->
                        val daysLeft =
                            ChronoUnit.DAYS.between(LocalDate.now(clock), deadline).toInt()
                        when {
                            daysLeft < 0 -> CATEGORY_PAST_DUE
                            daysLeft == 0 -> CATEGORY_DUE_TODAY
                            else -> "$CATEGORY_DAYS_LEFT$daysLeft"
                        }
                    } ?: CATEGORY_NO_DEADLINE
                }
            }
            .mapValues { (_, goals) -> goals.sortedBy { it.deadline } }
            .toList()
            .sortedBy { (category, _) ->
                when (category) {
                    CATEGORY_NO_DEADLINE -> SORT_PRIORITY_FIRST
                    CATEGORY_PAST_DUE -> SORT_PRIORITY_SECOND
                    CATEGORY_DUE_TODAY -> SORT_PRIORITY_THIRD
                    CATEGORY_COMPLETED -> SORT_PRIORITY_LAST
                    else -> category.removePrefix(CATEGORY_DAYS_LEFT).toInt() + SORT_PRIORITY_FOURTH
                }
            }
    }
}
