package ca.umanitoba.cs.timeline.data

import app.cash.sqldelight.coroutines.asFlow
import app.cash.sqldelight.coroutines.mapToList
import ca.umanitoba.cs.timeline.DayStatisticQueries
import ca.umanitoba.cs.timeline.di.Dispatcher
import ca.umanitoba.cs.timeline.di.TimelineDispatchers
import ca.umanitoba.cs.timeline.model.DayStatistic
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import javax.inject.Inject
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.DurationUnit
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class DefaultDayStatisticDao
@Inject
constructor(
    private val dayStatisticSource: DayStatisticQueries,
    private val zoneId: ZoneId,
    @Dispatcher(TimelineDispatchers.IO) private val ioDispatcher: CoroutineDispatcher
) : DayStatisticDao {

    override fun getDayStats(): Flow<List<DayStatistic>> =
        dayStatisticSource
            .selectAllDayStats { date, goal, timeSpent ->
                DayStatistic(
                    date = Instant.ofEpochSecond(date).atZone(zoneId).toLocalDate(),
                    goalId = goal,
                    timeSpent = timeSpent.milliseconds
                )
            }
            .asFlow()
            .mapToList(ioDispatcher)

    override fun getDayStatsByDate(date: LocalDate): Flow<List<DayStatistic>> =
        dayStatisticSource
            .selectWithDate(date.atStartOfDay(zoneId).toEpochSecond()) { goal, timeSpent ->
                DayStatistic(date = date, goalId = goal, timeSpent = timeSpent.milliseconds)
            }
            .asFlow()
            .mapToList(ioDispatcher)

    override fun getDayStatsByGoalId(goalId: Long): Flow<List<DayStatistic>> =
        dayStatisticSource
            .selectWithGoal(goalId) { date, timeSpent ->
                DayStatistic(
                    date = Instant.ofEpochSecond(date).atZone(zoneId).toLocalDate(),
                    goalId = goalId,
                    timeSpent = timeSpent.milliseconds
                )
            }
            .asFlow()
            .mapToList(ioDispatcher)

    override suspend fun getDayStatByGoalIdAndDate(date: LocalDate, goalId: Long): DayStatistic? =
        withContext(ioDispatcher) {
            dayStatisticSource
                .selectOneWithGoalAndDate(date.atStartOfDay(zoneId).toEpochSecond(), goalId) {
                    date,
                    goal,
                    timeSpent ->
                    DayStatistic(
                        date = Instant.ofEpochSecond(date).atZone(zoneId).toLocalDate(),
                        goalId = goal,
                        timeSpent = timeSpent.milliseconds
                    )
                }
                .executeAsOneOrNull()
        }

    override suspend fun addDayStat(date: LocalDate, goalId: Long) {
        withContext(ioDispatcher) {
            dayStatisticSource.transaction {
                dayStatisticSource.insertDayStat(date.atStartOfDay(zoneId).toEpochSecond(), goalId)
                dayStatisticSource.selectLastRowId().executeAsOne()
            }
        }
    }

    override suspend fun addTimeToStat(date: LocalDate, goalId: Long, time: Duration) {
        val timeLong: Long = time.toLong(DurationUnit.MILLISECONDS)
        withContext(ioDispatcher) {
            dayStatisticSource.transaction {
                dayStatisticSource.addTime(
                    timeLong,
                    date.atStartOfDay(zoneId).toEpochSecond(),
                    goalId
                )
            }
        }
    }

    override suspend fun removeDayStat(date: LocalDate, goalId: Long) {
        withContext(ioDispatcher) {
            dayStatisticSource.deleteDayStat(date.atStartOfDay(zoneId).toEpochSecond(), goalId)
        }
    }

    override suspend fun removeDayStatByGoal(goalId: Long) {
        withContext(ioDispatcher) {
            dayStatisticSource.transaction { dayStatisticSource.deleteDayStatByGoal(goalId) }
        }
    }
}
