package ca.umanitoba.cs.timeline.ui.tasklist

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import ca.umanitoba.cs.timeline.model.Task
import ca.umanitoba.cs.timeline.ui.components.LengthRestrictedTextField
import ca.umanitoba.cs.timeline.ui.components.TextFieldState
import ca.umanitoba.cs.timeline.utils.format
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.ReorderableLazyListState
import sh.calvin.reorderable.rememberReorderableLazyColumnState

@OptIn(ExperimentalFoundationApi::class)
fun LazyListScope.tasksList(
    tasks: List<Task>,
    reorderableLazyColumnState: ReorderableLazyListState,
    onRemove: (Long, Long) -> Unit,
    onEdit: (Long, String) -> Unit,
    onCompleteChange: (Long, Boolean) -> Unit,
) {
    items(tasks, key = { it.id }) { task ->
        ReorderableItem(reorderableLazyColumnState, task.id) {
            TaskItem(
                task,
                onEdit = { onEdit(task.id, task.name) },
                onRemove = { onRemove(task.id, task.goalId) },
                onCompleteChange = { onCompleteChange(task.id, it) },
                modifier = Modifier.fillMaxSize().longPressDraggableHandle()
            )
            HorizontalDivider()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskItem(
    task: Task,
    onEdit: () -> Unit,
    onRemove: () -> Unit,
    onCompleteChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val dismissState = rememberSwipeToDismissBoxState(positionalThreshold = { it * 0.4f })

    LaunchedEffect(dismissState.currentValue, dismissState.progress) {
        // Remove once the item faded far enough
        if (
            dismissState.currentValue != SwipeToDismissBoxValue.Settled &&
                dismissState.progress > 0.9f
        ) {
            onRemove()
            // Reset state so an item reusing the id can show up
            dismissState.snapTo(SwipeToDismissBoxValue.Settled)
        }
    }

    SwipeToDismissBox(
        dismissState,
        backgroundContent = {
            Box(
                modifier =
                    modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.surfaceContainerLow)
                        .padding(8.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Icon(Icons.Rounded.Delete, contentDescription = "Delete")
            }
        },
        enableDismissFromStartToEnd = false
    ) {
        Row(
            modifier =
                modifier
                    .clickable(onClickLabel = "Edit task", onClick = onEdit)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = task.isCompleted, onCheckedChange = onCompleteChange)
            Text(task.name, modifier = Modifier.weight(1f))
            if (task.timeSpent > Duration.ZERO) {
                Text(task.timeSpent.format())
            }
            Spacer(modifier = Modifier.width(16.dp))
        }
    }
}

@Composable
fun TaskAlertDialog(
    initialName: String,
    title: String,
    onDismissRequest: () -> Unit,
    onConfirm: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val taskNameField = remember {
        TextFieldState(initialName, selection = TextRange(initialName.length))
    }

    AlertDialog(
        title = { Text(title) },
        text = {
            val focusRequester = remember { FocusRequester() }
            LengthRestrictedTextField(
                taskNameField,
                onValueChange = { taskNameField.value = it },
                limits = Task.NAME_LENGTH_LIMITS,
                label = { Text("Task Name*") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                modifier = Modifier.focusRequester(focusRequester)
            )

            LaunchedEffect(Unit) { focusRequester.requestFocus() }
        },
        onDismissRequest = onDismissRequest,
        confirmButton = {
            Button(
                onClick = { onConfirm(taskNameField.value.text) },
                enabled = !taskNameField.isError
            ) {
                Text("Confirm")
            }
        },
        dismissButton = { Button(onClick = onDismissRequest) { Text("Cancel") } },
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun PreviewTaskList() {
    val tasks =
        (1..10).map {
            Task(
                goalId = 0,
                id = it.toLong(),
                name = "Task $it",
                isCompleted = it > 7,
                timeSpent = if (it > 7) it.minutes else Duration.ZERO
            )
        }
    val lazyListState = rememberLazyListState()
    val reorderableLazyColumnState = rememberReorderableLazyColumnState(lazyListState) { _, _ -> }

    LazyColumn {
        tasksList(
            tasks = tasks,
            reorderableLazyColumnState = reorderableLazyColumnState,
            onRemove = { _, _ -> },
            onCompleteChange = { _, _ -> },
            onEdit = { _, _ -> },
        )
    }
}
