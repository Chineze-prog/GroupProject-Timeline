package ca.umanitoba.cs.timeline.ui.timer

import android.content.res.Configuration
import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import ca.umanitoba.cs.timeline.R
import ca.umanitoba.cs.timeline.domain.timer.PomodoroState
import ca.umanitoba.cs.timeline.domain.timer.TimerState
import ca.umanitoba.cs.timeline.model.Task
import ca.umanitoba.cs.timeline.ui.components.PermissionRationaleDialog
import ca.umanitoba.cs.timeline.ui.tasklist.TaskAlertDialog
import ca.umanitoba.cs.timeline.ui.tasklist.tasksList
import ca.umanitoba.cs.timeline.ui.theme.TimelineTheme
import ca.umanitoba.cs.timeline.utils.format
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.PermissionStatus
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.shouldShowRationale
import kotlin.math.roundToInt
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds
import sh.calvin.reorderable.rememberReorderableLazyColumnState

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun TimerScreen(
    timerState: TimerState,
    pomodoroState: PomodoroState.State,
    tasks: List<Task>,
    goalName: String,
    goalTime: Duration,
    onTimerStart: () -> Unit,
    onTimerStop: () -> Unit,
    onPomodoroSkip: () -> Unit,
    onTaskMove: (Long, Long) -> Unit,
    onTaskAdd: (String) -> Unit,
    onTaskNameUpdate: (Long, String) -> Unit,
    onTaskRemove: (Long) -> Unit,
    onTaskCompleteUpdate: (Long, Boolean) -> Unit,
) {
    var showEditor by rememberSaveable { mutableStateOf(false) }
    var editTaskId by rememberSaveable { mutableLongStateOf(-1) }
    var editTaskName by rememberSaveable { mutableStateOf("") }
    var showAdder by rememberSaveable { mutableStateOf(false) }

    var showRationale by rememberSaveable { mutableStateOf(false) }
    val notificationPermission =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            rememberPermissionState(android.Manifest.permission.POST_NOTIFICATIONS) {
                showRationale = false
                onTimerStart()
            }
        } else {
            null
        }

    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Timer(
            timerState.remainingTime,
            timerState.state == TimerState.State.RUNNING,
            pomodoroState,
            onStart = {
                if (notificationPermission?.status is PermissionStatus.Denied) {
                    if (notificationPermission.status.shouldShowRationale) {
                        showRationale = true
                    } else {
                        notificationPermission.launchPermissionRequest()
                    }
                } else {
                    onTimerStart()
                }
            },
            onStop = onTimerStop,
            onSkip = onPomodoroSkip,
            modifier = Modifier.padding(16.dp)
        )
        HorizontalDivider()
        Tasks(
            tasks,
            goalName,
            goalTime,
            onTaskMove = onTaskMove,
            onTaskAdd = { showAdder = true },
            onTaskEdit = { id, name ->
                showEditor = true
                editTaskId = id
                editTaskName = name
            },
            onTaskRemove = onTaskRemove,
            onTaskCompleteChange = onTaskCompleteUpdate,
        )
    }

    if (showAdder) {
        TaskAlertDialog(
            initialName = "",
            title = "Add Task",
            onDismissRequest = { showAdder = false },
            onConfirm = {
                onTaskAdd(it)
                showAdder = false
            }
        )
    }

    if (showEditor) {
        TaskAlertDialog(
            initialName = editTaskName,
            title = "Edit Task",
            onDismissRequest = { showEditor = false },
            onConfirm = {
                onTaskNameUpdate(editTaskId, it)
                showEditor = false
            }
        )
    }

    if (showRationale) {
        PermissionRationaleDialog(
            title = "Allow ${stringResource(R.string.app_name)} to send you notifications?",
            body =
                "We use notifications to enhance your experience, like notifying when timer has elapsed.",
            onDismiss = {
                showRationale = false
                onTimerStart()
            },
            onConfirm = { notificationPermission?.launchPermissionRequest() },
            icon = { Icon(Icons.Rounded.Notifications, contentDescription = null) }
        )
    }
}

@Composable
private fun Timer(
    remainingTime: Duration,
    running: Boolean,
    pomodoroState: PomodoroState.State,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onSkip: () -> Unit,
    modifier: Modifier = Modifier
) {
    val icon =
        when (pomodoroState) {
            PomodoroState.State.POMODORO -> painterResource(id = R.drawable.ic_work_session)
            PomodoroState.State.SHORT_BREAK ->
                painterResource(id = R.drawable.ic_short_break_session)
            PomodoroState.State.LONG_BREAK -> painterResource(id = R.drawable.ic_long_break_session)
        }
    val sessionName =
        when (pomodoroState) {
            PomodoroState.State.POMODORO -> "Work session"
            PomodoroState.State.SHORT_BREAK -> "Mini break"
            PomodoroState.State.LONG_BREAK -> "Long break"
        }
    val sessionText = "$sessionName in progress"
    val action = if (running) onStop else onStart
    val actionText = if (running) "Pause" else "Start"

    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(100.dp))
            Text(sessionText, style = MaterialTheme.typography.bodySmall)
            Text(remainingTime.format(), style = MaterialTheme.typography.displayLarge)
        }
        Column(modifier = Modifier.width(IntrinsicSize.Max)) {
            Button(onClick = action, modifier = Modifier.fillMaxWidth()) { Text(actionText) }
            OutlinedButton(onClick = onSkip, modifier = Modifier.fillMaxWidth()) {
                Text("Skip this session")
            }
        }
    }
}

@Composable
private fun Tasks(
    tasks: List<Task>,
    goalName: String,
    goalTime: Duration,
    onTaskMove: (Long, Long) -> Unit,
    onTaskAdd: () -> Unit,
    onTaskRemove: (Long) -> Unit,
    onTaskEdit: (Long, String) -> Unit,
    onTaskCompleteChange: (Long, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val completedCount = tasks.count { it.isCompleted }

    // Cache modifications here to reduce latency. This meant that we are optimistic that these
    // changes will pass, and there will be not very nice UX if they didn't, but nothing fatal.
    val cachedTasks = remember(tasks) { tasks.toMutableStateList() }
    val lazyColumnState = rememberLazyListState()
    val itemsBeforeList = 2
    val reorderableLazyColumnState =
        rememberReorderableLazyColumnState(lazyColumnState) { from, to ->
            cachedTasks.apply {
                add(to.index - itemsBeforeList, removeAt(from.index - itemsBeforeList))
            }
            onTaskMove(from.key as Long, to.key as Long)
        }
    Column {
        LazyColumn(modifier = modifier.weight(1f), state = lazyColumnState) {
            item {
                TasksHeader(
                    completedCount,
                    tasks.count(),
                    goalName,
                    goalTime,
                    modifier = Modifier.padding(16.dp)
                )
            }
            item {
                Text(
                    "Your tasks",
                    color = MaterialTheme.colorScheme.tertiary,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(16.dp)
                )
            }

            if (tasks.isNotEmpty()) {
                tasksList(
                    cachedTasks,
                    reorderableLazyColumnState,
                    onRemove = { removeId, goalId ->
                        val itemIdx = cachedTasks.indexOfFirst { it.id == removeId }
                        if (itemIdx >= 0) cachedTasks.removeAt(itemIdx)
                        onTaskRemove(removeId)
                    },
                    onEdit = onTaskEdit,
                    onCompleteChange = onTaskCompleteChange,
                )
            }
        }

        if (tasks.isEmpty()) {
            Box(modifier = Modifier.weight(2f).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("It's looking pretty empty around here")
            }
        }

        Button(onClick = onTaskAdd, modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Add Task")
        }
    }
}

@Composable
private fun TasksHeader(
    completed: Int,
    total: Int,
    goalName: String,
    goalTime: Duration,
    modifier: Modifier = Modifier
) {
    val progress = if (total > 0) completed.toFloat() / total else 0f
    Column(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = modifier) {
        Text(
            "Current goal",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.tertiary
        )
        Text(goalName, style = MaterialTheme.typography.headlineSmall)
        if (total > 0) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LinearProgressIndicator(
                    progress = { progress },
                    strokeCap = StrokeCap.Round,
                    trackColor = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.heightIn(min = 8.dp).fillMaxWidth()
                )
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("$completed/$total tasks")
                    Text("${(progress * 100).roundToInt()}%")
                }
            }
        }
        Text("Total Time Spent: " + goalTime.format())
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewTimerScreen() {
    val list =
        (1..10).map { Task(goalId = 0, id = it.toLong(), name = "Task $it", isCompleted = it > 7) }
    val timerState = TimerState(remainingTime = 10.minutes)
    val goalName = "Some noble goal"
    val goalTime = 123.seconds
    TimelineTheme {
        Surface {
            TimerScreen(
                timerState,
                PomodoroState.State.LONG_BREAK,
                list,
                goalName,
                goalTime,
                onTaskMove = { _, _ -> },
                onTaskAdd = {},
                onTaskCompleteUpdate = { _, _ -> },
                onTaskRemove = { _ -> },
                onTaskNameUpdate = { _, _ -> },
                onPomodoroSkip = {},
                onTimerStart = {},
                onTimerStop = {}
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewEmptyTimerScreen() {
    val list = emptyList<Task>()
    val timerState = TimerState(remainingTime = 10.minutes)
    val goalName = "Some noble goal"
    val goalTime = 123.seconds

    TimelineTheme {
        Surface {
            TimerScreen(
                timerState,
                PomodoroState.State.LONG_BREAK,
                list,
                goalName,
                goalTime,
                onTaskMove = { _, _ -> },
                onTaskAdd = {},
                onTaskCompleteUpdate = { _, _ -> },
                onTaskRemove = { _ -> },
                onTaskNameUpdate = { _, _ -> },
                onPomodoroSkip = {},
                onTimerStart = {},
                onTimerStop = {},
            )
        }
    }
}

@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
fun PreviewDarkTimerScreen() {
    PreviewTimerScreen()
}

@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
fun PreviewDarkEmptyTimerScreen() {
    PreviewEmptyTimerScreen()
}
