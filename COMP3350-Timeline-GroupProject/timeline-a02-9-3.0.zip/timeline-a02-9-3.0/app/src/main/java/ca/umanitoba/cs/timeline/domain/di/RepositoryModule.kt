package ca.umanitoba.cs.timeline.domain.di

import ca.umanitoba.cs.timeline.domain.dayStatistic.DayStatisticRepository
import ca.umanitoba.cs.timeline.domain.dayStatistic.DefaultDayStatisticRepository
import ca.umanitoba.cs.timeline.domain.goal.DefaultGoalRepository
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.domain.recurringgoal.DefaultRecurringGoalRepository
import ca.umanitoba.cs.timeline.domain.recurringgoal.RecurringGoalRepository
import ca.umanitoba.cs.timeline.domain.task.DefaultTaskRepository
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
interface RepositoryModule {
    @Binds @Singleton fun bindTaskRepository(repository: DefaultTaskRepository): TaskRepository

    @Binds @Singleton fun bindGoalRepository(repository: DefaultGoalRepository): GoalRepository

    @Binds
    @Singleton
    fun bindRecurringGoalRepository(
        repository: DefaultRecurringGoalRepository
    ): RecurringGoalRepository

    @Binds
    @Singleton
    fun bindDayStatisticRepository(
        repository: DefaultDayStatisticRepository
    ): DayStatisticRepository
}
