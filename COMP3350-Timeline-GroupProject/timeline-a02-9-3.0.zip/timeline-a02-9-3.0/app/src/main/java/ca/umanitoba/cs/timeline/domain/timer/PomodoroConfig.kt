package ca.umanitoba.cs.timeline.domain.timer

import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes

data class PomodoroConfig(
    val pomodoroDuration: Duration = 25.minutes,
    val breakDuration: Duration = 5.minutes,
    val longBreakDuration: Duration = 15.minutes,
    val cyclesBeforeLongBreak: Int = 4,
)
