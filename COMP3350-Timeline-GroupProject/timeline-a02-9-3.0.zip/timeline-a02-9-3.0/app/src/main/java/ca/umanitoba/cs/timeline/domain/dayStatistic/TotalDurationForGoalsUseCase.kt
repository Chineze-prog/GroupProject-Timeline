package ca.umanitoba.cs.timeline.domain.dayStatistic

import ca.umanitoba.cs.timeline.model.DayStatistic
import javax.inject.Inject

class TotalDurationForGoalsUseCase @Inject constructor() {
    operator fun invoke(stats: List<DayStatistic>): Map<Long, Float> {
        val goalDurationMap = mutableMapOf<Long, Float>()
        for (stat in stats) {
            val goalId = stat.goalId
            val duration = stat.timeSpent.inWholeMinutes.toFloat()
            goalDurationMap[goalId] = goalDurationMap.getOrDefault(goalId, 0f) + duration
        }
        return goalDurationMap
    }
}
