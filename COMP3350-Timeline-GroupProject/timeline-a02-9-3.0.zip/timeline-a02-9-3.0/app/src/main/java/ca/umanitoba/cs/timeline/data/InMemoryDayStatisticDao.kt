package ca.umanitoba.cs.timeline.data

import ca.umanitoba.cs.timeline.model.DayStatistic
import java.time.LocalDate
import javax.inject.Inject
import kotlin.time.Duration
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update

class InMemoryDayStatisticDao @Inject constructor() : DayStatisticDao {
    private val dayStatsMappedByDate =
        MutableStateFlow<Map<LocalDate, List<DayStatistic>>>(emptyMap())
    private val dayStatsMappedByGoal = MutableStateFlow<Map<Long, List<DayStatistic>>>(emptyMap())

    override fun getDayStats(): Flow<List<DayStatistic>> =
        dayStatsMappedByDate.map { it.values.flatten() }

    override fun getDayStatsByDate(date: LocalDate): Flow<List<DayStatistic>> =
        dayStatsMappedByDate.map { it[date] ?: emptyList() }

    override fun getDayStatsByGoalId(goalId: Long): Flow<List<DayStatistic>> =
        dayStatsMappedByGoal.map { it[goalId] ?: emptyList() }

    override suspend fun getDayStatByGoalIdAndDate(date: LocalDate, goalId: Long): DayStatistic? =
        dayStatsMappedByDate.value.values.flatten().find { it.date == date && it.goalId == goalId }

    override suspend fun addDayStat(date: LocalDate, goalId: Long) {
        if (getDayStatByGoalIdAndDate(date, goalId) == null) {
            val newDayStat = DayStatistic(date, goalId)
            dayStatsMappedByDate.update { dayStats ->
                dayStats.toMutableMap().apply {
                    put(date, getOrElse(date) { emptyList() } + newDayStat)
                }
            }
            dayStatsMappedByGoal.update { dayStats ->
                dayStats.toMutableMap().apply {
                    put(goalId, getOrElse(goalId) { emptyList() } + newDayStat)
                }
            }
        }
    }

    override suspend fun addTimeToStat(date: LocalDate, goalId: Long, time: Duration) {
        dayStatsMappedByDate.update { currentDayStats ->
            currentDayStats.mapValues { (_, currentDayStats) ->
                currentDayStats.map { currentDayStat ->
                    if (currentDayStat.date == date && currentDayStat.goalId == goalId) {
                        currentDayStat.copy(timeSpent = currentDayStat.timeSpent + time)
                    } else {
                        currentDayStat
                    }
                }
            }
        }
        dayStatsMappedByGoal.update { currentDayStats ->
            currentDayStats.mapValues { (_, currentDayStats) ->
                currentDayStats.map { currentDayStat ->
                    if (currentDayStat.date == date && currentDayStat.goalId == goalId) {
                        currentDayStat.copy(timeSpent = currentDayStat.timeSpent + time)
                    } else {
                        currentDayStat
                    }
                }
            }
        }
    }

    override suspend fun removeDayStat(date: LocalDate, goalId: Long) {
        dayStatsMappedByDate.update { currentDayStats ->
            currentDayStats.mapValues { dayStat ->
                dayStat.value.filterNot { it.date == date && it.goalId == goalId }
            }
        }
        dayStatsMappedByGoal.update { currentDayStats ->
            currentDayStats.mapValues { dayStat ->
                dayStat.value.filterNot { it.date == date && it.goalId == goalId }
            }
        }
    }

    override suspend fun removeDayStatByGoal(goalId: Long) {
        dayStatsMappedByDate.update { currentDayStats ->
            currentDayStats.mapValues { dayStat -> dayStat.value.filterNot { it.goalId == goalId } }
        }
        dayStatsMappedByGoal.update { currentDayStats ->
            currentDayStats.mapValues { dayStat -> dayStat.value.filterNot { it.goalId == goalId } }
        }
    }
}
