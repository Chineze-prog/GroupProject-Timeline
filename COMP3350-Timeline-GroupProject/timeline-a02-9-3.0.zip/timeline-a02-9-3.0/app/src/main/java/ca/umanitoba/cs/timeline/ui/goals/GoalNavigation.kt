package ca.umanitoba.cs.timeline.ui.goals

import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable

private const val goalRoute = "goals"

fun NavGraphBuilder.goalScreen(
    onNavigateToTimer: (Long) -> Unit,
    onNavigateToStatistics: () -> Unit
) {
    composable(goalRoute) {
        val viewModel = hiltViewModel<GoalViewModel>()
        GoalScreen(
            onNavigateToTimer = onNavigateToTimer,
            onNavigateToStatistics = onNavigateToStatistics,
            viewModel = viewModel
        )
    }
}
