package ca.umanitoba.cs.timeline.domain.dayStatistic

import ca.umanitoba.cs.timeline.model.DayStatistic
import java.time.LocalDate
import kotlin.time.Duration
import kotlinx.coroutines.flow.Flow

interface DayStatisticRepository {
    /** @return An observable list of day statistics */
    fun getDayStats(): Flow<List<DayStatistic>>

    /**
     * Get the day statistics for a given date
     *
     * @param date The date the statistics are under
     * @return An observable list of day statistics
     */
    fun getDayStatsByDate(date: LocalDate): Flow<List<DayStatistic>>

    /**
     * Get the day statistics for a given goal with [goalId]
     *
     * @param goalId The id for the goal the day statistics are under
     * @return An observable list of day statistics
     */
    fun getDayStatsByGoalId(goalId: Long): Flow<List<DayStatistic>>

    /**
     * Get the day statistic for a given date and goal with [goalId]
     *
     * @param date The date of the day statistic
     * @param goalId The id for the goal of the day statistic
     * @return `null` if day statistic does not exist, the day statistic otherwise
     */
    suspend fun getDayStatByGoalIdAndDate(date: LocalDate, goalId: Long): DayStatistic?

    /**
     * Add a new day statistic on [date] and assign it to goal with [goalId]
     *
     * @param date The date of the day statistic
     * @param goalId The id for the goal of the day statistic
     */
    suspend fun addDayStat(date: LocalDate, goalId: Long)

    /**
     * Adds time spent to day statistic on [date] and with goal [goalId]
     *
     * @param date The date of the day statistic
     * @param goalId The id for the goal of the day statistic
     */
    suspend fun addTimeToStat(date: LocalDate, goalId: Long, time: Duration)

    /**
     * Remove day statistic on [date] with goal [goalId]
     *
     * @param date The date of the day statistic
     * @param goalId The id for the goal of the day statistic
     */
    suspend fun removeDayStat(date: LocalDate, goalId: Long)

    /**
     * Removes all day statistics with goal [goalId]
     *
     * @param goalId The id for the goal
     */
    suspend fun removeDayStatByGoal(goalId: Long)
}
