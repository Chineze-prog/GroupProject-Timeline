package ca.umanitoba.cs.timeline.domain.recurringgoal

import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.model.RecurringGoal
import kotlinx.coroutines.flow.Flow

interface RecurringGoalRepository {

    fun getRecurringGoals(): Flow<List<RecurringGoal>>

    /**
     * Updates an existing recurring goal.
     *
     * @param goalId The ID of the goal to update.
     * @param frequency Optional new frequency of recurrence. If `null`, the frequency will not be
     *   updated.
     */
    suspend fun setRecurringGoal(
        goalId: Long,
        frequency: RecurrenceFrequency,
        isRepeated: Boolean,
    )

    /**
     * Deletes a recurring goal.
     *
     * @param goalId The ID of the recurring goal to delete.
     */
    suspend fun deleteRecurringGoal(goalId: Long)

    /**
     * Retrieves a specific recurring goal by its ID.
     *
     * @param goalId The ID of the recurring goal.
     * @return The `RecurringGoal` instance if found, `null` otherwise.
     */
    suspend fun getRecurringGoal(goalId: Long): RecurringGoal?
}
