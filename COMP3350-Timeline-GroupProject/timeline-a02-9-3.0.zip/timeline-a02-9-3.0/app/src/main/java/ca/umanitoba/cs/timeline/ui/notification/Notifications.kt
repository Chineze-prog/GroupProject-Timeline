package ca.umanitoba.cs.timeline.ui.notification

import android.content.Context
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationManagerCompat

object Notifications {
    const val TIMER_CHANNEL_ID = "timer_channel"

    const val TIMER_NOTIFICATION_ID = 1

    fun createChannels(context: Context) {
        val timerChannel =
            NotificationChannelCompat.Builder(
                    TIMER_CHANNEL_ID,
                    NotificationManagerCompat.IMPORTANCE_HIGH
                )
                .setName("Timer")
                .setVibrationEnabled(true)
                .build()

        val manager = NotificationManagerCompat.from(context)
        manager.createNotificationChannel(timerChannel)
    }
}
