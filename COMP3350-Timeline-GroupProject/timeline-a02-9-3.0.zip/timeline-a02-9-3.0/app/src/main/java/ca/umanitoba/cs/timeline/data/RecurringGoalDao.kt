package ca.umanitoba.cs.timeline.data

import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.model.RecurringGoal
import kotlinx.coroutines.flow.Flow

interface RecurringGoalDao {
    /**
     * Deletes a specified recurring goal by its ID from the database. This is a no-op if the goal
     * with the specified ID does not exist.
     *
     * @param goalId The unique identifier of the recurring goal to be deleted.
     */
    suspend fun deleteRecurringGoal(goalId: Long)

    /**
     * Fetches a recurring goal identified by its ID from the database.
     *
     * @param goalId The unique identifier of the recurring goal to be retrieved.
     * @return The `RecurringGoal` associated with the given ID, or `null` if no such goal exists.
     */
    suspend fun getRecurringGoal(goalId: Long): RecurringGoal?

    /**
     * Inserts a new recurring goal into the database, or updates an existing goal if the provided
     * `goalId` matches an existing record. It assigns a repetition frequency to the goal and marks
     * it as repeating or not.
     *
     * @param goalId The ID of the primary goal this recurring goal is associated with. This should
     *   correspond to an existing non-recurring goal's ID.
     * @param repeatFrequency The recurrence frequency (e.g., DAILY, WEEKLY, MONTHLY) of the goal.
     * @param isRepeated A flag indicating whether the goal should repeat according to the specified
     *   `repeatFrequency`.
     * @return The unique identifier (`goalId`) of the newly inserted or updated recurring goal.
     */
    suspend fun setRecurringGoal(
        goalId: Long,
        repeatFrequency: RecurrenceFrequency,
        isRepeated: Boolean,
    )
    /**
     * Retrieves a flow of a list containing all recurring goals stored in the database.
     *
     * @return A `Flow` emitting updates to the list of `RecurringGoal` instances whenever changes
     *   occur in the database.
     */
    fun getRecurringGoals(): Flow<List<RecurringGoal>>
}
