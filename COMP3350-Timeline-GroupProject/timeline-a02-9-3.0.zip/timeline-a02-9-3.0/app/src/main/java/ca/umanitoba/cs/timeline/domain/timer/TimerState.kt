package ca.umanitoba.cs.timeline.domain.timer

import kotlin.time.Duration

data class TimerState(
    val remainingTime: Duration = Duration.ZERO,
    val state: State = State.PAUSED,
    val initialTime: Duration = Duration.ZERO
) {
    enum class State {
        /** Timer is paused */
        PAUSED,
        /** Timer is running */
        RUNNING,
        /** Timer has run to completion */
        COMPLETED
    }

    val timePassed: Duration
        get() = initialTime - remainingTime
}
