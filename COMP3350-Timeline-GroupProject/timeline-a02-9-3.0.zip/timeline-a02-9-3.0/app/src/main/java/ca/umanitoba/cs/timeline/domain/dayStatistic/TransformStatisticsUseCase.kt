package ca.umanitoba.cs.timeline.domain.dayStatistic

import ca.umanitoba.cs.timeline.model.DayStatistic
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.Month
import java.time.format.TextStyle
import java.util.Locale
import javax.inject.Inject

class TransformStatisticsUseCase
@Inject
constructor(private val generateLabelsUseCase: GenerateLabelsUseCase) {

    fun transformForWeeklyView(dayStatistics: List<DayStatistic>): Map<String, List<Float>> {
        val allDaysOfWeek =
            DayOfWeek.values()
                .associate { it.getDisplayName(TextStyle.SHORT, Locale.getDefault()) to listOf(0f) }
                .toMutableMap()

        val groupedByDayOfWeek =
            dayStatistics.groupBy {
                it.date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault())
            }

        return allDaysOfWeek +
            groupedByDayOfWeek.mapValues { (_, stats) ->
                stats
                    .groupBy { it.goalId }
                    .mapValues { (_, innerStats) ->
                        innerStats.sumOf { it.timeSpent.inWholeMinutes }.toFloat()
                    }
                    .values
                    .toList()
                    .let { it.ifEmpty { listOf(0f) } }
            }
    }

    fun transformForMonthlyView(dayStatistics: List<DayStatistic>): Map<String, List<Float>> {
        val currentYear = LocalDate.now().year
        val statsForCurrentYear = dayStatistics.filter { it.date.year == currentYear }

        val monthLabels =
            Month.values().associate { month ->
                month.value to month.getDisplayName(TextStyle.FULL, Locale.getDefault())
            }

        val allMonthsData =
            (1..12).associate { month -> monthLabels[month]!! to listOf(0f) }.toMutableMap()

        statsForCurrentYear.forEach { stat ->
            val monthLabel = monthLabels[stat.date.monthValue]!!
            val existingData = allMonthsData[monthLabel]?.firstOrNull() ?: 0f
            val newData = stat.timeSpent.inWholeMinutes.toFloat()

            allMonthsData[monthLabel] = listOf(existingData + newData)
        }
        return allMonthsData
    }

    fun transformForYearlyView(dayStatistics: List<DayStatistic>): Map<String, List<Float>> {
        // Use the GenerateYearLabelsUseCase to get year labels
        val yearLabels = generateLabelsUseCase.generateYearLabels(dayStatistics)

        // Prepare initial data structure
        val allYearsData = yearLabels.associateWith { listOf(0f) }.toMutableMap()

        // Group and sum data by year
        val groupedByYear = dayStatistics.groupBy { it.date.year.toString() }

        groupedByYear.forEach { (year, stats) ->
            val totalsPerGoal =
                stats
                    .groupBy { it.goalId }
                    .map { (_, goalStats) ->
                        goalStats.sumOf { it.timeSpent.inWholeMinutes }.toFloat()
                    }

            if (year in yearLabels) {
                allYearsData[year] = listOf(totalsPerGoal.sum())
            }
        }

        return allYearsData
    }
}
