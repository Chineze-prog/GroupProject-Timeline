package ca.umanitoba.cs.timeline.utils

import android.os.SystemClock
import javax.inject.Inject
import kotlin.time.AbstractLongTimeSource
import kotlin.time.DurationUnit

/**
 * Provides a Kotlin time source using Android real time clock.
 *
 * This clock is monotonic and counts even during deep sleep.
 */
class AndroidRealTimeSource @Inject constructor() :
    AbstractLongTimeSource(DurationUnit.MILLISECONDS) {
    override fun read(): Long = SystemClock.elapsedRealtime()
}
