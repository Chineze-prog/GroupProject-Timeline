package ca.umanitoba.cs.timeline.domain.recurringgoal

import ca.umanitoba.cs.timeline.data.RecurringGoalDao
import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.model.RecurringGoal
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow

class DefaultRecurringGoalRepository
@Inject
constructor(private val recurringGoalDataSource: RecurringGoalDao) : RecurringGoalRepository {

    override fun getRecurringGoals(): Flow<List<RecurringGoal>> =
        recurringGoalDataSource.getRecurringGoals()

    override suspend fun deleteRecurringGoal(goalId: Long) =
        recurringGoalDataSource.deleteRecurringGoal(goalId)

    override suspend fun getRecurringGoal(goalId: Long): RecurringGoal? =
        recurringGoalDataSource.getRecurringGoal(goalId)

    override suspend fun setRecurringGoal(
        goalId: Long,
        frequency: RecurrenceFrequency,
        isRepeated: Boolean,
    ) = recurringGoalDataSource.setRecurringGoal(goalId, frequency, isRepeated)
}
