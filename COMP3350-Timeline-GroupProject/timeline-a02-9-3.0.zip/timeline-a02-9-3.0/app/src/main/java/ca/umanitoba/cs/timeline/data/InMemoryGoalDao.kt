package ca.umanitoba.cs.timeline.data

import ca.umanitoba.cs.timeline.model.Goal
import java.time.LocalDate
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import kotlin.time.Duration
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.mapNotNull
import kotlinx.coroutines.flow.update

class InMemoryGoalDao @Inject constructor() : GoalDao {
    private val goals = MutableStateFlow<List<Goal>>(emptyList())
    private val uniqueId = AtomicLong(0)

    private fun generateNewId(): Long = uniqueId.incrementAndGet()

    override fun getGoals(): Flow<List<Goal>> = goals.asStateFlow()

    override suspend fun updateGoal(id: Long, name: String?, deadline: LocalDate?) {
        goals.update { goals ->
            goals.map { goal ->
                if (goal.id == id)
                    goal.copy(name = name ?: goal.name, deadline = deadline ?: goal.deadline)
                else goal
            }
        }
    }

    override suspend fun removeGoalDeadline(id: Long) {
        goals.update { goals ->
            goals.map { goal -> if (goal.id == id) goal.copy(deadline = null) else goal }
        }
    }

    override suspend fun addGoal(name: String): Long {
        val newGoal = Goal(id = generateNewId(), name = name)
        goals.update { it + newGoal }
        return newGoal.id
    }

    override suspend fun deleteGoal(id: Long) {
        goals.update { it.filterNot { goal -> goal.id == id } }
    }

    override suspend fun getGoal(id: Long): Goal? = goals.value.find { it.id == id }

    override fun getObservableGoal(id: Long): Flow<Goal> =
        goals.mapNotNull { goals -> goals.find { it.id == id } }

    override suspend fun addTimeToGoal(id: Long, time: Duration) {
        goals.update { goals ->
            goals.map { goal ->
                if (goal.id == id) {
                    goal.copy(unallocatedTimeSpent = goal.unallocatedTimeSpent + time)
                } else {
                    goal
                }
            }
        }
    }

    override suspend fun allocateTime(id: Long) {
        goals.update { goals ->
            goals.map { goal ->
                if (goal.id == id) {
                    goal.copy(
                        allocatedTimeSpent = goal.allocatedTimeSpent + goal.unallocatedTimeSpent,
                        unallocatedTimeSpent = Duration.ZERO
                    )
                } else {
                    goal
                }
            }
        }
    }
}
