package ca.umanitoba.cs.timeline.domain.goal

import ca.umanitoba.cs.timeline.domain.dayStatistic.DayStatisticRepository
import ca.umanitoba.cs.timeline.domain.recurringgoal.RecurringGoalRepository
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import javax.inject.Inject
import kotlinx.coroutines.flow.first

class DeleteGoalUseCase
@Inject
constructor(
    private val goalRepository: GoalRepository,
    private val recurringGoalRepository: RecurringGoalRepository,
    private val taskRepository: TaskRepository,
    private val dayStatisticRepository: DayStatisticRepository
) {
    suspend operator fun invoke(goalId: Long) {
        val tasks = taskRepository.getTasksForGoal(goalId).first()
        for (task in tasks) {
            taskRepository.removeTask(task.id)
        }
        if (recurringGoalRepository.getRecurringGoal(goalId) != null) {
            recurringGoalRepository.deleteRecurringGoal(goalId)
        }
        dayStatisticRepository.removeDayStatByGoal(goalId)
        goalRepository.deleteGoal(goalId)
    }
}
