package ca.umanitoba.cs.timeline.data.di

import ca.umanitoba.cs.timeline.data.DayStatisticDao
import ca.umanitoba.cs.timeline.data.DefaultDayStatisticDao
import ca.umanitoba.cs.timeline.data.DefaultGoalDao
import ca.umanitoba.cs.timeline.data.DefaultRecurringGoalDao
import ca.umanitoba.cs.timeline.data.DefaultTaskDao
import ca.umanitoba.cs.timeline.data.GoalDao
import ca.umanitoba.cs.timeline.data.RecurringGoalDao
import ca.umanitoba.cs.timeline.data.TaskDao
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
interface DaoModule {
    @Singleton @Binds fun bindTaskDao(taskDao: DefaultTaskDao): TaskDao

    @Singleton @Binds fun bindGoalDao(goalDao: DefaultGoalDao): GoalDao

    @Singleton
    @Binds
    fun bindRecurringGoalDao(recurringGoalDao: DefaultRecurringGoalDao): RecurringGoalDao

    @Singleton
    @Binds
    fun bindDayStatisticDao(dayStatisticDao: DefaultDayStatisticDao): DayStatisticDao
}
