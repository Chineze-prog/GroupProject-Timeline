package ca.umanitoba.cs.timeline.domain.task

import ca.umanitoba.cs.timeline.model.Task
import kotlin.time.Duration
import kotlinx.coroutines.flow.Flow

interface TaskRepository {
    /** @return An observable list of tasks */
    fun getTasks(): Flow<List<Task>>

    /**
     * Add a new task with [name] and assign it to a goal with [goalId].
     *
     * @return The ID of the added task.
     */
    suspend fun addTask(goalId: Long, name: String): Long

    /**
     * Remove the task with [id].
     *
     * Does not do anything if the task does not exist.
     */
    suspend fun removeTask(id: Long)

    /**
     * Update the task with [id].
     *
     * Does not do anything if the task does not exist.
     *
     * @param id The task to update.
     * @param name The new name for the task. If `null`, the name will not be updated.
     * @param completed The new completion state for the task. If `null`, the state will not be
     *   updated.
     */
    suspend fun updateTask(id: Long, name: String? = null, completed: Boolean? = null)

    /**
     * Get the task with [id].
     *
     * @return `null` if the task does not exist, the task otherwise.
     */
    suspend fun getTask(id: Long): Task?

    /**
     * Move [sourceTask] to before or after [targetTask].
     *
     * If [sourceTask] position is less than [targetTask], [sourceTask] will be ordered after
     * [targetTask]. Otherwise, [sourceTask] will be ordered before [targetTask].
     *
     * Both tasks must be of the same goal and both must exist. If not, an [Exception] will be
     * thrown
     */
    suspend fun moveTask(sourceTask: Long, targetTask: Long)

    /**
     * Get the tasks for a Goal with [goalId]
     *
     * @param goalId the id for the goal the tasks are under
     */
    fun getTasksForGoal(goalId: Long): Flow<List<Task>>

    suspend fun addTimeToTask(id: Long, timeSpent: Duration)

    /**
     * Get the number of tasks completed and total tasks for a Goal with [goalId]
     *
     * @param goalId the id for the goal the tasks are under
     * @return '(0,0)' if goal does not exist, otherwise returns a Pair(completedTotal,totalTasks)
     */
    fun getTaskCompletionForGoal(goalId: Long): Flow<Pair<Int, Int>>
}
