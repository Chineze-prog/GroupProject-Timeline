package ca.umanitoba.cs.timeline

import android.app.Application
import ca.umanitoba.cs.timeline.ui.notification.Notifications
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TimelineApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        Notifications.createChannels(applicationContext)
    }
}
