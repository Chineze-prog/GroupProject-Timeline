package ca.umanitoba.cs.timeline.domain.timer

import ca.umanitoba.cs.timeline.utils.countdownTicker
import javax.inject.Inject
import kotlin.time.Duration
import kotlin.time.Duration.Companion.ZERO
import kotlin.time.Duration.Companion.seconds
import kotlin.time.TimeSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * A countdown timer with a given update interval.
 *
 * Upon [start], the timer will continuously emit its current [state], which can be collected for
 * display in an UI. The timer will perform one last update before stopping.
 *
 * @param timeout The duration before the timer stops. Timeout must be larger or equal to
 *   [Duration.ZERO]
 * @property interval The timer update interval. The actual update interval depends on the timeout
 *   and system load.
 * @property timeSource The time source used for the timer.
 */
class TimerUseCase(
    private var timeout: Duration,
    private val timeSource: TimeSource,
    private val interval: Duration = 1.seconds
) {
    @Inject constructor(timeSource: TimeSource) : this(ZERO, timeSource)

    private val _state = MutableStateFlow(TimerState())

    /** The current timer state */
    val state: StateFlow<TimerState> = _state.asStateFlow()

    private var worker: Job? = null

    init {
        reset(timeout)
    }

    /**
     * Reset the timer with the given timeout
     *
     * @param timeout The duration before the timer stops.
     * @throws IllegalArgumentException If [timeout] is negative.
     */
    fun reset(timeout: Duration) {
        require(timeout >= ZERO)
        stop()
        _state.value = TimerState(remainingTime = timeout, initialTime = timeout)
    }

    /**
     * Start the timer
     *
     * @param scope The scope to launch coroutines in
     * @return Whether the timer is running. Will return false if the remaining time is
     *   [Duration.ZERO]
     */
    fun start(scope: CoroutineScope): Boolean =
        if (worker?.isActive != true && _state.value.remainingTime > ZERO) {
            worker = scope.launch { worker() }
            true
        } else worker?.isActive == true

    /**
     * Stop the timer
     *
     * The timer will emit one last tick before stopping
     */
    fun stop() {
        worker?.cancel()
        worker = null
    }

    /**
     * Start or stop the timer depending on whether it is running.
     *
     * @param scope The scope to launch coroutines in
     */
    fun toggle(scope: CoroutineScope) {
        if (worker?.isActive != true) {
            start(scope)
        } else {
            stop()
        }
    }

    private suspend fun worker() {
        val deadline = timeSource.markNow() + _state.value.remainingTime
        countdownTicker(interval, deadline)
            .onCompletion { cause ->
                _state.update {
                    if (it.state == TimerState.State.RUNNING) {
                        TimerState(
                            remainingTime = -deadline.elapsedNow(),
                            state =
                                if (cause == null) TimerState.State.COMPLETED
                                else TimerState.State.PAUSED,
                            initialTime = it.initialTime
                        )
                    } else {
                        it // Don't emit an update if someone else resetted it
                    }
                }
            }
            .collect { remaining ->
                _state.update {
                    TimerState(
                        remainingTime = remaining,
                        state = TimerState.State.RUNNING,
                        initialTime = it.initialTime
                    )
                }
            }
    }
}
