package ca.umanitoba.cs.timeline.domain.dayStatistic

import ca.umanitoba.cs.timeline.model.DayStatistic
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class FilterStatsByTimePeriodUseCase @Inject constructor() {
    fun getWeeklyStats(
        stats: Flow<List<DayStatistic>>,
        currentDay: LocalDate
    ): Flow<List<DayStatistic>> {
        return stats.map { stats ->
            val startOfWeek = currentDay.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            val endOfWeek = currentDay.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY))
            stats.filter { stat -> stat.date in startOfWeek..endOfWeek }.sortedBy { it.date }
        }
    }

    fun getMonthlyStats(
        stats: Flow<List<DayStatistic>>,
        currentDay: LocalDate
    ): Flow<List<DayStatistic>> {
        return stats.map { stats ->
            stats.filter { stat -> stat.date.year == currentDay.year }.sortedBy { it.date }
        }
    }

    fun getYearlyStats(stats: Flow<List<DayStatistic>>): Flow<List<DayStatistic>> {
        return stats.map { stats -> stats.sortedBy { it.date } }
    }
}
