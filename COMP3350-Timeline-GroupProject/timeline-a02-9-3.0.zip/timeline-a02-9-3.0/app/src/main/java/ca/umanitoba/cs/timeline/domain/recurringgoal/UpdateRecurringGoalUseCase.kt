package ca.umanitoba.cs.timeline.domain.recurringgoal

import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import java.time.Clock
import java.time.LocalDate
import javax.inject.Inject
import kotlinx.coroutines.flow.first

class UpdateRecurringGoalUseCase
@Inject
constructor(
    private val recurringGoalRepository: RecurringGoalRepository,
    private val recurringGoalManager: RecurringGoalManager,
    private val goalRepository: GoalRepository,
    private val taskRepository: TaskRepository,
    private val clock: Clock
) {
    suspend operator fun invoke(
        goalId: Long,
        frequency: RecurrenceFrequency? = null,
        deadline: LocalDate? = null,
    ) {
        val effectiveEndDate =
            deadline ?: goalRepository.getGoal(goalId)?.deadline ?: LocalDate.now(clock)
        val effectiveFrequency =
            frequency
                ?: recurringGoalRepository.getRecurringGoal(goalId)?.repeatFrequency
                ?: throw IllegalStateException("Frequency must be provided for new recurring goals")
        val stats = taskRepository.getTaskCompletionForGoal(goalId).first()

        if (goalRepository.getGoal(goalId)?.deadline != effectiveEndDate) {
            goalRepository.updateGoal(goalId, deadline = effectiveEndDate)
        }
        recurringGoalRepository.setRecurringGoal(
            goalId = goalId,
            frequency = effectiveFrequency,
            isRepeated = false
        )
        if (stats.first == stats.second && stats.second > 0) {
            recurringGoalManager.handleTaskCompletionForGoal(goalId, effectiveFrequency)
        }
    }
}
