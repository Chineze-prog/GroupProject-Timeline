package ca.umanitoba.cs.timeline.domain.goal

import ca.umanitoba.cs.timeline.domain.dayStatistic.DayStatisticRepository
import ca.umanitoba.cs.timeline.domain.dayStatistic.InvalidDayStatisticException
import java.time.Clock
import java.time.LocalDate
import javax.inject.Inject
import kotlin.time.Duration

class AddGoalTimeUseCase
@Inject
constructor(
    private val goalRepository: GoalRepository,
    private val dayStatisticRepository: DayStatisticRepository,
    private val clock: Clock
) {
    suspend operator fun invoke(goalId: Long, date: LocalDate, time: Duration) {
        if (dayStatisticRepository.getDayStatByGoalIdAndDate(date, goalId) == null) {
            dayStatisticRepository.addDayStat(date, goalId)
        }
        val currentDate = LocalDate.now(clock)

        if (date > currentDate) {
            throw InvalidDayStatisticException("Invalid date for statistics")
        } else {
            dayStatisticRepository.addTimeToStat(date, goalId, time)
            goalRepository.addTimeToGoal(goalId, time)
        }
    }
}
