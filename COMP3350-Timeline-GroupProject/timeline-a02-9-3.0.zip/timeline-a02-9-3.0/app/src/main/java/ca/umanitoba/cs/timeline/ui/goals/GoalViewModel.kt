package ca.umanitoba.cs.timeline.ui.goals

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ca.umanitoba.cs.timeline.domain.GetLocalDateUseCase
import ca.umanitoba.cs.timeline.domain.RecurrenceFrequency
import ca.umanitoba.cs.timeline.domain.goal.CategorizeAndSortGoalsUseCase
import ca.umanitoba.cs.timeline.domain.goal.DeleteGoalUseCase
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.domain.goal.UpdateGoalUseCase
import ca.umanitoba.cs.timeline.domain.recurringgoal.RecurringGoalRepository
import ca.umanitoba.cs.timeline.domain.recurringgoal.UpdateRecurringGoalUseCase
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import ca.umanitoba.cs.timeline.domain.timer.InvalidDeadlineException
import ca.umanitoba.cs.timeline.model.RecurringGoal
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

@HiltViewModel
class GoalViewModel
@Inject
constructor(
    private val goalRepository: GoalRepository,
    private val taskRepository: TaskRepository,
    private val updateGoalUseCase: UpdateGoalUseCase,
    private val goalEditDialogueState: GoalEditDialogState,
    private val categorizeAndSortGoalsUseCase: CategorizeAndSortGoalsUseCase,
    getLocalDateUseCase: GetLocalDateUseCase,
    private val deleteGoalUseCase: DeleteGoalUseCase,
    private val recurringGoalRepository: RecurringGoalRepository,
    private val updateRecurringGoalUseCase: UpdateRecurringGoalUseCase,
) : ViewModel() {
    val goals = goalRepository.getGoals()
    val recurringGoal = recurringGoalRepository.getRecurringGoals()
    val date = getLocalDateUseCase()

    val goalsByDeadlines = goals.map { categorizeAndSortGoalsUseCase(it) }

    fun getGoalEditDialogueState(): GoalEditDialogState {
        return goalEditDialogueState
    }

    fun addGoal(goalName: String) {
        viewModelScope.launch { goalRepository.addGoal(goalName) }
    }

    fun removeGoal(goalId: Long) {
        viewModelScope.launch { deleteGoalUseCase(goalId) }
    }

    fun updateGoal(goalId: Long, newName: String, deadline: LocalDate?) {
        viewModelScope.launch { goalRepository.updateGoal(goalId, newName, deadline) }
    }

    fun getTaskCompletionStats(goalId: Long): Flow<Pair<Int, Int>> {
        return taskRepository.getTaskCompletionForGoal(goalId)
    }

    fun updateGoalDeadline(goalId: Long, deadline: LocalDate?) {
        viewModelScope.launch {
            try {
                updateGoalUseCase(goalId, deadline = deadline)
            } catch (e: InvalidDeadlineException) {
                if (e.message == "Invalid Deadline") {
                    goalEditDialogueState.showErrorDialogue = true
                }
            }
        }
    }

    fun removeGoalDeadline(goalId: Long) {
        viewModelScope.launch { goalRepository.removeGoalDeadline(goalId) }
    }

    suspend fun getRecurringGoal(goalId: Long): RecurringGoal? {
        return recurringGoalRepository.getRecurringGoal(goalId)
    }

    fun removeRecurringGoal(goalId: Long) {
        viewModelScope.launch { recurringGoalRepository.deleteRecurringGoal(goalId) }
    }

    fun setRecurringGoal(
        goalId: Long,
        frequency: RecurrenceFrequency,
    ) {
        viewModelScope.launch { updateRecurringGoalUseCase(goalId, frequency) }
    }
}
