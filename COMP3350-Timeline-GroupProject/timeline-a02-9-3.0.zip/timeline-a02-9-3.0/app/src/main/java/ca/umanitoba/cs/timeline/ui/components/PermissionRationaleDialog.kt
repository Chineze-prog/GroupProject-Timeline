package ca.umanitoba.cs.timeline.ui.components

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun PermissionRationaleDialog(
    title: String,
    body: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    icon: @Composable () -> Unit = {},
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { Button(onClick = onConfirm) { Text("Allow") } },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Later") } },
        icon = icon,
        title = { Text(title) },
        text = { Text(body) }
    )
}
