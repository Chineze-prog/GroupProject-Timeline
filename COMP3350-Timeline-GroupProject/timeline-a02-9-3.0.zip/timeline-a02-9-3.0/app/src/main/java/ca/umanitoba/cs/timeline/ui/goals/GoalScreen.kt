package ca.umanitoba.cs.timeline.ui.goals

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.hilt.navigation.compose.hiltViewModel
import java.util.Calendar

@Composable
internal fun GoalScreen(
    onNavigateToTimer: (Long) -> Unit,
    onNavigateToStatistics: () -> Unit,
    viewModel: GoalViewModel = hiltViewModel()
) {
    val goals by viewModel.goals.collectAsState(emptyList())
    val date by viewModel.date.collectAsState(Calendar.getInstance().time)
    val recurringGoals by viewModel.recurringGoal.collectAsState(emptyList())
    var showAddGoalDialog by remember { mutableStateOf(false) }
    val invalidDeadlineErrorDialogue = viewModel.getGoalEditDialogueState()

    if (showAddGoalDialog) {
        GoalAlertDialog(
            initialName = "",
            title = "Add Goal",
            onDismissRequest = { showAddGoalDialog = false },
            onConfirm = { name,
                ->
                viewModel.addGoal(name)
                showAddGoalDialog = false
            },
        )
    }
    Column {
        GoalListUI(
            goals = goals,
            date = date,
            recurringGoals = recurringGoals,
            onNavigateToTimer = onNavigateToTimer,
            onNavigateToStatistics = onNavigateToStatistics,
            onRemoveGoal = viewModel::removeGoal,
            onUpdateGoal = viewModel::updateGoal,
            onUpdateGoalDeadline = viewModel::updateGoalDeadline,
            onRemoveGoalDeadline = viewModel::removeGoalDeadline,
            onRemoveRecurringGoal = viewModel::removeRecurringGoal,
            viewModel = viewModel,
            onSetRecurringGoal = viewModel::setRecurringGoal,
        )
        Button(modifier = Modifier.fillMaxWidth(), onClick = { showAddGoalDialog = true }) {
            Text("Add Goal")
        }
    }

    if (invalidDeadlineErrorDialogue.showErrorDialogue) {
        AlertDialog(
            title = {
                Text(text = invalidDeadlineErrorDialogue.value, textAlign = TextAlign.Center)
            },
            onDismissRequest = { invalidDeadlineErrorDialogue.showErrorDialogue = false },
            confirmButton = {
                Button(onClick = { invalidDeadlineErrorDialogue.showErrorDialogue = false }) {
                    Text("OK")
                }
            }
        )
    }
}
