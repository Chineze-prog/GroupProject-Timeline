package ca.umanitoba.cs.timeline.ui.timer

import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import kotlin.time.Duration

private const val goalIdArg = "goalId"
private const val timerRoute = "timer/{$goalIdArg}"

internal class TimerArgs(val goalId: Long) {
    constructor(
        savedStateHandle: SavedStateHandle
    ) : this(checkNotNull(savedStateHandle[goalIdArg]) as Long)
}

fun NavGraphBuilder.timerScreen() {
    composable(timerRoute, arguments = listOf(navArgument(goalIdArg) { type = NavType.LongType })) {
        val viewModel = hiltViewModel<TimerViewModel>()
        val timerState by viewModel.timerState.collectAsState()
        val pomodoroState by viewModel.pomodoroState.collectAsState()
        val tasks by viewModel.tasks.collectAsState(emptyList())
        val goalName by viewModel.goalName.collectAsState("")
        val goalTime by viewModel.goalTime.collectAsState(Duration.ZERO)

        TimerScreen(
            timerState = timerState,
            pomodoroState = pomodoroState.state,
            tasks = tasks,
            goalName = goalName,
            goalTime = goalTime,
            onTimerStart = viewModel::startTimer,
            onTimerStop = viewModel::stopTimer,
            onPomodoroSkip = viewModel::skipPomodoro,
            onTaskMove = viewModel::moveTask,
            onTaskAdd = viewModel::addTask,
            onTaskNameUpdate = viewModel::editTask,
            onTaskRemove = viewModel::removeTask,
            onTaskCompleteUpdate = viewModel::onCompletionTask,
        )
    }
}

fun NavController.navigateToTimer(goalId: Long) =
    this.navigate(timerRoute.replace("{$goalIdArg}", goalId.toString()))
