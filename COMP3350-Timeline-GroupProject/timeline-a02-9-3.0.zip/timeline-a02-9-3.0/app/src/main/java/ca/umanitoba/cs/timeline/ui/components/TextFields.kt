package ca.umanitoba.cs.timeline.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun LengthRestrictedTextField(
    state: TextFieldState,
    onValueChange: (TextFieldValue) -> Unit,
    limits: IntRange,
    modifier: Modifier = Modifier,
    label: @Composable () -> Unit = {},
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions(),
    maxLines: Int = Int.MAX_VALUE
) {
    LaunchedEffect(state.value.text) {
        state.isError =
            state.value.text.length !in limits || state.value.text.trim().length !in limits
    }
    OutlinedTextField(
        value = state.value,
        onValueChange = onValueChange,
        modifier = modifier,
        label = label,
        isError = state.isError,
        supportingText = {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (limits.first > 0) {
                    Row {
                        Text("Required")
                        Spacer(modifier = Modifier.width(16.dp))
                    }
                }
                Text(
                    "${state.value.text.length}/${limits.last}",
                    textAlign = TextAlign.End,
                    modifier = Modifier.weight(1f)
                )
            }
        },
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        maxLines = maxLines
    )
}

@Preview(showBackground = true)
@Composable
fun PreviewLengthRestrictedTextField() {
    val state = TextFieldState("Some text")
    LengthRestrictedTextField(state, onValueChange = {}, limits = 1..100)
}

@Preview(showBackground = true)
@Composable
fun PreviewLengthRestrictedTextFieldError() {
    val state = TextFieldState("Some very long text", isError = false)
    LengthRestrictedTextField(
        state,
        onValueChange = {},
        limits = 0..10,
        label = { Text("Some input*") }
    )
}
