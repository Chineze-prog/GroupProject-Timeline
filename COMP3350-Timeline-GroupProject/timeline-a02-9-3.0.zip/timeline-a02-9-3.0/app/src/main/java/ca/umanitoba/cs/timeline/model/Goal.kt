package ca.umanitoba.cs.timeline.model

import java.time.LocalDate
import kotlin.time.Duration

data class Goal(
    val id: Long,
    val name: String,
    val deadline: LocalDate? = null,
    val unallocatedTimeSpent: Duration = Duration.ZERO,
    val allocatedTimeSpent: Duration = Duration.ZERO,
)
