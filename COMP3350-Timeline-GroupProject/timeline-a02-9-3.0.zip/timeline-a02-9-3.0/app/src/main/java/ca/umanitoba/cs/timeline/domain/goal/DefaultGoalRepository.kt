package ca.umanitoba.cs.timeline.domain.goal

import ca.umanitoba.cs.timeline.data.GoalDao
import ca.umanitoba.cs.timeline.model.Goal
import java.time.LocalDate
import javax.inject.Inject
import kotlin.time.Duration
import kotlinx.coroutines.flow.Flow

class DefaultGoalRepository @Inject constructor(private val goalDataSource: GoalDao) :
    GoalRepository {
    override fun getGoals(): Flow<List<Goal>> = goalDataSource.getGoals()

    override suspend fun addGoal(name: String): Long = goalDataSource.addGoal(name)

    override suspend fun updateGoal(id: Long, name: String?, deadline: LocalDate?) =
        goalDataSource.updateGoal(id, name, deadline)

    override suspend fun deleteGoal(id: Long) = goalDataSource.deleteGoal(id)

    override suspend fun getGoal(id: Long): Goal? = goalDataSource.getGoal(id)

    override fun getObservableGoal(id: Long): Flow<Goal> = goalDataSource.getObservableGoal(id)

    override suspend fun addTimeToGoal(id: Long, time: Duration) =
        goalDataSource.addTimeToGoal(id, time)

    override suspend fun allocateTime(id: Long) = goalDataSource.allocateTime(id)

    override suspend fun removeGoalDeadline(id: Long) = goalDataSource.removeGoalDeadline(id)
}
