import com.diffplug.gradle.spotless.SpotlessTask

plugins {
    alias(libs.plugins.sqldelight)
    alias(libs.plugins.android.application)
    alias(libs.plugins.android.code.quality)
    alias(libs.plugins.android.junit5)
    alias(libs.plugins.hilt)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.ksp)
    alias(libs.plugins.spotless)
}

android {
    namespace = "ca.umanitoba.cs.timeline"
    compileSdk = 34
    defaultConfig {
        applicationId = "ca.umanitoba.cs.timeline"
        minSdk = 23
        targetSdk = 34
        versionCode = 4
        versionName = "2.2-${System.getenv("VERSION_SHA")}"
        testInstrumentationRunner = "ca.umanitoba.cs.timeline.TimelineJUnitRunner"
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }
    buildFeatures { compose = true }
    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.10" }
    @Suppress("UnstableApiUsage") testOptions { unitTests { isIncludeAndroidResources = true } }
}

hilt { enableAggregatingTask = true }

sqldelight { databases { create("Database") { packageName = "ca.umanitoba.cs.timeline" } } }

codeQuality {
    reportsDirectory.set(layout.buildDirectory.dir("reports"))
    issuesFile.set(reportsDirectory.file("code-quality-issues.json"))
}

spotless {
    format("misc") {
        target(".gitattributes", ".gitignore")

        trimTrailingWhitespace()
        indentWithSpaces(2)
        endWithNewline()
    }
    kotlin {
        target("**/*.kt")
        ktfmt("0.47").kotlinlangStyle()
    }
    kotlinGradle { ktfmt("0.47").kotlinlangStyle() }
}

tasks.named("collectCodeQualityIssues") { dependsOn("lint") }

tasks.named("lint") { dependsOn("spotlessCheck") }

tasks.withType<SpotlessTask>().configureEach {
    notCompatibleWithConfigurationCache("https://github.com/diffplug/spotless/issues/987")
}

kotlin { jvmToolchain(17) }

dependencies {
    val composeBom = platform(libs.compose.bom)
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation(libs.sqldelight.android)
    implementation(libs.sqldelight.coroutines)
    implementation(libs.activity.compose)
    implementation(libs.compose.material3)
    implementation(libs.lifecycle.compose)
    implementation(libs.accompanist.permissions)
    implementation(libs.android.material)
    implementation(libs.calvin.reorderable)
    implementation(libs.vico.compose)
    implementation(libs.vico.compose.m3)
    implementation(libs.vico.core)
    // Hilt dependency injection
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)

    // Android Studio Preview support
    implementation(libs.compose.preview)
    debugImplementation(libs.compose.ui.tooling)

    // Compose Navigation
    implementation(libs.compose.navigation)
    implementation(libs.hilt.compose.navigation)

    // Java 8+ classes support for API < 26
    coreLibraryDesugaring(libs.desugar.jdk)

    // For compose tests
    debugImplementation(project(":ui-test-hilt-manifest"))

    testImplementation(libs.sqldelight.sqlite)
    testImplementation(libs.sqlite.jdbc)

    testImplementation(libs.androidx.test.runner)
    testImplementation(libs.androidx.test.junit.ktx)
    testImplementation(libs.junit.suite.api)
    testImplementation(libs.jupiter.api)
    testImplementation(libs.coroutines.test)
    testImplementation(libs.mockk)
    testRuntimeOnly(libs.junit.suite.engine)
    testRuntimeOnly(libs.jupiter.engine)

    // Acceptance-test-as-unit-test via Robolectric
    testDebugImplementation(project(":app-shared-tests"))
    testDebugImplementation(project(":ui-test-hilt-manifest"))
    testDebugImplementation(libs.hilt.testing)
    testDebugImplementation(libs.junit4)
    testDebugImplementation(libs.robolectric)
    testDebugRuntimeOnly(libs.junit.vintage.engine)

    androidTestImplementation(project(":app-shared-tests"))
    androidTestImplementation(libs.androidx.test.runner)
    androidTestImplementation(libs.androidx.test.junit.ktx)
    androidTestImplementation(libs.hilt.testing)
}
