plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.ksp)
    alias(libs.plugins.spotless)
}

android {
    namespace = "ca.umanitoba.cs.timeline.test"
    compileSdk = 34

    defaultConfig { minSdk = 23 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions { jvmTarget = "1.8" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.10" }
}

spotless {
    format("misc") {
        target(".gitattributes", ".gitignore")

        trimTrailingWhitespace()
        indentWithSpaces(2)
        endWithNewline()
    }
    kotlin {
        target("**/*.kt")
        ktfmt("0.47").kotlinlangStyle()
    }
    kotlinGradle { ktfmt("0.47").kotlinlangStyle() }
}

dependencies {
    implementation(project(":app"))

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.test.junit4)

    implementation(libs.junit4)
    implementation(libs.androidx.test.ktx)
    implementation(libs.androidx.test.runner)
    implementation(libs.androidx.test.rules)
    implementation(libs.coroutines.test)

    // Hilt
    implementation(libs.hilt.android)
    implementation(libs.hilt.testing)
    implementation(project(":ui-test-hilt-manifest"))
    ksp(libs.hilt.compiler)

    // Navigation
    implementation(libs.compose.navigation)
    implementation(libs.navigation.testing)
}
