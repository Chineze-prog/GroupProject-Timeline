package ca.umanitoba.cs.timeline.test.ui.recurringgoal

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotDisplayed
import androidx.compose.ui.test.click
import androidx.compose.ui.test.hasAnySibling
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.hasTextExactly
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onChild
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onParent
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.printToString
import androidx.compose.ui.test.swipeDown
import androidx.compose.ui.test.swipeLeft
import androidx.compose.ui.test.swipeUp
import androidx.navigation.compose.ComposeNavigator
import androidx.navigation.testing.TestNavHostController
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import ca.umanitoba.cs.timeline.test.ui.timer.BaseTimerScreenTest
import ca.umanitoba.cs.timeline.ui.TimelineNavGraph
import ca.umanitoba.cs.timeline.uitesthiltmanifest.HiltComponentActivity
import ca.umanitoba.cs.timeline.utils.DateUtils
import dagger.hilt.android.testing.HiltAndroidRule
import java.time.Clock
import java.time.Instant
import java.time.ZoneId
import javax.inject.Inject
import kotlinx.coroutines.runBlocking
import org.junit.Before
import org.junit.Rule
import org.junit.Test

abstract class BaseRecurringGoalTest {

    @get:Rule(order = 0) abstract val hiltRule: HiltAndroidRule

    @get:Rule(order = 1) val composeTestRule = createAndroidComposeRule<HiltComponentActivity>()

    @Inject lateinit var goalRepository: GoalRepository

    @Inject lateinit var taskRepository: TaskRepository

    @Inject lateinit var clock: Clock

    @Inject lateinit var zoneId: ZoneId

    private lateinit var navController: TestNavHostController

    @RequiresApi(Build.VERSION_CODES.O)
    @Before
    fun setup() {
        hiltRule.inject()
        runBlocking {
            val testGoalId = goalRepository.addGoal(BaseTimerScreenTest.TEST_GOAL_NAME)
            taskRepository.addTask(testGoalId, BaseTimerScreenTest.TEST_TASK_NAME_ONE)
            taskRepository.addTask(testGoalId, BaseTimerScreenTest.TEST_TASK_NAME_TWO)
        }

        composeTestRule.setContent {
            navController = TestNavHostController(LocalContext.current)
            navController.navigatorProvider.addNavigator(ComposeNavigator())
            TimelineNavGraph(navController = navController)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    @Test
    fun recurringGoalCanBeSet() {
        with(composeTestRule) {
            onNodeWithText(BaseTimerScreenTest.TEST_GOAL_NAME).assertIsDisplayed()

            onNodeWithContentDescription("Frequency").apply {
                assertIsDisplayed()
                performClick()
            }
            onNodeWithText("Daily").assertIsDisplayed()
            onNodeWithText("Weekly").assertIsDisplayed()
            onNodeWithText("Monthly").apply {
                assertIsDisplayed()
                performClick()
            }

            onRoot().performTouchInput {
                swipeUp()
                swipeUp()
            }
            println(onRoot().printToString())
            onNodeWithText("Frequency: Monthly")
            onNodeWithText("Deadline: ", substring = true)
        }
    }

    @Test
    fun completedAllTheTasksAndRepeated() {

        with(composeTestRule) {
            onNodeWithText(BaseTimerScreenTest.TEST_GOAL_NAME).assertIsDisplayed()
            onNodeWithText(BaseTimerScreenTest.TEST_GOAL_NAME).performTouchInput {
                click(centerLeft)
            }
            onNode(
                    hasText("Current goal") and
                        hasAnySibling(hasText(BaseTimerScreenTest.TEST_GOAL_NAME))
                )
                .assertIsDisplayed()

            onNodeWithText("Current goal").onParent().performTouchInput {
                swipeUp()
                swipeUp()
            }
            onNodeWithText(BaseTimerScreenTest.TEST_TASK_NAME_ONE).onChild().performClick()

            onNodeWithText(BaseTimerScreenTest.TEST_TASK_NAME_TWO).onChild().performClick()

            composeTestRule.runOnUiThread { navController.navigate("goals") }
            onRoot().performTouchInput { swipeDown() }

            onNodeWithContentDescription("Frequency").apply {
                assertIsDisplayed()
                performClick()
            }

            onNodeWithText("Daily").apply {
                assertIsDisplayed()
                performClick()
            }
            onRoot().performTouchInput {
                swipeDown()
                swipeDown()
            }

            onNodeWithText("100% Complete").assertIsDisplayed()
        }
    }

    @Test
    fun datePickerBeforeRepeated() {
        with(composeTestRule) {
            onNodeWithContentDescription("Deadline").apply {
                assertIsDisplayed()
                performClick()
            }

            onNodeWithContentDescription("Switch to text input mode").performClick()

            onNode(hasTextExactly("Date"), useUnmergedTree = true).apply {
                onParent().performClick()
                onParent().performTextClearance()
                onParent().performTextInput("10102025")
            }
            onNodeWithText("Oct 10, 2025").assertIsDisplayed()
            onNodeWithText("Confirm").performClick()
            onNodeWithText("Deadline: October 10, 2025").assertIsDisplayed()

            onNodeWithContentDescription("Frequency").apply {
                assertIsDisplayed()
                performClick()
            }

            onNodeWithText("Daily").apply {
                assertIsDisplayed()
                performClick()
            }

            onRoot().performTouchInput { swipeDown() }

            onNodeWithText(BaseTimerScreenTest.TEST_GOAL_NAME).performTouchInput {
                click(centerLeft)
            }

            onNodeWithText("Current goal").onParent().performTouchInput {
                swipeUp()
                swipeUp()
            }

            onNodeWithText(BaseTimerScreenTest.TEST_TASK_NAME_ONE).onChild().apply {
                performClick()
            }

            onNodeWithText(BaseTimerScreenTest.TEST_TASK_NAME_TWO).onChild().apply {
                performClick()
            }
            composeTestRule.runOnUiThread { navController.navigate("goals") }

            onRoot().performTouchInput {
                swipeUp()
                swipeUp()
            }

            onRoot().performTouchInput {
                swipeUp()
                swipeUp()
            }

            onAllNodesWithText(BaseTimerScreenTest.TEST_GOAL_NAME).assertCountEquals(2)
            onAllNodesWithText("Frequency: Daily").assertCountEquals(2)

            onAllNodesWithText(BaseTimerScreenTest.TEST_GOAL_NAME)[0].assertIsDisplayed()
            onAllNodesWithText("Frequency: Daily")[0].assertIsDisplayed()

            onAllNodesWithText(BaseTimerScreenTest.TEST_GOAL_NAME)[1].assertIsDisplayed()
            onAllNodesWithText("Frequency: Daily")[1].assertIsDisplayed()
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    @Test
    fun removingTaskToRepeated() {
        with(composeTestRule) {
            val tomorrow = Instant.now(clock).atZone(zoneId).toLocalDate().plusDays(1)
            onNodeWithText(BaseTimerScreenTest.TEST_GOAL_NAME).assertIsDisplayed()
            onNodeWithContentDescription("Frequency").apply {
                assertIsDisplayed()
                performClick()
            }
            onNodeWithText("Daily").apply {
                assertIsDisplayed()
                performClick()
            }

            onRoot().performTouchInput { swipeDown() }

            onNodeWithText(BaseTimerScreenTest.TEST_GOAL_NAME).performTouchInput {
                click(centerLeft)
            }

            onNodeWithText("Current goal").onParent().performTouchInput {
                swipeUp()
                swipeUp()
            }

            onNodeWithText(BaseTimerScreenTest.TEST_TASK_NAME_TWO).onChild().apply {
                performClick()
            }

            onNodeWithText(BaseTimerScreenTest.TEST_TASK_NAME_ONE).performTouchInput { swipeLeft() }

            composeTestRule.runOnUiThread { navController.navigate("goals") }

            onRoot().performTouchInput {
                swipeDown()
                swipeDown()
            }

            composeTestRule.onAllNodesWithText(BaseTimerScreenTest.TEST_GOAL_NAME)[1].apply {
                onNodeWithText("Frequency: Daily")
                onNodeWithText("Deadline: ${DateUtils.localDateToString(tomorrow)}")
            }
        }
    }

    @Test
    fun cancelDatePickWillCancelFrequency() {
        with(composeTestRule) {
            onNodeWithContentDescription("Deadline").apply {
                assertIsDisplayed()
                performClick()
            }

            onNodeWithContentDescription("Switch to text input mode").performClick()

            onNode(hasTextExactly("Date"), useUnmergedTree = true).apply {
                onParent().performClick()
                onParent().performTextClearance()
                onParent().performTextInput("10102025")
            }
            onNodeWithText("Oct 10, 2025").assertIsDisplayed()
            onNodeWithText("Confirm").performClick()

            onRoot().performTouchInput { swipeDown() }

            onNodeWithContentDescription("Frequency").performClick()

            onNodeWithText("Daily").apply {
                assertIsDisplayed()
                performClick()
            }
            onRoot().performTouchInput { swipeDown() }

            onNodeWithContentDescription("Deadline").apply {
                assertIsDisplayed()
                performClick()
            }
            onNodeWithContentDescription("Switch to text input mode").performClick()
            onNode(hasTextExactly("Date"), true).apply {
                onParent().performClick()
                onParent().performTextClearance()
                onParent().performTextInput("05122020")
            }
            onNodeWithText("May 12, 2020").assertIsDisplayed()
            onNodeWithText("Confirm").performClick()
            onNodeWithText("Invalid deadline", true).assertIsDisplayed()
            onNodeWithText("OK").performClick()
            onNodeWithText("Cancel/Remove").performClick()
            onNodeWithText("YES").performClick()

            onRoot().performTouchInput {
                swipeDown()

                swipeDown()
            }

            onNodeWithText("Deadline: October 10, 2025").assertIsNotDisplayed()
            onNodeWithText("Frequency: Daily").assertIsNotDisplayed()
        }
    }
}
