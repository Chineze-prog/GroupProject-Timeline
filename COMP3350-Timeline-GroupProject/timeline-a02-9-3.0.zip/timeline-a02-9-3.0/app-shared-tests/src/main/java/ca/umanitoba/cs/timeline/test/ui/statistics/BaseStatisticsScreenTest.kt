package ca.umanitoba.cs.timeline.test.ui.statistics

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.navigation.compose.ComposeNavigator
import androidx.navigation.testing.TestNavHostController
import ca.umanitoba.cs.timeline.domain.dayStatistic.DayStatisticRepository
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.ui.TimelineNavGraph
import ca.umanitoba.cs.timeline.ui.statistics.navigateToStatistics
import ca.umanitoba.cs.timeline.uitesthiltmanifest.HiltComponentActivity
import dagger.hilt.android.testing.HiltAndroidRule
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import javax.inject.Inject
import kotlin.time.Duration.Companion.minutes
import kotlinx.coroutines.runBlocking
import org.junit.Before
import org.junit.Rule
import org.junit.Test

abstract class BaseStatisticsScreenTest {

    @get:Rule(order = 0) abstract val hiltRule: HiltAndroidRule

    @get:Rule(order = 1) val composeTestRule = createAndroidComposeRule<HiltComponentActivity>()

    @Inject lateinit var goalRepository: GoalRepository

    @Inject lateinit var dayStatisticRepository: DayStatisticRepository

    @RequiresApi(Build.VERSION_CODES.O)
    @Before
    fun setup() {
        hiltRule.inject()
        lateinit var navController: TestNavHostController
        runBlocking {
            val goal1 = goalRepository.addGoal("Goal 1")
            val goal2 = goalRepository.addGoal("Goal 2")
            val goal3 = goalRepository.addGoal("Goal 3")
            val goal4 = goalRepository.addGoal("Goal 4")
            val goal5 = goalRepository.addGoal("Goal 5")
            val goal6 = goalRepository.addGoal("Goal 6")
            val goal7 = goalRepository.addGoal("Goal 7")

            val currentDate = LocalDate.now()
            val monday = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            val sunday = LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY))

            val february = LocalDate.now().withMonth(2)
            val march = LocalDate.now().withMonth(3)
            val june = LocalDate.now().withMonth(5)

            val year2023 = LocalDate.now().withYear(2023)
            val year2022 = LocalDate.now().withYear(2022)
            val year2019 = LocalDate.now().withYear(2019)

            dayStatisticRepository.addDayStat(currentDate, goal1)
            dayStatisticRepository.addDayStat(currentDate, goal3)
            dayStatisticRepository.addDayStat(monday, goal1)
            dayStatisticRepository.addDayStat(sunday, goal2)
            dayStatisticRepository.addDayStat(sunday, goal3)

            dayStatisticRepository.addTimeToStat(currentDate, goal1, 50.minutes)
            dayStatisticRepository.addTimeToStat(currentDate, goal3, 25.minutes)
            dayStatisticRepository.addTimeToStat(monday, goal1, 21.minutes)
            dayStatisticRepository.addTimeToStat(sunday, goal2, 43.minutes)
            dayStatisticRepository.addTimeToStat(sunday, goal3, 30.minutes)

            dayStatisticRepository.addDayStat(february, goal2)
            dayStatisticRepository.addDayStat(march, goal3)
            dayStatisticRepository.addDayStat(march, goal4)
            dayStatisticRepository.addDayStat(june, goal4)
            dayStatisticRepository.addDayStat(june, goal5)
            dayStatisticRepository.addDayStat(june, goal6)

            dayStatisticRepository.addTimeToStat(february, goal2, 15.minutes)
            dayStatisticRepository.addTimeToStat(march, goal3, 75.minutes)
            dayStatisticRepository.addTimeToStat(march, goal4, 17.minutes)
            dayStatisticRepository.addTimeToStat(june, goal4, 28.minutes)
            dayStatisticRepository.addTimeToStat(june, goal5, 41.minutes)
            dayStatisticRepository.addTimeToStat(june, goal6, 15.minutes)

            dayStatisticRepository.addDayStat(year2023, goal1)
            dayStatisticRepository.addDayStat(year2022, goal1)
            dayStatisticRepository.addDayStat(year2022, goal7)
            dayStatisticRepository.addDayStat(year2022, goal6)
            dayStatisticRepository.addDayStat(year2019, goal7)
            dayStatisticRepository.addDayStat(year2019, goal5)

            dayStatisticRepository.addTimeToStat(year2023, goal1, 15.minutes)
            dayStatisticRepository.addTimeToStat(year2022, goal1, 10.minutes)
            dayStatisticRepository.addTimeToStat(year2022, goal7, 38.minutes)
            dayStatisticRepository.addTimeToStat(year2022, goal6, 65.minutes)
            dayStatisticRepository.addTimeToStat(year2019, goal7, 29.minutes)
            dayStatisticRepository.addTimeToStat(year2019, goal5, 55.minutes)
        }

        composeTestRule.setContent {
            navController = TestNavHostController(LocalContext.current)
            navController.navigatorProvider.addNavigator(ComposeNavigator())

            LaunchedEffect(Unit) { navController.navigateToStatistics() }
            TimelineNavGraph(navController = navController)
        }
    }

    @Test
    fun viewWeeklyStats() {
        with(composeTestRule) {
            onNodeWithText("Select Option").performClick()

            onNodeWithText("Weekly").apply {
                assertIsDisplayed()
                performClick()
            }
            onNodeWithText("Your Trends").assertIsDisplayed()
            onNodeWithText("Weekly").assertIsDisplayed()
            onNodeWithText("Overall Time Logged").assertIsDisplayed()
            onNodeWithText("Time Spent On Goals").assertIsDisplayed()
            onNodeWithText("Select Option").assertIsNotDisplayed()

            // Cannot check graph with assertions, sleep so tester can manually look at graphs
            Thread.sleep(5000)
        }
    }

    @Test
    fun viewMonthlyStats() {
        with(composeTestRule) {
            onNodeWithText("Select Option").performClick()

            onNodeWithText("Monthly").apply {
                assertIsDisplayed()
                performClick()
            }
            onNodeWithText("Your Trends").assertIsDisplayed()
            onNodeWithText("Monthly").assertIsDisplayed()
            onNodeWithText("Overall Time Logged").assertIsDisplayed()
            onNodeWithText("Time Spent On Goals").assertIsDisplayed()
            onNodeWithText("Select Option").assertIsNotDisplayed()

            // Cannot check graph with assertions, sleep so tester can manually look at graphs
            Thread.sleep(5000)
        }
    }

    @Test
    fun viewYearlyStats() {
        with(composeTestRule) {
            onNodeWithText("Select Option").performClick()

            onNodeWithText("Yearly").apply {
                assertIsDisplayed()
                performClick()
            }
            onNodeWithText("Your Trends").assertIsDisplayed()
            onNodeWithText("Yearly").assertIsDisplayed()
            onNodeWithText("Overall Time Logged").assertIsDisplayed()
            onNodeWithText("Time Spent On Goals").assertIsDisplayed()
            onNodeWithText("Select Option").assertIsNotDisplayed()

            // Cannot check graph with assertions, sleep so tester can manually look at graphs
            Thread.sleep(5000)
        }
    }

    @Test
    fun switchBetweenTimePeriods() {
        with(composeTestRule) {
            onNodeWithText("Select Option").performClick()

            onNodeWithText("Weekly").apply {
                assertIsDisplayed()
                performClick()
            }

            onNodeWithText("Your Trends").assertIsDisplayed()
            onNodeWithText("Select Option").assertIsNotDisplayed()
            Thread.sleep(2000)

            onNodeWithText("Weekly").apply {
                assertIsDisplayed()
                performClick()
            }

            onNodeWithText("Monthly").apply {
                assertIsDisplayed()
                performClick()
            }

            onNodeWithText("Your Trends").assertIsDisplayed()
            onNodeWithText("Select Option").assertIsNotDisplayed()
            Thread.sleep(2000)

            onNodeWithText("Monthly").apply {
                assertIsDisplayed()
                performClick()
            }

            onNodeWithText("Yearly").apply {
                assertIsDisplayed()
                performClick()
            }

            onNodeWithText("Your Trends").assertIsDisplayed()
            onNodeWithText("Select Option").assertIsNotDisplayed()
            Thread.sleep(2000)
        }
    }
}
