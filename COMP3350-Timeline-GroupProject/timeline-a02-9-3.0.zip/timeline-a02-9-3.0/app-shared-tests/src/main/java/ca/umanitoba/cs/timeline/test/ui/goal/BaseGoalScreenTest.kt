package ca.umanitoba.cs.timeline.test.ui.goal

import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotDisplayed
import androidx.compose.ui.test.assertIsOff
import androidx.compose.ui.test.assertIsToggleable
import androidx.compose.ui.test.click
import androidx.compose.ui.test.hasAnySibling
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.hasTextExactly
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onChild
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onParent
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeDown
import androidx.compose.ui.test.swipeLeft
import androidx.compose.ui.test.swipeUp
import androidx.navigation.compose.ComposeNavigator
import androidx.navigation.testing.TestNavHostController
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import ca.umanitoba.cs.timeline.ui.TimelineNavGraph
import ca.umanitoba.cs.timeline.uitesthiltmanifest.HiltComponentActivity
import dagger.hilt.android.testing.HiltAndroidRule
import javax.inject.Inject
import kotlinx.coroutines.runBlocking
import org.junit.Before
import org.junit.Rule
import org.junit.Test

abstract class BaseGoalScreenTest {

    @get:Rule(order = 0) abstract val hiltRule: HiltAndroidRule

    @get:Rule(order = 1) val composeTestRule = createAndroidComposeRule<HiltComponentActivity>()

    @Inject lateinit var goalRepository: GoalRepository

    @Inject lateinit var taskRepository: TaskRepository

    companion object {
        const val TEST_TASK_NAME_ONE = "Test task 1"
        const val TEST_TASK_NAME_TWO = "Test task 2"
    }

    @Before
    fun setup() {
        hiltRule.inject()
        lateinit var navController: TestNavHostController
        runBlocking {
            val goalId = goalRepository.addGoal("Goal")
            taskRepository.addTask(goalId, TEST_TASK_NAME_ONE)
            taskRepository.addTask(goalId, TEST_TASK_NAME_TWO)
        }

        composeTestRule.setContent {
            navController = TestNavHostController(LocalContext.current)
            navController.navigatorProvider.addNavigator(ComposeNavigator())

            TimelineNavGraph(navController = navController)
        }
    }

    @Test
    fun creatingAGoal() {
        with(composeTestRule) {
            // clicks on the "add Goal" button to add a new goal
            onNodeWithText("Add Goal").apply {
                assertIsDisplayed()
                performClick()
            }

            // enters the name of the new goal
            onNodeWithText("Goal Name*").apply {
                performClick()
                performTextInput("New Goal")
                onNodeWithText("Confirm").performClick()
            }

            // Swipe to load goal list in robolectric
            onRoot().performTouchInput { swipeDown() }

            // verifies the goal is displayed
            onNodeWithText("New Goal").assertIsDisplayed()
        }
    }

    @Test
    fun editingAGoal() {
        with(composeTestRule) {
            onNodeWithText("Goal").assertIsDisplayed()

            // rename the goal
            onNodeWithContentDescription("Edit").apply {
                assertIsDisplayed()
                performClick()

                onNodeWithText("Goal Name*").apply {
                    performClick()
                    performTextClearance()
                    performTextInput("Test Goal")
                }

                onNodeWithText("Confirm").performClick()
            }

            // Swipe to load goal list in robolectric
            onRoot().performTouchInput { swipeDown() }

            // verifies the goal has been renamed
            onNodeWithText("Test Goal").assertIsDisplayed()
        }
    }

    @Test
    fun deletingAGoal() {
        with(composeTestRule) {
            // swipes a goal to delete it
            onNodeWithText("Goal").performTouchInput { swipeLeft() }

            // verifies the goal has been removed
            onNodeWithText("Goal").assertDoesNotExist()
        }
    }

    @Test
    fun navigateFromAGoalToItsTasks() {
        with(composeTestRule) {
            // verifies the goal is displayed
            onNodeWithText("Goal").assertIsDisplayed()

            // clicking on a goal leads to its tasks
            onNodeWithText("Goal").performTouchInput { click(centerLeft) }
            onNode(hasText("Current goal") and hasAnySibling(hasText("Goal"))).assertIsDisplayed()
        }
    }

    @Test
    fun settingGoalDeadline() {
        with(composeTestRule) {
            onNodeWithContentDescription("Deadline").apply {
                assertIsDisplayed()
                performClick()
            }

            onNodeWithContentDescription("Switch to text input mode").performClick()

            onNode(hasTextExactly("Date"), useUnmergedTree = true).apply {
                onParent().performClick()
                onParent().performTextClearance()
                onParent().performTextInput("10102025")
            }

            onNodeWithText("Oct 10, 2025").assertIsDisplayed()
            onNodeWithText("Confirm").performClick()
            onNodeWithText("Deadline: October 10, 2025").assertIsDisplayed()
        }
    }

    @Test
    fun cannotSetGoalInvalidDeadline() {
        with(composeTestRule) {
            onNodeWithContentDescription("Deadline").apply {
                assertIsDisplayed()
                performClick()
            }
            onNodeWithContentDescription("Switch to text input mode").performClick()
            onNode(hasTextExactly("Date"), true).apply {
                onParent().performClick()
                onParent().performTextClearance()
                onParent().performTextInput("05122020")
            }
            onNodeWithText("May 12, 2020").assertIsDisplayed()
            onNodeWithText("Confirm").performClick()
            onNodeWithText("Invalid deadline", true).assertIsDisplayed()
            onNodeWithText("OK").performClick()
            onNodeWithText("Cancel/Remove").performClick()
            onNodeWithText("NO").performClick()
            onNodeWithText("Deadline: May 12, 2020").assertIsNotDisplayed()
        }
    }

    @Test
    fun goalProgressUpdatesOnTaskCompletion() {
        with(composeTestRule) {
            onNodeWithText("Goal").assertIsDisplayed()

            onNodeWithText("0% Complete").assertIsDisplayed()

            // clicking on a goal leads to its tasks
            onNodeWithText("Goal").performTouchInput { click(centerLeft) }
            onNode(hasText("Current goal") and hasAnySibling(hasText("Goal"))).assertIsDisplayed()

            onNodeWithText("Current goal").onParent().performTouchInput { swipeUp() }

            onNodeWithText(TEST_TASK_NAME_ONE).onChild().apply {
                assertIsToggleable()
                assertIsOff()
                performClick()
            }

            activityRule.scenario.onActivity { activity ->
                activity.onBackPressedDispatcher.onBackPressed()
            }

            onNodeWithText("Goal").assertIsDisplayed()
            onNodeWithText("50% Complete").assertIsDisplayed()
        }
    }
}
