package ca.umanitoba.cs.timeline.test.ui.timer

import android.os.Build
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertIsOff
import androidx.compose.ui.test.assertIsToggleable
import androidx.compose.ui.test.hasAnySibling
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.hasTextExactly
import androidx.compose.ui.test.isDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onChild
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onParent
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextClearance
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeLeft
import androidx.compose.ui.test.swipeUp
import androidx.navigation.compose.ComposeNavigator
import androidx.navigation.testing.TestNavHostController
import androidx.test.rule.GrantPermissionRule
import ca.umanitoba.cs.timeline.domain.goal.GoalRepository
import ca.umanitoba.cs.timeline.domain.task.TaskRepository
import ca.umanitoba.cs.timeline.ui.TimelineNavGraph
import ca.umanitoba.cs.timeline.ui.timer.navigateToTimer
import ca.umanitoba.cs.timeline.uitesthiltmanifest.HiltComponentActivity
import dagger.hilt.android.testing.HiltAndroidRule
import javax.inject.Inject
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.runBlocking
import org.junit.Before
import org.junit.Rule
import org.junit.Test

abstract class BaseTimerScreenTest {
    @get:Rule(order = 0) abstract val hiltRule: HiltAndroidRule

    @get:Rule(order = 1) val composeTestRule = createAndroidComposeRule<HiltComponentActivity>()

    @get:Rule(order = 2)
    val notificationPermissionRule: GrantPermissionRule =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            GrantPermissionRule.grant(android.Manifest.permission.POST_NOTIFICATIONS)
        else GrantPermissionRule.grant()

    @Inject lateinit var goalRepository: GoalRepository

    @Inject lateinit var taskRepository: TaskRepository

    /** Skip time to speed test up if possible. No error otherwise */
    abstract fun skipTime(duration: Duration)

    private var testGoalId: Long = 0

    companion object {
        const val TEST_GOAL_NAME = "Test goal"
        const val TEST_TASK_NAME_ONE = "Test task 1"
        const val TEST_TASK_NAME_TWO = "Test task 2"
    }

    @Before
    fun setup() {
        hiltRule.inject()
        runBlocking {
            testGoalId = goalRepository.addGoal(TEST_GOAL_NAME)
            taskRepository.addTask(testGoalId, TEST_TASK_NAME_ONE)
            taskRepository.addTask(testGoalId, TEST_TASK_NAME_TWO)
        }
        lateinit var navController: TestNavHostController
        composeTestRule.setContent {
            navController = TestNavHostController(LocalContext.current)
            navController.navigatorProvider.addNavigator(ComposeNavigator())

            // Navigate to timer screen immediately
            LaunchedEffect(Unit) { navController.navigateToTimer(testGoalId) }
            TimelineNavGraph(navController = navController)
        }
    }

    @Test
    fun goalNameIsOnScreen() {
        with(composeTestRule) {
            onNode(hasText("Current goal") and hasAnySibling(hasText(TEST_GOAL_NAME)))
                .assertIsDisplayed()
        }
    }

    @Test
    fun timerStartPauseButtonWork() {
        with(composeTestRule) {
            onNodeWithText("Start").performClick()
            onNodeWithText("Pause").apply {
                assertIsDisplayed()
                performClick()
            }
            onNodeWithText("Start").assertIsDisplayed()
        }
    }

    @Test
    fun skipButtonGoFromWorkToBreak() {
        with(composeTestRule) {
            onNodeWithText("Work session in progress").assertIsDisplayed()
            onNodeWithText("Skip this session").performClick()
            onNodeWithText("Mini break in progress").assertIsDisplayed()
        }
    }

    @Test
    fun timeIsCollectedForGoal() {
        with(composeTestRule) {
            onNodeWithText("Start").performClick()
            onNode(hasText("Current goal") and hasAnySibling(hasText("Total Time Spent: 0")))
                .assertIsDisplayed()

            onNodeWithText("Pause").assertIsDisplayed()

            skipTime(5.seconds)

            waitUntil(10000) {
                onNode(hasText("Current goal") and hasAnySibling(hasText("Total Time Spent: 5")))
                    .isDisplayed()
            }
            onNodeWithText("24:55").assertIsDisplayed()
        }
    }

    @Test
    fun timeIsNotCollectedDuringBreak() {
        with(composeTestRule) {
            onNodeWithText("Work session in progress").assertIsDisplayed()
            onNodeWithText("Skip this session").performClick()
            onNodeWithText("Mini break in progress").assertIsDisplayed()
            onNodeWithText("Start").performClick()

            onNode(hasText("Current goal") and hasAnySibling(hasText("Total Time Spent: 0")))
                .assertIsDisplayed()

            onNodeWithText("Pause").assertIsDisplayed()

            skipTime(5.seconds)

            waitUntil(10000) { onNodeWithText("4:55").isDisplayed() }

            onNode(hasText("Current goal") and hasAnySibling(hasText("Total Time Spent: 0")))
                .assertIsDisplayed()
        }
    }

    @Test
    fun taskIsCreated() {
        with(composeTestRule) {
            onNodeWithText("Add Task").apply {
                assertIsDisplayed()
                performClick()
            }

            onNodeWithText("Task Name*").apply {
                assertIsDisplayed()
                performClick()
                performTextInput("Created task")
            }

            onNodeWithText("Confirm").apply {
                assertIsDisplayed()
                assertIsEnabled()
                performClick()
            }

            onNodeWithText("Current goal").onParent().performTouchInput {
                swipeUp()
                swipeUp()
            }

            onNodeWithText("Created task").assertIsDisplayed()
        }
    }

    @Test
    fun taskCannotBeCreatedWithoutName() {
        with(composeTestRule) {
            onNodeWithText("Add Task").apply {
                assertIsDisplayed()
                performClick()
            }
            onNodeWithText("Task Name*").assertIsDisplayed()
            onNodeWithText("Confirm").assertIsNotEnabled()
        }
    }

    @Test
    fun taskIsDeleted() {
        with(composeTestRule) {
            onNodeWithText("Current goal").onParent().performTouchInput {
                swipeUp()
                swipeUp()
            }

            onNodeWithText(TEST_TASK_NAME_ONE).assertIsDisplayed()
            onNodeWithText(TEST_TASK_NAME_TWO).assertIsDisplayed()

            onNodeWithText(TEST_TASK_NAME_ONE).performTouchInput { swipeLeft() }

            onNodeWithText("Current goal").onParent().performTouchInput {
                swipeUp()
                swipeUp()
            }

            onNodeWithText(TEST_TASK_NAME_ONE).assertIsNotDisplayed()
            onNodeWithText(TEST_TASK_NAME_TWO).assertIsDisplayed()
        }
    }

    @Test
    fun taskIsEdited() {
        with(composeTestRule) {
            onNodeWithText("Current goal").onParent().performTouchInput { swipeUp() }

            onNodeWithText(TEST_TASK_NAME_ONE).apply {
                assertIsDisplayed()
                performClick()
            }

            onNodeWithText("Task Name*").apply {
                assertIsDisplayed()
                performClick()
                performTextClearance()
                performTextInput("Edited task")
            }

            onNodeWithText("Confirm").apply {
                assertIsDisplayed()
                assertIsEnabled()
                performClick()
            }

            onNodeWithText("Current goal").onParent().performTouchInput {
                swipeUp()
                swipeUp()
            }
            onNodeWithText("Edited task").assertIsDisplayed()
            onNodeWithText(TEST_TASK_NAME_ONE).assertIsNotDisplayed()
        }
    }

    @Test
    fun timeIsAddedOnTaskCompletion() {
        runBlocking { goalRepository.addTimeToGoal(testGoalId, 10.seconds) }

        with(composeTestRule) {
            onNodeWithText("Current goal").onParent().performTouchInput { swipeUp() }

            onNodeWithText(TEST_TASK_NAME_ONE).onChild().apply {
                assertIsToggleable()
                assertIsOff()
                performClick()
            }

            onNodeWithText("Current goal").onParent().performTouchInput {
                swipeUp()
                swipeUp()
            }

            onNode(hasText(TEST_TASK_NAME_ONE) and hasText("10")).isDisplayed()

            onNodeWithText(TEST_TASK_NAME_TWO).onChild().apply {
                assertIsToggleable()
                assertIsOff()
                performClick()
            }

            onNode(hasTextExactly(TEST_TASK_NAME_TWO)).assertIsDisplayed()
        }
    }
}
