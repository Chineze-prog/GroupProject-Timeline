## What is Timeline?
Timeline is an innovative personal planner app designed to elevate productivity by effectively 
managing planned projects and tasks. At its core, Timeline simplifies the daunting tasks of organizing 
upcoming deadlines, tracking task progression, and identifying areas that require additional 
attention. This app is a comprehensive solution for individuals seeking to enhance their time 
management skills and streamline their workflow. 

One of Timeline's standout features is its intuitive task management system. Users can effortlessly 
add tasks with due dates and priorities, allowing Timeline to intelligently identify and recommend 
the most suitable task to begin with based on the user's workflow preferences, taking the guesswork 
out of deciding where to start and providing users with a clear roadmap for efficient task completion.

Moreover, Timeline goes beyond mere task tracking; it actively monitors the time users invest in
each task. By tracking task durations, the app suggests strategic breaks, promoting a balanced 
and sustainable work routine. This thoughtful approach ensures that users can maintain consistent 
productivity while prioritizing their well-being.

Lastly, understanding one's workflow is pivotal for effective time management, and Timeline excels in this 
aspect. Users can review their progress on past tasks, unveiling patterns and insights that enable 
continuous improvement in scheduling and task execution. This reflective feature empowers users to 
refine their working methods, resulting in heightened efficiency over time.

## Who is Timeline for? 
Timeline caters to a diverse audience, making it a valuable tool for various scenarios. From parents 
juggling household responsibilities, appointments, and events to students managing a demanding 
course load, Timeline adapts to the unique needs of everyone. Timeline is the perfect tool 
for anyone who needs to manage personal deadlines and tasks, and review progression along their 
projects in a simple, intuitive, and effortless way.

## Why is Timeline valuable?
The inherent value of Timeline lies in its ability to simplify the complexities of multitasking and 
project management. Juggling multiple tasks, keeping track of deadlines, and evaluating progress 
across various projects can be daunting, but Timeline addresses these challenges head-on. It aids 
users in assessing task priorities, encourages breaking down large projects into manageable segments, 
and serves as a visual reminder of their progress. 

## How will Timeline be successful?
The success of Timeline will be gauged by user engagement and retention metrics. The number of active 
users and the average retention time will serve as key indicators of the app's efficacy and popularity. 
A high retention rate signifies that users find ongoing value in Timeline, relying on it as an 
essential tool for their daily productivity and time management needs. As Timeline continues to evolve, 
its success will be synonymous with its ability to adapt to user expectations and consistently enhance 
the productivity experience.

## Features
Planned features can be found [here](https://code.cs.umanitoba.ca/comp3350-winter2024/timeline-a02-9/-/issues/?state=all&label_name%5B%5D=Feature)

## User Stories
User stories can be found [here](https://code.cs.umanitoba.ca/comp3350-winter2024/timeline-a02-9/-/issues/?state=all&label_name%5B%5D=User%20Story)

## Architecture
Application architecture can be found [here](ARCHITECTURE.md)