# Architecture

Our architecture is based
on [Google's app architecture recommendations](https://developer.android.com/topic/architecture#recommended-app-arch),
which is a variant of Model - View - ViewModel architecture.

This document describes the overall repository organization and architecture.

## Overview

Our architecture has 3 main layers: a [data layer], a [domain layer] and a [UI layer].

```mermaid
graph TB
  subgraph Data[Data Layer]
    subgraph Adapters
      TaskDao
      GoalDao
      DayStatisticDao
    end

    subgraph Database
      DayStatisticQueries
      TaskQueries
      GoalQueries
    end

    Database -- convert columns to model --> Adapters
    Adapters -. deconstruct actions to queries .-> Database
  end

  subgraph Domain[Domain Layer]
    %% Workaround for https://github.com/mermaid-js/mermaid/issues/4644
    Hidden:::hidden
    subgraph Timer
      PomodoroUseCase
      TimerUseCase
      CollectTimeUseCase
    end

    subgraph Goal
      AddGoalTimeUseCase
      DeleteGoalUseCase
      UpdateGoalUseCase
    end

    subgraph Repositories
      TaskRepository
      GoalRepository
      DayStatisticRepository
    end

    Timer --> Repositories
    Goal --> Repositories
  end

  subgraph UI[UI Layer]
    subgraph ViewModels[View Models]
      GoalViewModel
      TimerViewModel
    end
    subgraph Screens
      GoalScreen
      TimerScreen
    end

    TimelineNavGraph -- select screen to display --> Screens
    Screens -. navigation events .-> TimelineNavGraph
    GoalScreen <--> GoalViewModel
    TimerScreen <--> TimerViewModel
  end

  Adapters -- data in --> Repositories
  Repositories -. events out .-> Adapters
  ViewModels -. events out .-> Domain
  Domain -- data in --> ViewModels
  
  %% Arrange boxes in a straight line
  Hidden ~~~ Repositories
  
  classDef hidden display: none;
```

[data layer]: app/src/main/java/ca/umanitoba/cs/timeline/data

[domain layer]: app/src/main/java/ca/umanitoba/cs/timeline/domain

[UI layer]: app/src/main/java/ca/umanitoba/cs/timeline/ui

> :information: The diagram above have system dependencies factored out as they are not important
> to the understanding of the program structure. More information can be found in
> [Dependency injection](#dependency-injection) section below

Our architecture follows a reactive model, where changes in lower layers flow to higher layers, and
events flow down the pipeline. This is called [Unidirectional data flow][UDF].

The highest layer is UI while the lowest is the data layer.

[UDF]: https://developer.android.com/topic/architecture/ui-layer#udf

## UI Layer

The UI layer is separated into two major components:

- Screens
- View Models

This layer is completely contained within
the [`.ui`](/app/src/main/java/ca/umanitoba/cs/timeline/ui) package.

### View Models

View Models holds the responsibility of transforming data from lower layers into UI state, and
transforming UI interactions into events for lower layers. As such, view models have a two-way
binding with screens: They are aware of what is going on in the screen, and the screen is aware
of the view model structure.

View Models are the only way for UI components to talk to lower layers.

#### [`TimerViewModel`](/app/src/main/java/ca/umanitoba/cs/timeline/ui/timer/TimerViewModel.kt)

This is the view model that connects the domain layer to the timer UI.

#### [`GoalViewModel`](/app/src/main/java/ca/umanitoba/cs/timeline/ui/goals/GoalViewModel.kt)

This is the view model that connects the domain layer to the goal list UI.

### Screens

Screens are what is shown to the user. Code in here only uses other UI components and never access
the lower layers.

We used [Jetpack Compose] to implement the screens.

[Jetpack Compose]: https://developer.android.com/jetpack/compose

#### [`TimerScreen.kt`](/app/src/main/java/ca/umanitoba/cs/timeline/ui/timer/TimerScreen.kt)

The screen with the timer and task list.

#### [`GoalScreen.kt`](/app/src/main/java/ca/umanitoba/cs/timeline/ui/goals/GoalScreen.kt)

The screen with the goal list.

#### Navigation

Implemented
by [`TimelineNavGraph.kt`](/app/src/main/java/ca/umanitoba/cs/timeline/ui/TimelineNavGraph.kt),
this represents the screen graph of the program. Which screen is shown and how to move between them
is defined here.

## Domain Layer

The domain layer implements the bulk of the program logic model. These are separated into `UseCase`s
which perform exactly one task. This design is inspired by
Google's [Architecture guide][Google domain layer].

In addition to `UseCase`s, we also host repositories as the abstraction to connect to the data layer
here. This was requested by graders in previous iterations.

[Google domain layer]: https://developer.android.com/topic/architecture/domain-layer

This layer is completely contained within
the [`.domain`](/app/src/main/java/ca/umanitoba/cs/timeline/domain) package.

### Timer feature

#### [`PomodoroUseCase`](app/src/main/java/ca/umanitoba/cs/timeline/domain/timer/PomodoroUseCase.kt)

The state machine behind the Pomodoro timer. This allows for the application of the Pomodoro
technique.

#### [`TimerUseCase`](app/src/main/java/ca/umanitoba/cs/timeline/domain/timer/TimerUseCase.kt)

Implements the timer ticking logic.

#### [`CollectTimeUseCase`](app/src/main/java/ca/umanitoba/cs/timeline/domain/timer/CollectTimeUseCase.kt)

Implements time accumulation logic for goals.

### Task list feature

#### [`TaskRepository`](app/src/main/java/ca/umanitoba/cs/timeline/domain/task/TaskRepository.kt)

A list-like interface for managing collections of [`Task`]s.

#### [`DefaultTaskRepository`](app/src/main/java/ca/umanitoba/cs/timeline/domain/task/DefaultTaskRepository.kt)

The default implementation of `TaskRepository`, just a simple bridge to `TaskDao`.

### Goal feature

#### [`GoalRepository`](app/src/main/java/ca/umanitoba/cs/timeline/domain/goal/GoalRepository.kt)

A list-like interface for managing collections of [`Goal`]s.

#### [`DefaultGoalRepository`](app/src/main/java/ca/umanitoba/cs/timeline/domain/goal/DefaultGoalRepository.kt)

The default implementation of `GoalRepository`.

#### [`AddGoalTimeUseCase`](app/src/main/java/ca/umanitoba/cs/timeline/domain/goal/AddGoalTimeUseCase.kt)

The use case for adding time spent to a goal. This extends upon `GoalRepository::addTimeToGoal` with
extra logic to handle the statistics feature.

#### [`UpdateGoalUseCase`](app/src/main/java/ca/umanitoba/cs/timeline/domain/goal/UpdateGoalUseCase.kt)

The use case for updating information related to a [`Goal`]. This extends upon
`GoalRepository::updateGoal` with extra logic to verify model consistency.

### Statistics feature

#### [`DayStatisticRepository`](app/src/main/java/ca/umanitoba/cs/timeline/domain/dayStatistic/DayStatisticRepository.kt)

A list-like interface for managing collections of [`DayStatistic`]s.

#### [`DefaultDayStatisticRepository`](app/src/main/java/ca/umanitoba/cs/timeline/domain/dayStatistic/DefaultDayStatisticRepository.kt)

The default implementation of `DayStatisticRepository`.

### Auxiliary use cases

Reusable logic that does not belong to any one feature.

#### [`GetLocalDateUseCase`](app/src/main/java/ca/umanitoba/cs/timeline/domain/GetLocalDateUseCase.kt)

Provides a reactive view of the current date, with automatic updates every hour.

## Data Layer

The data layer implements persistence logic via the use of data access objects (DAOs), which are
adapters to real database interface generated by [SQLDelight](https://cashapp.github.io/sqldelight).

This layer is contained within the [`.data`](/app/src/main/java/ca/umanitoba/cs/timeline/data)
package and contains code for handling data storage and management.

### [`TaskDao`](app/src/main/java/ca/umanitoba/cs/timeline/data/TaskDao.kt)

An interface describing direct task database access.

### [`InMemoryTaskDao`](app/src/main/java/ca/umanitoba/cs/timeline/data/InMemoryTaskDao.kt)

Implementation of an in-memory `TaskDao`, where data is gone as soon as the app process terminates.

### [`DefaultTaskDao`](app/src/main/java/ca/umanitoba/cs/timeline/data/DefaultTaskDao.kt)

Implementation of the default `TaskDao`, using SQLDelight to persist data.

### [`GoalDao`](app/src/main/java/ca/umanitoba/cs/timeline/data/GoalDao.kt)

An interface describing direct goal database access.

### [`InMemoryGoalDao`](app/src/main/java/ca/umanitoba/cs/timeline/data/InMemoryGoalDao.kt)

Implementation of an in-memory `GoalDao`, where data is gone as soon as the app process terminates.

### [`DefaultGoalDao`](app/src/main/java/ca/umanitoba/cs/timeline/data/DefaultGoalDao.kt)

Implementation of the default `GoalDao`, using SQLDelight to persist data.

### [`DayStatisticDao`](app/src/main/java/ca/umanitoba/cs/timeline/data/DayStatisticDao.kt)

An interface describing direct day statistics access.

### [`InMemoryDayStatisticDao`](app/src/main/java/ca/umanitoba/cs/timeline/data/InMemoryDayStatisticDao.kt)

Implementation of an in-memory `GoalDao`, where data is gone as soon as the app process terminates.

### [`DefaultDayStatisticDao`](app/src/main/java/ca/umanitoba/cs/timeline/data/DefaultDayStatisticDao.kt)

Implementation of the default `DayStatisticDao`, using SQLDelight to persist data.

### [`TaskQueries`](app/src/main/sqldelight/ca/umanitoba/cs/timeline/Task.sq)

The implementation of SQL queries for `DefaultTaskDao`. The `TaskQueries` class is generated
by SQLDelight based on this SQL file.

### [`GoalQueries`](app/src/main/sqldelight/ca/umanitoba/cs/timeline/Goal.sq)

The implementation of SQL queries for `DefaultGoalDao`. The `GoalQueries` class is generated
by SQLDelight based on this SQL file.

### [`DayStatisticQueries`](app/src/main/sqldelight/ca/umanitoba/cs/timeline/DayStatistic.sq)

The implementation of SQL queries for `DefaultDayStatisticDao`. The `DayStatisticQueries` class is
generated by SQLDelight based on this SQL file.

## Models

Contained within [`.model`](/app/src/main/java/ca/umanitoba/cs/timeline/model) package, this layer
provides models for data handled by the application

### [`Task`]

Data class describing a task.

### [`Goal`]

Data class describing a goal.

### [`DayStatistic`]

Data class describing accumulated data about a day.

[`Task`]: app/src/main/java/ca/umanitoba/cs/timeline/model/Task.kt

[`Goal`]: app/src/main/java/ca/umanitoba/cs/timeline/model/Goal.kt

[`DayStatistic`]: app/src/main/java/ca/umanitoba/cs/timeline/model/DayStatistic.kt

## Utilities

Utilities usable by all layers are placed within the
[`.utils`](app/src/main/java/ca/umanitoba/cs/timeline/utils) package. The difference between
utilities and use cases in domain layer is that utilities solves a general problem that does not
have much bearing to the program logic.

## Tests

Tests are tagged with `@Tag("unit")` or `@Tag("integration")` within their source file to specify
whether they are integration or unit tests.

These are then automatically collected as:

- [`IntegrationTestSuite`](app/src/test/java/ca/umanitoba/cs/timeline/IntegrationTestSuite.kt): The
  full integration test suite. This class can be used to only run the integration tests.

- [`UnitTestSuite`](app/src/test/java/ca/umanitoba/cs/timeline/UnitTestSuite.kt): The full unit test
  suite. This class can be used to only run the unit tests.

All tests can be run manually via: `./gradlew test`

### Acceptance tests

Acceptance tests are collected into two suites:

- [`AcceptanceTestSuite`](app/src/androidTest/java/ca/umanitoba/cs/timeline/AcceptanceTestSuite.kt):
  The full acceptance test suite that run on a real device.

- [`RobolectricTestSuite`](app/src/testDebug/java/ca/umanitoba/cs/timeline/RobolectricTestSuite.kt):
  Acceptance tests that are run on the JVM, allowing automated testing without using emulators.

In order to share testing code, most acceptance tests are spun off into
the [`:app-shared-tests](app-shared-tests) module.

## Dependency injection

This program makes extensive usage of dependency injection to achieve comprehensive unit and
integration testing. This leads to many "basic" elements such as system clock or coroutine
dispatchers become injected instead of instantiated directly by dependents.

To reduce boilerplate that ensues from this design,
the [Hilt](https://developer.android.com/training/dependency-injection/hilt-android)
framework is utilized to automatically inject dependencies where they are required. Hilt processes
dependencies and generate glue code automatically at compile time and incur no runtime costs.

Hilt works by tagging classes with `@Inject` and provide `@Module`s for declaring how should a
dependency be fulfilled.

### Dependency Modules

`@Module`s tell Hilt how to provide the dependency to a given interface (ie. use `AndroidTimeSource`
to satisfy `TimeSource` interface on Android). In this project, we host most modules within `.di`
subpackages, with a simple heuristic:

- Modules that inject only implementations of interfaces that are implemented in the same package
  goes into the `.di` subpackage of that package. An example is [`DaoModule`] describe the Dao
  implementation to be used by other packages.

- Modules that inject system dependencies, like `AndroidSqliteDriver` as `SqlDriver` on Android
  are implemented within `.di` subpackage of the top-level `ca.umanitoba.cs.timeline`.

### System dependencies

This section describes the system dependencies injected in the program.

```mermaid
graph BT
  AndroidSqlDriver --> AndroidDatabaseModule
  AndroidDatabaseModule --> DatabaseModule
  DatabaseModule --> Database
  Database --> TaskQueries
  Database --> GoalQueries
  Database --> DayStatisticQueries
  ZoneIdModule --> ZoneId
  ZoneId --> Adapters

  subgraph DB[Data Layer]
    subgraph Adapters
      DefaultDayStatisticDao
      DefaultTaskDao
      DefaultGoalDao
    end

    subgraph DBQueries[Database]
      Database
      DayStatisticQueries
      TaskQueries
      GoalQueries
    end

    DayStatisticQueries --> DefaultDayStatisticDao
    TaskQueries --> DefaultTaskDao
    GoalQueries --> DefaultGoalDao
    DefaultDayStatisticDao --> DaoModule
    DefaultTaskDao --> DaoModule
    DefaultGoalDao --> DaoModule
  end

  subgraph Domain[Domain Layer]
    AddGoalTimeUseCase
    UpdateGoalUseCase
    TimerUseCase

    subgraph Repositories
      DefaultDayStatisticRepository
      DefaultTaskRepository
      DefaultGoalRepository
    end
  end

  ClockModule --> Clock
  Clock --> AddGoalTimeUseCase
  Clock --> UpdateGoalUseCase
  DaoModule --> Repositories
  AndroidTimeSourceModule --> TimeSource
  TimeSource --> TimerUseCase
  CoroutineModule --> Dispatchers.IO
  Dispatchers.IO --> Adapters
```

#### `SqlDriver`

`SqlDriver` is the database driver used by the system. This is injected by
[`AndroidDatabaseModule`](app/src/main/java/ca/umanitoba/cs/timeline/di/AndroidDatabaseModule.kt)
in the resulting Android program.

When used on other platforms, SQLDelight
provides [other drivers](https://cashapp.github.io/sqldelight/2.0.1/multiplatform_sqlite/#constructing-driver-instances)
that could be used instead. This is done for integration tests.

For acceptance tests, we
use [`TestSqlDriverModule`](app/src/androidTest/java/ca/umanitoba/cs/timeline/di/TestSqlDriverModule.kt)
to inject a memory-only database in those, allowing us to skip all teardown stages by always
starting at a clean slate.

#### `TimeSource`

`TimeSource` is used by the timer to track how much real time has passed. This is implemented for
Android
as [`AndroidRealTimeSource`](app/src/main/java/ca/umanitoba/cs/timeline/utils/AndroidRealTimeSource.kt)
as the
Kotlin-provided `TimeSource.Monotonic` [does not count the sleep time on Android][monotonic-android-sleep].

In tests, we
use [`TestTimeSource`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.time/-test-time-source/)
as `TimeSource`, allowing manual control of the clock and avoid actually waiting for the required
time.

#### `CoroutineDispatcher`

This program uses `Dispatchers.IO` to offload database update outside of main thread. However, this
makes integration testing harder as we cannot control when certain actions happen. To combat this,
they are also injected
via [`CoroutineModule`](app/src/main/java/ca/umanitoba/cs/timeline/di/CoroutineModule.kt)
so that it become possible to swap out during integration testing.

#### `Clock`

The real system clock is injected
via [`ClockModule`](app/src/main/java/ca/umanitoba/cs/timeline/di/ClockModule.kt)
during runtime, but a fixed and fake clock is used in unit tests instead.

#### `ZoneId`

The real system timezone is injected
via [`ZoneIdModule`](app/src/main/java/ca/umanitoba/cs/timeline/di/ZoneIdModule.kt)
during runtime, but in unit tests we inject UTC timezone directly to make sure the test system
timezone does not have any bearings on the tests.

[monotonic-android-sleep]: https://kotlinlang.org/docs/time-measurement.html#create-time-source
